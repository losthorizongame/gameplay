
import * as THREE from 'three';
import { getTerrainHeight, checkVegetationCollision, initNoise } from './MathUtils';
import { WATER_LEVEL, WORLD_SEED } from '../types';

// Inicializa o noise se ainda não estiver (segurança)
initNoise(WORLD_SEED);

export const generateNextMissionPosition = (currentPos: THREE.Vector3): THREE.Vector3 => {
  const minDistance = 300;
  const maxDistance = 800;
  
  // Tenta encontrar um ponto válido por X tentativas
  for (let i = 0; i < 50; i++) {
    // 1. Escolhe uma direção e distância aleatória
    const angle = Math.random() * Math.PI * 2;
    const distance = minDistance + Math.random() * (maxDistance - minDistance);
    
    const targetX = currentPos.x + Math.cos(angle) * distance;
    const targetZ = currentPos.z + Math.sin(angle) * distance;
    
    // 2. Verifica a altura do terreno
    const height = getTerrainHeight(targetX, targetZ);
    
    // REGRAS DE VALIDAÇÃO:
    // - Deve ser terra firme (acima da água + margem)
    // - Não pode ser pico de montanha inacessível (> 50m)
    // - Inclinação razoável (checa vizinhos)
    
    if (height > WATER_LEVEL + 2.0 && height < 50) {
        // Checagem de inclinação simples
        const h2 = getTerrainHeight(targetX + 2, targetZ);
        const slope = Math.abs(height - h2);
        
        if (slope < 1.5) {
             // Ponto válido encontrado!
             // Retornamos Y + 1.0 para o marcador flutuar levemente
             return new THREE.Vector3(targetX, height, targetZ);
        }
    }
  }
  
  // Fallback se falhar (muito raro): retorna um ponto próximo seguro
  return new THREE.Vector3(currentPos.x + 100, 50, currentPos.z + 100);
};
