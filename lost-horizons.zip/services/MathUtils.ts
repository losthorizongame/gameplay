
import { WATER_LEVEL, VILLAGE_GRID_SIZE, VILLAGE_CHANCE, CHUNK_SIZE, VEGETATION_STEP_HIGH, HouseData, VillageObjectData } from '../types';

// OTIMIZAÇÃO: Cache para getTerrainHeight.
const heightCache = new Map<string, number>();
const MAX_HEIGHT_CACHE = 5000;

class PseudoNoise {
  private perm: number[];
  private grad3: number[][];

  constructor(seed: number) {
    this.grad3 = [
      [1, 1, 0], [-1, 1, 0], [1, -1, 0], [-1, -1, 0],
      [1, 0, 1], [-1, 0, 1], [1, 0, -1], [-1, 0, -1],
      [0, 1, 1], [0, -1, 1], [0, 1, -1], [0, -1, -1]
    ];
    // Pre-calc permutation table
    const p = new Array(256);
    for (let i = 0; i < 256; i++) {
      p[i] = Math.floor(Math.abs(Math.sin(seed + i)) * 256);
    }
    this.perm = new Array(512);
    for (let i = 0; i < 512; i++) {
      this.perm[i] = p[i & 255];
    }
  }

  private dot(g: number[], x: number, y: number) {
    return g[0] * x + g[1] * y;
  }

  public noise2D(xin: number, yin: number) {
    const F2 = 0.5 * (Math.sqrt(3.0) - 1.0);
    const s = (xin + yin) * F2;
    const i = Math.floor(xin + s);
    const j = Math.floor(yin + s);
    const G2 = (3.0 - Math.sqrt(3.0)) / 6.0;
    const t = (i + j) * G2;
    const X0 = i - t;
    const Y0 = j - t;
    const x0 = xin - X0;
    const y0 = yin - Y0;

    let i1, j1;
    if (x0 > y0) { i1 = 1; j1 = 0; }
    else { i1 = 0; j1 = 1; }

    const x1 = x0 - i1 + G2;
    const y1 = y0 - j1 + G2;
    const x2 = x0 - 1.0 + 2.0 * G2;
    const y2 = y0 - 1.0 + 2.0 * G2;

    const ii = i & 255;
    const jj = j & 255;
    const gi0 = this.perm[ii + this.perm[jj]] % 12;
    const gi1 = this.perm[ii + i1 + this.perm[jj + j1]] % 12;
    const gi2 = this.perm[ii + 1 + this.perm[jj + 1]] % 12;

    let n0 = 0.0, n1 = 0.0, n2 = 0.0;

    let t0 = 0.5 - x0 * x0 - y0 * y0;
    if (t0 >= 0) {
      t0 *= t0;
      n0 = t0 * t0 * this.dot(this.grad3[gi0], x0, y0);
    }

    let t1 = 0.5 - x1 * x1 - y1 * y1;
    if (t1 >= 0) {
      t1 *= t1;
      n1 = t1 * t1 * this.dot(this.grad3[gi1], x1, y1);
    }

    let t2 = 0.5 - x2 * x2 - y2 * y2;
    if (t2 >= 0) {
      t2 *= t2;
      n2 = t2 * t2 * this.dot(this.grad3[gi2], x2, y2);
    }

    return 70.0 * (n0 + n1 + n2);
  }
}

// Singletons para evitar recriação
let noiseInstance: PseudoNoise | null = null;
let moistureInstance: PseudoNoise | null = null;
let treeInstance: PseudoNoise | null = null;
let rockInstance: PseudoNoise | null = null; 
let villageInstance: PseudoNoise | null = null;

export const initNoise = (seed: number) => {
  if (noiseInstance) return; // Prevent re-init overhead
  noiseInstance = new PseudoNoise(seed);
  moistureInstance = new PseudoNoise(seed + 1234);
  treeInstance = new PseudoNoise(seed + 9876);
  rockInstance = new PseudoNoise(seed + 4321);
  villageInstance = new PseudoNoise(seed + 5555);
  heightCache.clear();
};

export const getHumidity = (x: number, z: number): number => {
  if (!moistureInstance) initNoise(12345);
  const val = moistureInstance!.noise2D(x / 600, z / 600);
  return (val + 1) * 0.5; 
};

export const getTreeDensity = (x: number, z: number): number => {
  if (!treeInstance) initNoise(12345);
  return (treeInstance!.noise2D(x / 5, z / 5) + 1) * 0.5;
}

export const getRockDensity = (x: number, z: number): number => {
  if (!rockInstance) initNoise(12345);
  return (rockInstance!.noise2D(x / 50, z / 50) + 1) * 0.5;
}

export const getTerrainHeight = (x: number, z: number): number => {
  // OTIMIZAÇÃO: Cache Key arredondada para aumentar hits
  const key = `${Math.floor(x * 10)}_${Math.floor(z * 10)}`;
  if (heightCache.has(key)) return heightCache.get(key)!;

  if (!noiseInstance) initNoise(12345);
  
  const continental = noiseInstance!.noise2D(x / 500, z / 500);
  const detail = noiseInstance!.noise2D(x / 120, z / 120);
  
  const fine = noiseInstance!.noise2D(x / 30, z / 30) * 0.2;

  let height = 0;
  
  if (continental < -0.4) {
    height = continental * 20; 
  } else if (continental < 0.1) {
    height = continental * 10;
  } else if (continental < 0.5) {
    height = 5 + (continental * 5) + (detail * 3);
  } else {
    var mountainFactor = (continental - 0.5) * 2; 
    height = 15 + (mountainFactor * 60) + (detail * 10);
  }

  height += fine;
  
  // Cache management
  if (heightCache.size > MAX_HEIGHT_CACHE) {
      heightCache.clear(); 
  }
  heightCache.set(key, height);

  return height;
};

export const findSafeSpawnPosition = (): { x: number, y: number, z: number } => {
  if (!noiseInstance) initNoise(12345);
  const step = 32; 

  for (let i = 0; i < 100; i++) {
    const angle = i * 2.4; 
    const radius = Math.sqrt(i) * step;
    const x = Math.cos(angle) * radius;
    const z = Math.sin(angle) * radius;
    const h = getTerrainHeight(x, z);
    
    if (h > WATER_LEVEL + 2.0 && h < 50) {
        if (!checkVegetationCollision(x, z)) {
            return { x, y: h + 2.5, z };
        }
    }
  }
  return { x: 0, y: 80, z: 0 };
};

const hashCoordinates = (x: number, z: number): number => {
  let h = 0x811c9dc5;
  h ^= Math.floor(x);
  h = Math.imul(h, 0x01000193);
  h ^= Math.floor(z);
  h = Math.imul(h, 0x01000193);
  return (h >>> 0) / 4294967296; 
};

export const getVillageData = (regionX: number, regionZ: number) => {
  if (!villageInstance) initNoise(12345);

  let seedVal = hashCoordinates(regionX * 987, regionZ * 123);
  
  // --- FORÇAR VILA INICIAL ---
  if (regionX === 0 && regionZ === 0) {
      seedVal = 0.1;
  }

  if (seedVal > VILLAGE_CHANCE) return null;

  const jitterX = (hashCoordinates(regionX, seedVal) - 0.5) * VILLAGE_GRID_SIZE * 0.4;
  const jitterZ = (hashCoordinates(regionZ, seedVal) - 0.5) * VILLAGE_GRID_SIZE * 0.4;
  
  let worldX = regionX * VILLAGE_GRID_SIZE + VILLAGE_GRID_SIZE/2 + jitterX;
  let worldZ = regionZ * VILLAGE_GRID_SIZE + VILLAGE_GRID_SIZE/2 + jitterZ;

  let h = getTerrainHeight(worldX, worldZ);
  
  // --- SEGURANÇA PARA A VILA INICIAL (0,0) ---
  if (regionX === 0 && regionZ === 0) {
      if (h < WATER_LEVEL + 2.0 || h > 45) {
          let found = false;
          for(let r=10; r<=150; r+=10) {
              for(let a=0; a<Math.PI*2; a+=0.5) {
                  const tx = worldX + Math.cos(a)*r;
                  const tz = worldZ + Math.sin(a)*r;
                  const th = getTerrainHeight(tx, tz);
                  if (th > WATER_LEVEL + 3.0 && th < 35) {
                      worldX = tx;
                      worldZ = tz;
                      h = th;
                      found = true;
                      break;
                  }
              }
              if (found) break;
          }
      }
      return { x: worldX, z: worldZ, h, seed: seedVal };
  }

  if (h < WATER_LEVEL + 1.5) return null;
  if (h > 45) return null;

  const h1 = getTerrainHeight(worldX + 8, worldZ);
  const h2 = getTerrainHeight(worldX, worldZ + 8);
  const slope = Math.max(Math.abs(h - h1), Math.abs(h - h2));

  if (slope > 2.4) return null;

  return { x: worldX, z: worldZ, h, seed: seedVal };
};

// Nova Função: Encontrar a vila válida mais próxima de uma posição
export const findNearestVillage = (posX: number, posZ: number, minDistance: number = 200): { x: number, z: number, y: number } | null => {
    const startRX = Math.floor(posX / VILLAGE_GRID_SIZE);
    const startRZ = Math.floor(posZ / VILLAGE_GRID_SIZE);
    
    // Procura em espiral ao redor da região atual
    for (let radius = 0; radius <= 5; radius++) {
        for (let x = startRX - radius; x <= startRX + radius; x++) {
            for (let z = startRZ - radius; z <= startRZ + radius; z++) {
                // Verificar se a vila existe
                const v = getVillageData(x, z);
                if (v) {
                    const distSq = (v.x - posX)**2 + (v.z - posZ)**2;
                    // Deve ser longe o suficiente para valer a viagem, mas a mais próxima possível
                    if (distSq > minDistance * minDistance) {
                        return { x: v.x, z: v.z, y: v.h };
                    }
                }
            }
        }
    }
    // Fallback: Retorna uma posição arbitrária se não achar vilas (terra distante)
    const fallbackX = posX + 500;
    const fallbackZ = posZ + 500;
    const fh = getTerrainHeight(fallbackX, fallbackZ);
    return { x: fallbackX, z: fallbackZ, y: fh };
}

export const getVillageContent = (regionX: number, regionZ: number) => {
  const village = getVillageData(regionX, regionZ);
  if (!village) return { houses: [], objects: [] };

  const houses: HouseData[] = [];
  const objects: VillageObjectData[] = [];
  
  const axisX = village.seed > 0.5;
  const numHouses = 4 + Math.floor(village.seed * 4); 
  const spacing = 10;
  const streetWidth = 10;

  objects.push({
    type: village.seed > 0.3 ? 'well' : 'campfire',
    x: village.x, z: village.z, y: village.h, rot: 0
  });

  if (village.h < WATER_LEVEL + 15.0) {
      const dirs = [[1,0], [-1,0], [0,1], [0,-1]];
      let dockPlaced = false;

      for (const dir of dirs) {
          for (let dist = 8; dist <= 45; dist += 4) {
              const dx = dir[0] * dist;
              const dz = dir[1] * dist;
              const checkH = getTerrainHeight(village.x + dx, village.z + dz);
              
              if (checkH < WATER_LEVEL) {
                  const shorelineDist = dist - 1; 
                  const dockX = village.x + (dir[0] * shorelineDist);
                  const dockZ = village.z + (dir[1] * shorelineDist);
                  const dockY = WATER_LEVEL + 0.5;
                  const rot = dir[0] !== 0 ? (dir[0] > 0 ? 0 : Math.PI) : (dir[1] > 0 ? -Math.PI/2 : Math.PI/2);
                  
                  objects.push({ type: 'dock', x: dockX, z: dockZ, y: dockY, rot: rot });
                  objects.push({ type: 'boat', x: village.x + (dir[0] * (dist+5)), z: village.z + (dir[1] * (dist+5)), y: WATER_LEVEL, rot: rot + Math.PI });
                  dockPlaced = true;
                  break; 
              }
          }
          if (dockPlaced) break; 
      }
  }

  for (let i = 0; i < numHouses; i++) {
    const side = i % 2 === 0 ? 1 : -1;
    const distance = Math.floor(i / 2) * spacing + spacing;
    let hx, hz, rot;

    if (axisX) {
      hx = village.x + distance * (i % 4 < 2 ? 1 : -1);
      hz = village.z + (streetWidth * side);
      rot = side === 1 ? Math.PI : 0;
    } else {
      hx = village.x + (streetWidth * side);
      hz = village.z + distance * (i % 4 < 2 ? 1 : -1);
      rot = side === 1 ? Math.PI / 2 : -Math.PI / 2;
    }
    
    const hh = getTerrainHeight(hx, hz);
    if (Math.abs(hh - village.h) < 5.0 && hh > WATER_LEVEL + 1.0) {
       houses.push({ x: hx, z: hz, y: hh + 0.5, rot: rot, radius: 5.0 });
       if (i % 2 === 0) {
         const lampX = axisX ? hx : (side === 1 ? hx - 4 : hx + 4);
         const lampZ = axisX ? (side === 1 ? hz - 4 : hz + 4) : hz;
         const lh = getTerrainHeight(lampX, lampZ);
         objects.push({ type: 'lamp', x: lampX, z: lampZ, y: lh, rot: 0 });
       }
    }
  }

  // NPC REMOVIDO DAQUI - Agora é controlado pelo App.tsx dinamicamente
  // com base no capítulo da história para não ficar preso a (0,0)

  return { houses, objects };
};

const isVillageInRegion = (rX: number, rZ: number): boolean => {
    if (!villageInstance) initNoise(12345);
    if (rX === 0 && rZ === 0) return true;
    const seedVal = hashCoordinates(rX * 987, rZ * 123);
    return seedVal <= VILLAGE_CHANCE;
};

export const getObstaclesInChunk = (chunkX: number, chunkZ: number): HouseData[] => {
  const worldX = chunkX * CHUNK_SIZE;
  const worldZ = chunkZ * CHUNK_SIZE;
  const rX = Math.floor((worldX + CHUNK_SIZE/2) / VILLAGE_GRID_SIZE);
  const rZ = Math.floor((worldZ + CHUNK_SIZE/2) / VILLAGE_GRID_SIZE);
  const obstacles: HouseData[] = [];

  for(let x = rX - 1; x <= rX + 1; x++) {
    for(let z = rZ - 1; z <= rZ + 1; z++) {
        if (!isVillageInRegion(x, z)) continue;
        const content = getVillageContent(x, z);
        obstacles.push(...content.houses);
        content.objects.forEach(obj => {
            obstacles.push({ x: obj.x, z: obj.z, y: obj.y, rot: 0, radius: 2.0 });
        });
    }
  }
  return obstacles;
}

export const getVillageHouses = (regionX: number, regionZ: number): HouseData[] => {
    return getVillageContent(regionX, regionZ).houses;
};

export const getPlatformHeight = (x: number, z: number, currentTerrainHeight: number): number => {
    if (currentTerrainHeight > WATER_LEVEL + 5.0) return currentTerrainHeight;
    const rX = Math.floor(x / VILLAGE_GRID_SIZE);
    const rZ = Math.floor(z / VILLAGE_GRID_SIZE);
    
    for(let cx = rX - 1; cx <= rX + 1; cx++) {
        for(let cz = rZ - 1; cz <= rZ + 1; cz++) {
            if (!isVillageInRegion(cx, cz)) continue;

            const content = getVillageContent(cx, cz);
            for (const house of content.houses) {
                const dx = x - house.x;
                const dz = z - house.z;
                if (dx*dx + dz*dz < 120) { 
                     const cos = Math.cos(-house.rot);
                     const sin = Math.sin(-house.rot);
                     const lx = dx * cos - dz * sin;
                     const lz = dx * sin + dz * cos;
                     
                     if (Math.abs(lx) < 3.8 && Math.abs(lz) < 4.3) {
                         return Math.max(currentTerrainHeight, house.y + 0.2);
                     }
                     if (Math.abs(lx) < 1.5 && lz >= 4.3 && lz < 7.0) {
                         const rampStartZ = 7.0; 
                         const rampEndZ = 4.3;   
                         const t = (rampStartZ - lz) / (rampStartZ - rampEndZ);
                         const clampedT = Math.max(0, Math.min(1, t));
                         return currentTerrainHeight + (house.y + 0.2 - currentTerrainHeight) * clampedT;
                     }
                }
            }
            for (const obj of content.objects) {
                if (obj.type === 'dock') {
                    const dx = x - obj.x;
                    const dz = z - obj.z;
                    const cos = Math.cos(-obj.rot);
                    const sin = Math.sin(-obj.rot);
                    const localX = dx * cos - dz * sin;
                    const localZ = dx * sin + dz * cos;
                    
                    if (localX > -1.2 && localX < 4.8 && Math.abs(localZ) < 1.4) {
                        return obj.y + 0.2; 
                    }
                    if (localX <= -1.2 && localX > -4.0 && Math.abs(localZ) < 1.4) {
                        const rampDist = (-1.2 - localX); 
                        const rampHeight = obj.y + 0.2 + (rampDist * 0.3);
                        return Math.max(currentTerrainHeight, rampHeight);
                    }
                }
            }
        }
    }
    return currentTerrainHeight;
}

export const checkVegetationCollision = (playerX: number, playerZ: number): boolean => {
    // OTIMIZAÇÃO: Verifica primeiro colisão com casas (mais rápido e crítico)
    const isPositionBlockedByVillage = (objX: number, objZ: number, threshold: number): boolean => {
       const cX = Math.floor(objX / CHUNK_SIZE);
       const cZ = Math.floor(objZ / CHUNK_SIZE);
       // Checagem rápida de obstáculos
       const obstacles = getObstaclesInChunk(cX, cZ);
       const minDistSq = threshold * threshold; 
       for (const obs of obstacles) {
           const dx = objX - obs.x;
           const dz = objZ - obs.z;
           if (dx*dx + dz*dz < minDistSq) return true; 
       }
       return false;
    };

    const treeStep = VEGETATION_STEP_HIGH;
    const treeGridX = Math.round(playerX / treeStep);
    const treeGridZ = Math.round(playerZ / treeStep);
    
    for (let i = -1; i <= 1; i++) {
        for (let j = -1; j <= 1; j++) {
            const baseX = (treeGridX + i) * treeStep;
            const baseZ = (treeGridZ + j) * treeStep;
            
            // OTIMIZAÇÃO: Se não tiver densidade, nem faz contas pesadas
            const density = getTreeDensity(baseX, baseZ);
            if (density < 0.6) continue;

            const jitterX = (density - 0.5) * treeStep * 1.8;
            const jitterZ = (getTreeDensity(baseX + 50, baseZ + 50) - 0.5) * treeStep * 1.8;
            const objX = baseX + jitterX;
            const objZ = baseZ + jitterZ;
            
            const dx = playerX - objX;
            const dz = playerZ - objZ;
            
            // Distância bruta
            if (dx*dx + dz*dz > 2.0) continue; 
            
            // Se chegou aqui, está muito perto de um possível tronco.
            // Agora sim fazemos a checagem cara de altura e bioma.
            const scale = 0.8 + (density * 0.7);
            const radius = (0.5 * scale) + 0.2; 

            if (dx*dx + dz*dz < radius * radius) {
                const height = getTerrainHeight(objX, objZ);
                if (height < WATER_LEVEL + 3.5 || height > 35) continue;
                
                const humidity = getHumidity(objX, objZ);
                if (humidity < 0.35) continue;

                if (!isPositionBlockedByVillage(objX, objZ, 5.5)) return true;
            }
        }
    }
    
    // Check rápido de pedras
    const rockStep = VEGETATION_STEP_HIGH * 1.5;
    const rockGridX = Math.round(playerX / rockStep);
    const rockGridZ = Math.round(playerZ / rockStep);

    for (let i = -1; i <= 1; i++) {
        for (let j = -1; j <= 1; j++) {
            const baseX = (rockGridX + i) * rockStep;
            const baseZ = (rockGridZ + j) * rockStep;
            
            const dx = playerX - (baseX); 
            const dz = playerZ - (baseZ);
            
            if (dx*dx + dz*dz > 50) continue; 

            const jitterX = (hashCoordinates(baseX, baseZ) - 0.5) * rockStep;
            const jitterZ = (hashCoordinates(baseX + 100, baseZ + 100) - 0.5) * rockStep;
            const objX = baseX + jitterX;
            const objZ = baseZ + jitterZ;
            
            const dx2 = playerX - objX;
            const dz2 = playerZ - objZ;

            if (dx2*dx2 + dz2*dz2 < 9.0) { 
                const rh = getTerrainHeight(objX, objZ);
                const isSafeLand = rh > WATER_LEVEL + 3.0;
                const rockDensity = getRockDensity(objX, objZ);
                
                if (isSafeLand && rockDensity > 0.6) {
                    const existenceHash = hashCoordinates(objX * 13, objZ * 7);
                    if (existenceHash > 0.5) {
                        const scale = 0.5 + (rockDensity * 1.5);
                        const radius = scale * 1.0; 
                        if (dx2*dx2 + dz2*dz2 < radius * radius) {
                             if (!isPositionBlockedByVillage(objX, objZ, 8.0)) return true;
                        }
                    }
                }
            }
        }
    }

    return false;
}
