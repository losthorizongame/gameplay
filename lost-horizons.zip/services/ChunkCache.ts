
import { WorkerResponse } from '../types';

// Capacidade ajustada para equilibrar RAM vs Re-processamento
const CACHE_CAPACITY = 250; 

class ChunkCacheService {
  private cache: Map<string, WorkerResponse>;

  constructor() {
    this.cache = new Map();
  }

  private getKey(x: number, z: number, lod: number): string {
    return `${x}_${z}_${lod}`;
  }

  public get(x: number, z: number, lod: number): WorkerResponse | undefined {
    const key = this.getKey(x, z, lod);
    if (this.cache.has(key)) {
      // LRU: Move para o final (mais recente)
      const data = this.cache.get(key)!;
      this.cache.delete(key);
      this.cache.set(key, data);
      return data;
    }
    return undefined;
  }

  public set(x: number, z: number, lod: number, data: WorkerResponse): void {
    const key = this.getKey(x, z, lod);
    
    // Se o cache estiver cheio, remove o item mais antigo E limpa buffers
    if (this.cache.size >= CACHE_CAPACITY) {
        // Pega o primeiro item (mais antigo no Map)
        const iterator = this.cache.keys();
        const oldKey = iterator.next().value;
        
        if (oldKey) {
            // AQUI É A OTIMIZAÇÃO DE MEMÓRIA:
            // Não podemos dar .dispose() nas geometrias Three.js aqui porque elas são criadas
            // no componente React, mas podemos garantir que os TypedArrays gigantes
            // do Worker sejam liberados da referência para o Garbage Collector.
            this.cache.delete(oldKey);
        }
    }

    this.cache.set(key, data);
  }

  public has(x: number, z: number, lod: number): boolean {
    return this.cache.has(this.getKey(x, z, lod));
  }

  // Chamado quando o jogo reseta ou muda drasticamente de área
  public clear(): void {
    this.cache.clear();
  }
}

export const chunkCache = new ChunkCacheService();
