
import { WORLD_SEED, CHUNK_SIZE, WATER_LEVEL, WorkerResponse } from '../types';

interface WorkerRequest {
  type: 'chunk' | 'minimap';
  x: number;
  z: number;
  lodLevel?: number;
  seed: number;
  chunkSize: number;
  waterLevel: number;
  playerX?: number;
  playerZ?: number;
  radius?: number;
}

// Código do Worker purificado (sem classes complexas que podem falhar na minificação/stringificação)
const workerCode = `
  var perm = new Array(512);
  var grad3 = [
    [1, 1, 0], [-1, 1, 0], [1, -1, 0], [-1, -1, 0],
    [1, 0, 1], [-1, 0, 1], [1, 0, -1], [-1, 0, -1],
    [0, 1, 1], [0, -1, 1], [0, 1, -1], [0, -1, -1]
  ];

  function initNoise(seed) {
    var p = new Array(256);
    for (var i = 0; i < 256; i++) {
      p[i] = Math.floor(Math.abs(Math.sin(seed + i)) * 256);
    }
    for (var i = 0; i < 512; i++) {
      perm[i] = p[i & 255];
    }
  }

  // Função de Hash Determinístico para substituir Math.random()
  // Garante que a variação de cor seja idêntica nas bordas dos chunks
  function hash(x, z) {
    var sinX = Math.sin(x * 12.9898 + z * 78.233);
    return Math.abs(sinX - Math.floor(sinX));
  }

  function dot(g, x, y) {
    return g[0] * x + g[1] * y;
  }

  function noise2D(xin, yin) {
    var F2 = 0.5 * (Math.sqrt(3.0) - 1.0);
    var s = (xin + yin) * F2;
    var i = Math.floor(xin + s);
    var j = Math.floor(yin + s);
    var G2 = (3.0 - Math.sqrt(3.0)) / 6.0;
    var t = (i + j) * G2;
    var X0 = i - t;
    var Y0 = j - t;
    var x0 = xin - X0;
    var y0 = yin - Y0;

    var i1, j1;
    if (x0 > y0) { i1 = 1; j1 = 0; }
    else { i1 = 0; j1 = 1; }

    var x1 = x0 - i1 + G2;
    var y1 = y0 - j1 + G2;
    var x2 = x0 - 1.0 + 2.0 * G2;
    var y2 = y0 - 1.0 + 2.0 * G2;

    var ii = i & 255;
    var jj = j & 255;
    var gi0 = perm[ii + perm[jj]] % 12;
    var gi1 = perm[ii + i1 + perm[jj + j1]] % 12;
    var gi2 = perm[ii + 1 + perm[jj + 1]] % 12;

    var t0 = 0.5 - x0 * x0 - y0 * y0;
    var n0 = 0.0;
    if (t0 >= 0) {
      t0 *= t0;
      n0 = t0 * t0 * dot(grad3[gi0], x0, y0);
    }

    var t1 = 0.5 - x1 * x1 - y1 * y1;
    var n1 = 0.0;
    if (t1 >= 0) {
      t1 *= t1;
      n1 = t1 * t1 * dot(grad3[gi1], x1, y1);
    }

    var t2 = 0.5 - x2 * x2 - y2 * y2;
    var n2 = 0.0;
    if (t2 >= 0) {
      t2 *= t2;
      n2 = t2 * t2 * dot(grad3[gi2], x2, y2);
    }

    return 70.0 * (n0 + n1 + n2);
  }

  // noise wrappers com seeds fixas simuladas (offset)
  function getHumidity(x, z) {
    // Offset seed manualmente
    var val = noise2D(x / 600 + 1234, z / 600 + 1234);
    return (val + 1) * 0.5;
  }

  function getTerrainHeight(x, z) {
    // 1. Continental
    var continental = noise2D(x / 500, z / 500);
    // 2. Detail
    var detail = noise2D(x / 120, z / 120);
    // 3. Fine
    var fine = noise2D(x / 30, z / 30) * 0.2;

    var height = 0;
    if (continental < -0.4) {
      height = continental * 20; 
    } else if (continental < 0.1) {
      height = continental * 10;
    } else if (continental < 0.5) {
      height = 5 + (continental * 5) + (detail * 3);
    } else {
      var mountainFactor = (continental - 0.5) * 2;
      height = 15 + (mountainFactor * 60) + (detail * 10);
    }
    height += fine;
    return height;
  }

  self.onmessage = function(e) {
    try {
      var data = e.data;
      var type = data.type;
      
      initNoise(data.seed);
      var chunkSize = data.chunkSize || 64;
      var waterLevel = data.waterLevel || 4.0;

      if (type === 'chunk') {
          var worldX = data.x * chunkSize;
          var worldZ = data.z * chunkSize;
          var lodLevel = data.lodLevel || 1;

          var isHorizon = lodLevel >= 8;
          var segments = isHorizon ? 2 : Math.max(3, Math.floor(48 / lodLevel));
          
          var vertices = [];
          var colors = [];
          var normals = [];
          var indices = [];

          var chunkHasWater = false;
          var gridRowVertices = segments + 1;
          var segmentSize = chunkSize / segments;
          var eps = 1.0; 

          // Helper normais
          function calcNormal(px, pz) {
            var hL = getTerrainHeight(px - eps, pz);
            var hR = getTerrainHeight(px + eps, pz);
            var hD = getTerrainHeight(px, pz - eps);
            var hU = getTerrainHeight(px, pz + eps);
            var nx = hL - hR;
            var ny = 2.0 * eps;
            var nz = hD - hU;
            var len = Math.sqrt(nx*nx + ny*ny + nz*nz);
            return [nx/len, ny/len, nz/len];
          }

          for (var iz = 0; iz <= segments; iz++) {
            for (var ix = 0; ix <= segments; ix++) {
              var px = worldX + (ix * segmentSize);
              var pz = worldZ + (iz * segmentSize);
              
              var py = getTerrainHeight(px, pz);
              var humidity = getHumidity(px, pz);

              if (py <= waterLevel + 2.0) chunkHasWater = true;

              var localX = ix * segmentSize;
              var localZ = iz * segmentSize;

              vertices.push(localX, py, localZ);

              var n = calcNormal(px, pz);
              normals.push(n[0], n[1], n[2]);

              var r = 0, g = 0, b = 0;
              // Simple biome coloring
              if (py < waterLevel + 0.5) { r=0.57; g=0.49; b=0.38; } // Wet Sand
              else if (py < waterLevel + 3.5) { r=0.9; g=0.76; b=0.53; } // Sand
              else if (py > 55) { r=1; g=1; b=1; } // Snow
              else if (py > 35) { r=0.41; g=0.41; b=0.41; } // Rock
              else { 
                // Grass
                if (humidity < 0.3) { r=0.93; g=0.79; b=0.69; }
                else if (humidity < 0.55) { r=0.66; g=0.73; b=0.35; }
                else if (humidity < 0.75) { r=0.22; g=0.44; b=0.16; }
                else { r=0.1; g=0.27; b=0.07; }
                
                var tint = 0.9 + (py / 100) * 0.2;
                r*=tint; g*=tint; b*=tint;
              }
              
              // OTIMIZAÇÃO: Chunks distantes (Horizonte) não aplicam ruído de cor.
              // Isso evita o efeito de "shimmering" (cintilação) em pixels distantes
              // e economiza processamento.
              if (!isHorizon) {
                 var randomVal = hash(px, pz);
                 var noise = 0.95 + randomVal * 0.1;
                 r*=noise; g*=noise; b*=noise;
              } else {
                  // Para o horizonte, clareamos levemente para ajudar no blending com o fog
                  r = r * 0.9 + 0.1;
                  g = g * 0.9 + 0.1;
                  b = b * 0.9 + 0.1;
              }

              colors.push(r, g, b);
            }
          }

          for (var iz = 0; iz < segments; iz++) {
            for (var ix = 0; ix < segments; ix++) {
              var a = ix + gridRowVertices * iz;
              var b = ix + gridRowVertices * (iz + 1);
              var c = (ix + 1) + gridRowVertices * (iz + 1);
              var d = (ix + 1) + gridRowVertices * iz;
              indices.push(a, b, d);
              indices.push(b, c, d);
            }
          }

          var posArray = new Float32Array(vertices);
          var colArray = new Float32Array(colors);
          var normArray = new Float32Array(normals);
          var idxArray = new Uint16Array(indices);

          self.postMessage(
            { jobId: data.jobId, positions: posArray, colors: colArray, normals: normArray, indices: idxArray, hasWater: chunkHasWater },
            [posArray.buffer, colArray.buffer, normArray.buffer, idxArray.buffer]
          );

      } else if (type === 'minimap') {
          var size = 200; 
          var buffer = new Uint8ClampedArray(size * size * 4);
          var radius = data.radius || 120;
          var metersPerPixel = (radius * 2) / size;
          var startX = data.playerX - radius;
          var startZ = data.playerZ - radius;

          for (var y = 0; y < size; y++) {
              for (var x = 0; x < size; x++) {
                  var wx = startX + x * metersPerPixel;
                  var wz = startZ + y * metersPerPixel;

                  var h = getTerrainHeight(wx, wz);
                  var hum = getHumidity(wx, wz);
                  
                  // Cores hardcoded para evitar dependencias
                  var r=0, g=0, b=0; 
                  if (h < waterLevel) { r=40; g=90; b=180; }
                  else if (h < waterLevel + 1.5) { r=70; g=150; b=220; }
                  else if (h < waterLevel + 4.5) { r=235; g=215; b=140; }
                  else if (h > 55) { r=250; g=250; b=255; }
                  else if (h > 35) { r=140; g=140; b=140; }
                  else {
                      if (hum < 0.3) { r=235; g=215; b=140; }
                      else if (hum > 0.6) { r=50; g=120; b=40; }
                      else { r=100; g=190; b=80; }
                  }

                  var idx = (y * size + x) * 4;
                  // Mask circular
                  var dx = x - size/2; 
                  var dy = y - size/2;
                  var d = Math.sqrt(dx*dx + dy*dy);
                  var alpha = 255;
                  if (d > size/2) alpha = 0;

                  buffer[idx] = r; buffer[idx+1] = g; buffer[idx+2] = b; buffer[idx+3] = alpha;
              }
          }

          self.postMessage(
              { jobId: data.jobId, minimapBuffer: buffer },
              [buffer.buffer]
          );
      }
    } catch (err) {
      // Enviar erro de volta se houver
      self.postMessage({ jobId: e.data.jobId, error: err.toString() });
    }
  };
`;

class WorkerManager {
  private chunkWorker: Worker;
  private mapWorker: Worker;
  private chunkCallbacks: Map<string, (data: WorkerResponse) => void>;
  private mapCallbacks: Map<string, (data: WorkerResponse) => void>;

  constructor() {
    const blob = new Blob([workerCode], { type: 'application/javascript' });
    const blobUrl = URL.createObjectURL(blob);
    
    this.chunkWorker = new Worker(blobUrl);
    this.mapWorker = new Worker(blobUrl);
    
    this.chunkCallbacks = new Map();
    this.mapCallbacks = new Map();

    this.chunkWorker.onmessage = (e) => {
      const { jobId, error } = e.data;
      if (error) console.error("Chunk Worker Error:", error);
      
      if (this.chunkCallbacks.has(jobId)) {
        this.chunkCallbacks.get(jobId)!(e.data);
        this.chunkCallbacks.delete(jobId);
      }
    };

    this.mapWorker.onmessage = (e) => {
        const { jobId, error } = e.data;
        if (error) console.error("Map Worker Error:", error);

        if (this.mapCallbacks.has(jobId)) {
          this.mapCallbacks.get(jobId)!(e.data);
          this.mapCallbacks.delete(jobId);
        }
    };
  }

  public generateChunk(x: number, z: number, lodLevel: number): Promise<WorkerResponse> {
    const jobId = `${x}_${z}_${lodLevel}`;
    return new Promise((resolve) => {
      this.chunkCallbacks.set(jobId, resolve);
      this.chunkWorker.postMessage({
        type: 'chunk',
        x, z, lodLevel,
        seed: WORLD_SEED,
        chunkSize: CHUNK_SIZE,
        waterLevel: WATER_LEVEL,
        jobId
      });
    });
  }

  public generateMinimap(playerX: number, playerZ: number, radius: number): Promise<WorkerResponse> {
    const jobId = `mm_${Math.floor(playerX)}_${Math.floor(playerZ)}`;
    return new Promise((resolve) => {
        this.mapCallbacks.set(jobId, resolve);
        this.mapWorker.postMessage({
            type: 'minimap',
            x: 0, z: 0, 
            seed: WORLD_SEED,
            chunkSize: CHUNK_SIZE, 
            waterLevel: WATER_LEVEL,
            playerX, playerZ, radius,
            jobId
        });
    });
  }
}

export const workerManager = new WorkerManager();
