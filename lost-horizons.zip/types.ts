
export interface Vector3 {
  x: number;
  y: number;
  z: number;
}

export interface PlayerState {
  position: Vector3;
  rotation: { phi: number; theta: number }; // Camera angles
  seed: number;
  chapter: number; // 0 a 10
  questPhase: 'seek_npc' | 'mission_active';
  gameMode: 'exploration' | 'story'; // NOVO: Controla o fluxo do jogo
}

export interface DropData {
  id: string;
  type: 'wood' | 'stone';
  position: Vector3;
}

export interface GameSaveData {
  player: PlayerState;
  timestamp: number;
}

export interface WorkerResponse {
  jobId: string;
  positions?: Float32Array;
  colors?: Float32Array;
  normals?: Float32Array;
  indices?: Uint16Array;
  hasWater?: boolean;
  minimapBuffer?: Uint8ClampedArray;
  error?: string;
}

export interface Mission {
  id: number;
  target: Vector3;
  description: string;
  completed: boolean;
  variant: 'beacon' | 'crystal' | 'monolith' | 'artifact';
}

export interface StoryChapter {
  id: number;
  title: string;
  npcName: string;
  dialog: string[]; // Array de strings para parágrafos
  objectiveDescription: string;
  objectVariant: 'beacon' | 'crystal' | 'monolith' | 'artifact';
  timeMultiplier: number; // Dificuldade de tempo (1.0 = normal, 0.8 = difícil)
}

// Configuration Constants
export const CHUNK_SIZE = 64; // Size of one terrain tile in world units

// OTIMIZAÇÃO: 12 é o "Sweet Spot" para WebGL. 
export const RENDER_DISTANCE = 12; 

export const WORLD_SEED = 12345;
export const AUTO_SAVE_INTERVAL = 10000; // ms
export const WATER_LEVEL = 4.0; // Altura global da água

// Configurações da Vila
export const VILLAGE_GRID_SIZE = 280; 
export const VILLAGE_CHANCE = 0.6; 
export const HOUSE_RADIUS = 5;

// Configurações de Vegetação
// OTIMIZAÇÃO: Aumentado de 12 para 15 para reduzir overdraw próximo sem perder o feeling de floresta
export const VEGETATION_STEP_HIGH = 15; 
export const VEGETATION_STEP_LOW = 45;

export interface HouseData {
  x: number; z: number; y: number; rot: number; radius: number;
}

export interface VillageObjectData {
  type: 'well' | 'lamp' | 'campfire' | 'bench' | 'dock' | 'boat' | 'quest_board' | 'npc';
  x: number; z: number; y: number; rot: number;
}
