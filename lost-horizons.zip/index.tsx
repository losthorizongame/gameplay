
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';

// --- HACK: Ocultar aviso inofensivo do R3F ---
const originalError = console.error;
console.error = (...args) => {
  // Se o erro conter a frase específica do R3F, ignoramos
  if (typeof args[0] === 'string' && args[0].includes('Text is not allowed in the R3F tree')) {
    return;
  }
  // Caso contrário, exibe o erro normalmente
  originalError(...args);
};
// ----------------------------------------------

const rootElement = document.getElementById('root');
if (!rootElement) throw new Error('Failed to find the root element');

const root = ReactDOM.createRoot(rootElement);
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
