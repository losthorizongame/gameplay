
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Html } from '@react-three/drei';
import * as THREE from 'three';

import Player from './components/Player';
import WorldManager from './components/WorldManager';
import HUD from './components/HUD';
import MiniMap from './components/MiniMap';
import Environment from './components/Environment'; 
import PostFX from './components/PostFX'; 
import BirdFlock from './components/BirdFlock'; 
import AncientBeacon from './components/AncientBeacon'; 
import StoryNPC from './components/StoryNPC';
import ObjectiveMarker from './components/ObjectiveMarker';

import { saveSystem } from './services/SaveSystem';
import { initNoise, findSafeSpawnPosition, getVillageData, findNearestVillage, getTerrainHeight } from './services/MathUtils';
import { generateNextMissionPosition } from './services/MissionGenerator';
import { PlayerState, WORLD_SEED, Mission, Vector3, StoryChapter } from './types';
import { WaterGlobals } from './components/Water';

const MUSIC_URL = "https://raw.githubusercontent.com/sypherOS-XXI/worldgenerator/main/Horizonte%20Sem%20Fim.mp3";
const FAIL_SOUND_URL = "https://raw.githubusercontent.com/sypherOS-XXI/worldgenerator/main/wind_howl.mp3"; 

const OBJECTIVES_PER_CHAPTER = 3;

// --- DADOS DA HISTÓRIA (10 CAPÍTULOS) ---
const STORY_CHAPTERS: StoryChapter[] = [
    { id: 0, title: "O Despertar", npcName: "O Observador", dialog: ["As sombras estão se movendo.", "Os Antigos construíram estes faróis para nos proteger. Mas eles estão apagando.", "Acenda 3 faróis sagrados ao redor desta região para estabilizar a barreira inicial."], objectiveDescription: "Acenda os 3 Faróis", objectVariant: 'beacon', timeMultiplier: 1.0 },
    { id: 1, title: "Ecos do Norte", npcName: "O Viajante", dialog: ["Bom vê-lo vivo. A primeira barreira segurou, mas a corrupção vem do Norte.", "Existe uma falha tectônica onde cristais de energia brotam.", "Encontre e ative os Cristais de Ressonância."], objectiveDescription: "Ative os Cristais", objectVariant: 'crystal', timeMultiplier: 1.0 },
    { id: 2, title: "O Vale Esquecido", npcName: "O Eremita", dialog: ["Poucos chegam tão longe.", "Este vale guarda monólitos antigos. Eles cantam quando o vento sopra.", "Precisamos silenciá-los antes que a Sombra os ouça."], objectiveDescription: "Toque os Monólitos", objectVariant: 'monolith', timeMultiplier: 0.9 },
    { id: 3, title: "Águas Profundas", npcName: "A Guardiã do Rio", dialog: ["A água carrega memórias... e perigos.", "Artefatos dourados foram perdidos nas ilhas.", "Recupere-os rapidamente, a maré está subindo."], objectiveDescription: "Recupere os Artefatos", objectVariant: 'artifact', timeMultiplier: 0.9 },
    { id: 4, title: "A Chama Eterna", npcName: "O Ferreiro", dialog: ["Precisamos de fogo. Fogo verdadeiro.", "Os faróis desta região são diferentes. Eles queimam com alma.", "Não deixe a chama morrer."], objectiveDescription: "Reacenda as Chamas", objectVariant: 'beacon', timeMultiplier: 0.8 },
    { id: 5, title: "Ventos Cortantes", npcName: "O Observador", dialog: ["Você voltou. A situação piorou.", "Os cristais nas montanhas estão instáveis.", "Suba e estabilize-os. Cuidado com a queda."], objectiveDescription: "Estabilize os Picos", objectVariant: 'crystal', timeMultiplier: 0.8 },
    { id: 6, title: "Sombras Dançantes", npcName: "O Vulto", dialog: ["Eles estão vindo...", "Rápido. Os monólitos negros. Eles são a chave da prisão.", "Selo-os agora!"], objectiveDescription: "Sele os Monólitos", objectVariant: 'monolith', timeMultiplier: 0.7 },
    { id: 7, title: "A Corrida do Ouro", npcName: "O Mercador", dialog: ["Não me importo com sombras, mas deixei minha carga para trás!", "Recupere meus artefatos e talvez o mundo sobreviva mais um dia."], objectiveDescription: "Salve a Carga", objectVariant: 'artifact', timeMultiplier: 0.7 },
    { id: 8, title: "A Última Defesa", npcName: "O General", dialog: ["Esta é a linha final.", "Todos os faróis restantes devem ser acesos simultaneamente.", "Corra como se sua vida dependesse disso. Porque depende."], objectiveDescription: "Acenda a Linha Final", objectVariant: 'beacon', timeMultiplier: 0.6 },
    { id: 9, title: "O Coração do Mundo", npcName: "O Observador", dialog: ["Chegamos ao fim.", "O núcleo da Sombra está exposto.", "Ative os Cristais Primordiais e bana a escuridão para sempre!"], objectiveDescription: "Bana a Escuridão", objectVariant: 'crystal', timeMultiplier: 0.6 },
];

const getObjectName = (variant: string) => {
    switch(variant) {
        case 'beacon': return 'Faróis';
        case 'crystal': return 'Cristais';
        case 'monolith': return 'Monólitos';
        case 'artifact': return 'Artefatos';
        default: return 'Objetivos';
    }
}

const SplashScreen = ({ onStart, hasSave }: { onStart: () => void, hasSave: boolean }) => {
  return (
    <div className="absolute inset-0 bg-black z-[100] flex flex-col items-center justify-center animate-in fade-in duration-700">
       <div className="text-center space-y-8">
          <h1 className="text-8xl font-black tracking-tighter text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-pink-500 to-red-500 drop-shadow-[0_0_15px_rgba(168,85,247,0.5)] animate-pulse">
            LOST HORIZONS
          </h1>
          <p className="text-gray-500 font-mono tracking-widest text-sm uppercase">Uma Jornada de Exploração</p>
          
          <button 
            onClick={onStart}
            className="mt-12 px-12 py-4 border border-white/20 bg-white/5 hover:bg-white/20 text-white font-bold tracking-widest rounded-full transition-all duration-300 hover:scale-110 hover:shadow-[0_0_30px_rgba(255,255,255,0.2)]"
          >
            {hasSave ? "CONTINUAR JORNADA" : "INICIAR JOGO"}
          </button>
       </div>
    </div>
  );
};

const FPSCounter = ({ onUpdate }: { onUpdate: (fps: number) => void }) => {
  const frames = useRef(0);
  const prevTime = useRef(performance.now());
  
  useFrame(() => {
    frames.current++;
    const time = performance.now();
    if (time >= prevTime.current + 1000) {
      onUpdate(Math.round((frames.current * 1000) / (time - prevTime.current)));
      frames.current = 0;
      prevTime.current = time;
    }
  });
  return null;
};

// --- GAME LOGIC MANAGER ---
const GameManager = ({ 
  playerPos, 
  mission, 
  timeLeft, 
  gameState,
  isMissionActive,
  onComplete, 
  onFail,
  onDistanceUpdate,
  onTimeUpdate
}: { 
  playerPos: THREE.Vector3, 
  mission: Mission | null, 
  timeLeft: number,
  gameState: 'playing' | 'failed' | 'success',
  isMissionActive: boolean,
  onComplete: () => void,
  onFail: () => void,
  onDistanceUpdate: (d: number) => void,
  onTimeUpdate: (dt: number) => void
}) => {
    useFrame((state, delta) => {
        if (!isMissionActive || !mission || gameState !== 'playing') return;
        
        // 1. Mission Distance Check
        const target = new THREE.Vector3(mission.target.x, mission.target.y, mission.target.z);
        const dist2d = Math.sqrt((playerPos.x - target.x)**2 + (playerPos.z - target.z)**2);
        const dist3d = playerPos.distanceTo(target);

        onDistanceUpdate(dist3d);

        // Win Condition
        if (dist2d < 6.0) {
            onComplete();
            return;
        }

        // 2. Time Management
        if (timeLeft > 0) {
            onTimeUpdate(delta);
        } else {
            onFail();
        }
    });
    return null;
}

const App: React.FC = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [showSplash, setShowSplash] = useState(true);
  const [playerPos, setPlayerPos] = useState<THREE.Vector3>(new THREE.Vector3(0,30,0));
  const [playerRot, setPlayerRot] = useState(0); 
  const [speed, setSpeed] = useState(0);
  const [fps, setFps] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [isUnderwater, setIsUnderwater] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [hasSaveFile, setHasSaveFile] = useState(false);

  // --- STORY & MODE STATE ---
  const [gameMode, setGameMode] = useState<'exploration' | 'story'>('exploration');
  const [currentChapter, setCurrentChapter] = useState(0);
  const [questPhase, setQuestPhase] = useState<'seek_npc' | 'mission_active'>('seek_npc');
  const [npcLocation, setNpcLocation] = useState<THREE.Vector3>(new THREE.Vector3(0,0,0));
  
  // --- MISSION STATE ---
  const [gameState, setGameState] = useState<'playing' | 'failed' | 'success'>('playing');
  const [currentMission, setCurrentMission] = useState<Mission | null>(null);
  const [completedBeacons, setCompletedBeacons] = useState<Vector3[]>([]); 
  const [missionDistance, setMissionDistance] = useState<number>(0);
  const [showMissionSuccess, setShowMissionSuccess] = useState(false);
  const [beaconsLitCount, setBeaconsLitCount] = useState(0);
  const [showNPCDialog, setShowNPCDialog] = useState(false);
  const [showGameCompleted, setShowGameCompleted] = useState(false);

  // Time Attack State
  const [timeLeft, setTimeLeft] = useState<number>(0);
  const [maxTime, setMaxTime] = useState<number>(1);
  const [lastSafePos, setLastSafePos] = useState<THREE.Vector3>(new THREE.Vector3(0,30,0)); // Checkpoint

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const fadeIntervalRef = useRef<number | null>(null);

  // --- INITIALIZATION ---
  useEffect(() => {
    const audio = new Audio(MUSIC_URL);
    audio.loop = true;
    audio.volume = 0.4; 
    audio.muted = isMuted;
    audioRef.current = audio;

    const init = async () => {
      await saveSystem.init();
      const savedData = await saveSystem.load();
      initNoise(WORLD_SEED);
      
      let initialPos;
      
      if (savedData && savedData.player) {
        setHasSaveFile(true);
        initialPos = new THREE.Vector3(savedData.player.position.x, savedData.player.position.y, savedData.player.position.z);
        setPlayerPos(initialPos);
        setLastSafePos(initialPos);
        
        // Carrega estado da história e modo de jogo
        setCurrentChapter(savedData.player.chapter || 0);
        setQuestPhase(savedData.player.questPhase || 'seek_npc');
        setGameMode(savedData.player.gameMode || 'exploration');
        
        // Define a localização do NPC
        // Se estiver em modo exploração, o NPC está na vila mais próxima (como doador de missão)
        // Se estiver em modo história (seek_npc), o NPC está na vila alvo.
        const nearest = findNearestVillage(initialPos.x, initialPos.z, 0);
        if (nearest) setNpcLocation(new THREE.Vector3(nearest.x, nearest.y + 1, nearest.z));

      } else {
        // NEW GAME - Começa em Exploração
        const startVillage = getVillageData(0, 0);
        if (startVillage) {
            initialPos = new THREE.Vector3(startVillage.x - 10, startVillage.h + 2, startVillage.z + 10);
            setNpcLocation(new THREE.Vector3(startVillage.x + 5, startVillage.h + 1, startVillage.z + 5));
        } else {
            const spawn = findSafeSpawnPosition();
            initialPos = new THREE.Vector3(spawn.x, spawn.y, spawn.z);
            setNpcLocation(new THREE.Vector3(spawn.x + 5, spawn.y, spawn.z + 5));
        }
        setPlayerPos(initialPos);
        setLastSafePos(initialPos);
        setCurrentChapter(0);
        setQuestPhase('seek_npc');
        setGameMode('exploration'); // Padrão
      }
      
      setIsLoading(false);
    };
    init();

    const onLockChange = () => {
      if (document.pointerLockElement === null) {
         setIsPlaying(false);
         if (!showNPCDialog && !showGameCompleted) playMenuMusic(); 
      } else {
         setIsPlaying(true);
         fadeOutGameMusic();
      }
    };
    
    document.addEventListener('pointerlockchange', onLockChange);
    return () => {
        document.removeEventListener('pointerlockchange', onLockChange);
        if (audioRef.current) { audioRef.current.pause(); audioRef.current = null; }
        if (fadeIntervalRef.current) clearInterval(fadeIntervalRef.current);
    };
  }, []);

  useEffect(() => {
      if (audioRef.current) audioRef.current.muted = isMuted;
  }, [isMuted]);

  // --- AUDIO HELPERS ---
  const playMenuMusic = useCallback(() => {
    if (!audioRef.current) return;
    if (fadeIntervalRef.current) { clearInterval(fadeIntervalRef.current); fadeIntervalRef.current = null; }
    audioRef.current.volume = 0.4;
    audioRef.current.play().catch(() => {});
  }, []);

  const fadeOutGameMusic = useCallback(() => {
    if (!audioRef.current) return;
    if (fadeIntervalRef.current) clearInterval(fadeIntervalRef.current);
    fadeIntervalRef.current = window.setInterval(() => {
        if (audioRef.current && audioRef.current.volume > 0.05) {
            audioRef.current.volume -= 0.05;
        } else {
            if (audioRef.current) audioRef.current.pause();
            if (fadeIntervalRef.current) { clearInterval(fadeIntervalRef.current); fadeIntervalRef.current = null; }
        }
    }, 200);
  }, []);

  // --- STORY LOGIC ---

  const startNextObjective = useCallback((startPos: THREE.Vector3, objectiveIndex: number) => {
      const nextTarget = generateNextMissionPosition(startPos);
      const chapter = STORY_CHAPTERS[currentChapter];
      const dist = startPos.distanceTo(nextTarget);
      
      // Dificuldade baseada no multiplicador do capítulo
      const baseTime = (dist / 22.0) * 1.5 + 15; 
      const adjustedTime = baseTime * (chapter?.timeMultiplier || 1.0);

      setCurrentMission({
          id: objectiveIndex,
          target: nextTarget,
          description: chapter?.objectiveDescription || "Objetivo",
          completed: false,
          variant: chapter?.objectVariant || 'beacon'
      });
      
      setMaxTime(adjustedTime);
      setTimeLeft(adjustedTime);
      setGameState('playing');
  }, [currentChapter]);

  const handleStartQuest = useCallback(() => {
      // Se estiver em modo exploração, muda para história
      if (gameMode === 'exploration') {
          setGameMode('story');
          setCurrentChapter(0);
      }

      setBeaconsLitCount(0);
      setQuestPhase('mission_active');
      setShowNPCDialog(false);
      startNextObjective(playerPos, 1);
      
      const canvas = document.querySelector('#game-canvas canvas') as HTMLCanvasElement;
      canvas?.requestPointerLock();
  }, [playerPos, startNextObjective, gameMode]);

  const handleMissionComplete = useCallback(() => {
     if (!currentMission) return;
     
     // 1. Checkpoint & Visuals
     const targetPos = new THREE.Vector3(currentMission.target.x, currentMission.target.y, currentMission.target.z);
     setCompletedBeacons(prev => [...prev, currentMission.target]);
     setLastSafePos(targetPos);
     setShowMissionSuccess(true);
     setTimeout(() => setShowMissionSuccess(false), 3000);

     const newCount = beaconsLitCount + 1;
     setBeaconsLitCount(newCount);

     if (newCount >= OBJECTIVES_PER_CHAPTER) {
         // --- CAPÍTULO CONCLUÍDO ---
         setCompletedBeacons([]); // Limpa os beacons visuais para o próx capitulo
         
         if (currentChapter >= STORY_CHAPTERS.length - 1) {
             // FIM DA HISTÓRIA COMPLETA
             setShowGameCompleted(true);
             document.exitPointerLock();
         } else {
             // PREPARAR PRÓXIMO CAPÍTULO
             const nextChapterIdx = currentChapter + 1;
             setCurrentChapter(nextChapterIdx);
             setQuestPhase('seek_npc');
             setCurrentMission(null); // Remove missão ativa
             
             // Calcular Onde está o próximo NPC (Vila mais próxima do ponto final da missão)
             // minDistance 300 garante que não seja a mesma vila se estiver perto
             const nextVillage = findNearestVillage(targetPos.x, targetPos.z, 300);
             if (nextVillage) {
                 setNpcLocation(new THREE.Vector3(nextVillage.x, nextVillage.y + 1, nextVillage.z));
             }
             
             // Auto Save
             saveSystem.save({
                 position: targetPos,
                 rotation: { phi: 0, theta: playerRot },
                 seed: WORLD_SEED,
                 chapter: nextChapterIdx,
                 questPhase: 'seek_npc',
                 gameMode: 'story'
             });
         }
     } else {
         // PRÓXIMO OBJETIVO DO MESMO CAPÍTULO
         startNextObjective(targetPos, currentMission.id + 1);
     }
  }, [currentMission, beaconsLitCount, currentChapter, playerRot, startNextObjective]);

  const handleMissionFail = useCallback(() => {
      setGameState('failed');
      const failAudio = new Audio(FAIL_SOUND_URL); 
      if (!isMuted) { failAudio.volume = 0.5; failAudio.play().catch(() => {}); }

      setTimeout(() => {
          const respawnPos = lastSafePos.clone();
          respawnPos.y += 5; 
          setPlayerPos(respawnPos);
          if (currentMission) {
               const dist = respawnPos.distanceTo(currentMission.target);
               const estimatedTime = (dist / 22.0) * 1.5 + 15;
               setMaxTime(estimatedTime);
               setTimeLeft(estimatedTime);
          }
          setGameState('playing');
      }, 3000);
  }, [lastSafePos, currentMission, isMuted]);

  const handleTimeUpdate = useCallback((dt: number) => {
      // Tempo só conta no modo história
      if (gameMode === 'story') {
          setTimeLeft(prev => Math.max(0, prev - dt));
      }
  }, [gameMode]);

  // --- INTERACTIONS ---
  const handleInteractNPC = useCallback(() => {
      // Checa distância para o NPC atual (já que agora ele é móvel)
      const dist = playerPos.distanceTo(npcLocation);
      if (dist < 8.0) {
          document.exitPointerLock();
          setShowNPCDialog(true);
      }
  }, [playerPos, npcLocation]);

  const handleStartGame = () => {
    if(showGameCompleted) return;
    const canvas = document.querySelector('#game-canvas canvas') as HTMLCanvasElement;
    if (document.pointerLockElement === canvas) return;
    canvas?.focus();
    // @ts-ignore
    canvas?.requestPointerLock();
  };

  // --- VOLTAR PARA EXPLORAÇÃO (FIM DA HISTÓRIA) ---
  const handleBackToExploration = async () => {
      // Resetar para modo exploração, mas mantendo posição
      setGameMode('exploration');
      setQuestPhase('seek_npc'); // Reseta NPC para atuar como quest giver
      setCurrentMission(null);
      setCompletedBeacons([]);
      setShowGameCompleted(false);
      setGameState('playing');
      
      // Save soft (sem apagar DB)
      await saveSystem.save({
          position: playerPos,
          rotation: { phi: 0, theta: playerRot },
          seed: WORLD_SEED,
          chapter: 0,
          questPhase: 'seek_npc',
          gameMode: 'exploration'
      });
      
      // Recomeçar
      handleStartGame();
  };

  // Renderização Dinâmica do Diálogo
  const getDialogContent = () => {
      if (gameMode === 'exploration') {
          return {
              name: "O Viajante Misterioso",
              title: "INICIAR SAGA",
              dialog: [
                  "Saudações, explorador. O mundo é vasto e belo, mas sombras antigas espreitam.",
                  "Tenho ouvido rumores sobre faróis se apagando e monólitos despertando.",
                  "Se desejar enfrentar este desafio, aceitarei sua ajuda. Caso contrário, continue sua jornada em paz."
              ],
              button: "Aceitar Desafio (Modo História)"
          };
      }
      return {
          name: currentChapterData.npcName,
          title: `CAPÍTULO ${currentChapter + 1}/10`,
          dialog: currentChapterData.dialog,
          button: "Aceitar Missão"
      };
  };

  const currentChapterData = STORY_CHAPTERS[currentChapter];
  const dialogContent = getDialogContent();

  if (isLoading) return <div className="bg-black text-white h-screen flex items-center justify-center font-mono">Carregando mundo procedural...</div>;
  if (showSplash) return <SplashScreen onStart={() => { playMenuMusic(); setShowSplash(false); }} hasSave={hasSaveFile} />;

  return (
    <>
      <Canvas
        id="game-canvas" 
        shadows={{ type: THREE.PCFSoftShadowMap }}
        camera={{ fov: 70, near: 0.5, far: 1500 }}
        dpr={[1, 1.5]}
        gl={{ powerPreference: "high-performance", antialias: false }}
      >
        <FPSCounter onUpdate={setFps} />
        <color attach="background" args={[gameState === 'failed' && gameMode === 'story' ? '#000000' : '#87CEEB']} />
        
        <Environment playerPos={playerPos} isUnderwater={isUnderwater} />
        <WaterGlobals />
        <WorldManager playerPosition={playerPos} />
        <BirdFlock playerPos={playerPos} />
        
        {/* BEACONS CONCLUÍDOS (Só mostra se estiver no modo história) */}
        {gameMode === 'story' && questPhase === 'mission_active' && completedBeacons.map((pos, idx) => (
             <AncientBeacon 
                key={`completed_${idx}`} 
                position={new THREE.Vector3(pos.x, pos.y, pos.z)} 
                isLit={true} 
                isNext={false}
                variant={currentChapterData.objectVariant}
             />
        ))}

        {/* BEACON ATUAL (Só mostra se estiver no modo história) */}
        {gameMode === 'story' && questPhase === 'mission_active' && currentMission && (
            <AncientBeacon 
                key={`current_${currentMission.id}`}
                position={new THREE.Vector3(currentMission.target.x, currentMission.target.y, currentMission.target.z)}
                isLit={false}
                isNext={true}
                variant={currentChapterData.objectVariant}
            />
        )}

        {/* NPC DINÂMICO DA HISTÓRIA 
            - Aparece sempre no modo Exploração (como Quest Giver)
            - Aparece na fase seek_npc do modo História
        */}
        {(gameMode === 'exploration' || (gameMode === 'story' && questPhase === 'seek_npc')) && (
             <StoryNPC 
                position={npcLocation} 
                onClick={handleInteractNPC} 
                isInteractable={true}
            />
        )}

        {/* Marcador visual 3D (Feixe) - APENAS EM MODO HISTÓRIA */}
        {gameMode === 'story' && questPhase === 'seek_npc' && (
             <ObjectiveMarker position={npcLocation} />
        )}

        <GameManager 
            playerPos={playerPos} 
            mission={currentMission} 
            timeLeft={timeLeft}
            gameState={gameState}
            isMissionActive={gameMode === 'story' && questPhase === 'mission_active'}
            onComplete={handleMissionComplete} 
            onFail={handleMissionFail}
            onDistanceUpdate={setMissionDistance}
            onTimeUpdate={handleTimeUpdate}
        />

        <Player 
          initialState={{ 
              position: playerPos, 
              rotation: { phi: 0, theta: playerRot }, 
              seed: WORLD_SEED,
              chapter: currentChapter,
              questPhase: questPhase,
              gameMode: gameMode
          }}
          isLocked={isPlaying && gameState === 'playing' && !showNPCDialog && !showGameCompleted}
          isMuted={isMuted}
          onUnderwaterChange={setIsUnderwater}
          onPositionChange={setPlayerPos}
          onRotationChange={setPlayerRot}
          onStatsUpdate={(s) => setSpeed(s)}
          onAutoSave={(state) => saveSystem.save(state)}
          onAttack={() => {}}
          onInteractNPC={handleInteractNPC}
        />
        <PostFX />
      </Canvas>
      
      <HUD 
        isPlaying={isPlaying} 
        onStart={handleStartGame}
        position={playerPos}
        speed={speed}
        fps={fps}
        hasSave={true}
        isMuted={isMuted}
        toggleMute={() => setIsMuted(prev => !prev)}
        // OTIMIZAÇÃO DE EXPERIÊNCIA: Mostra a distância para a Vila ou para o Beacon dependendo da fase
        missionDistance={questPhase === 'mission_active' ? missionDistance : playerPos.distanceTo(npcLocation)}
        timeLeft={timeLeft}
        maxTime={maxTime}
        gameState={gameState}
        isMissionActive={gameMode === 'story' && questPhase === 'mission_active'}
        questPhase={questPhase}
        beaconsLit={beaconsLitCount}
        totalObjectives={OBJECTIVES_PER_CHAPTER}
        objectName={getObjectName(currentChapterData.objectVariant)}
        gameMode={gameMode}
      />
      
      {/* DIALOGO DA HISTÓRIA / QUEST GIVER */}
      {showNPCDialog && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/80 z-[60] backdrop-blur-sm animate-in fade-in duration-300">
              <div className="w-[800px] bg-gray-900 border border-purple-500/50 p-8 rounded-lg shadow-[0_0_50px_rgba(168,85,247,0.3)] text-purple-100 font-serif relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-64 h-64 bg-purple-600/10 blur-[80px] rounded-full pointer-events-none" />
                  <div className="flex gap-8">
                      <div className="w-48 h-64 bg-black/50 border border-purple-500/20 flex items-center justify-center shrink-0">
                          <div className="text-6xl animate-pulse">🔮</div>
                      </div>
                      <div className="flex flex-col">
                          <div className="flex justify-between items-baseline mb-2">
                              <h2 className="text-3xl font-bold text-purple-400 uppercase tracking-widest">{dialogContent.name}</h2>
                              <span className="text-xs font-mono text-purple-500/50">{dialogContent.title}</span>
                          </div>
                          <div className="h-px w-full bg-gradient-to-r from-purple-500 to-transparent mb-6" />
                          <div className="space-y-4 text-lg leading-relaxed text-gray-300">
                              {dialogContent.dialog.map((text, i) => (
                                  <p key={i}>{text}</p>
                              ))}
                          </div>
                          <div className="mt-8 flex gap-4">
                              <button onClick={handleStartQuest} className="px-8 py-3 bg-purple-600 hover:bg-purple-500 text-white font-bold tracking-widest uppercase rounded transition-all hover:scale-105 shadow-[0_0_20px_rgba(168,85,247,0.5)]">
                                  {dialogContent.button}
                              </button>
                              {/* Botão de recusar apenas no modo exploração */}
                              {gameMode === 'exploration' && (
                                  <button onClick={() => { setShowNPCDialog(false); handleStartGame(); }} className="px-8 py-3 border border-gray-600 hover:bg-gray-800 text-gray-300 font-bold tracking-widest uppercase rounded transition-all">
                                      Ainda não
                                  </button>
                              )}
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      )}

      {/* FEEDBACK DE SUCESSO DE MISSÃO */}
      {showMissionSuccess && (
          <div className="absolute top-1/3 left-1/2 transform -translate-x-1/2 -translate-y-1/2 pointer-events-none z-50 text-center w-full">
               <h1 className="text-7xl font-black text-orange-500 drop-shadow-[0_0_30px_rgba(255,100,0,0.8)] animate-in zoom-in duration-500 tracking-tighter uppercase stroke-black mb-4">
                   OBJETIVO ALCANÇADO
               </h1>
          </div>
      )}

      {/* TELA DE HISTÓRIA CONCLUÍDA */}
      {showGameCompleted && (
          <div className="absolute inset-0 bg-white/95 z-[100] flex flex-col items-center justify-center animate-in fade-in duration-2000 text-center p-12">
               <h1 className="text-9xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-orange-600 mb-8 drop-shadow-xl tracking-tighter">
                   HISTÓRIA CONCLUÍDA
               </h1>
               <div className="h-2 w-48 bg-gray-900 mb-12" />
               <p className="text-3xl text-gray-800 font-serif max-w-4xl leading-relaxed">
                   "Com a ativação do último cristal, a Sombra Viva recua para as profundezas do cosmos. As vilas voltam a prosperar sob a luz dos faróis e o silêncio dos monólitos."
               </p>
               <p className="mt-12 text-xl font-bold text-gray-500 uppercase tracking-[0.5em]">
                   Parabéns por completar esta saga
               </p>
               <button onClick={handleBackToExploration} className="mt-16 px-8 py-4 border-2 border-gray-900 text-gray-900 font-black uppercase hover:bg-gray-900 hover:text-white transition-colors">
                   Voltar a Explorar
               </button>
          </div>
      )}

      {/* MENSAGEM DE "BUSQUE A VILA" */}
      {((gameMode === 'story' && questPhase === 'seek_npc') || gameMode === 'exploration') && isPlaying && !showNPCDialog && !showGameCompleted && (
          <div className="absolute bottom-32 left-1/2 transform -translate-x-1/2 pointer-events-none z-40">
               <div className={`px-6 py-3 rounded-full backdrop-blur-md animate-pulse border ${gameMode === 'story' ? 'bg-black/60 text-yellow-400 border-yellow-500/30' : 'bg-green-900/60 text-green-300 border-green-500/30'}`}>
                   {gameMode === 'story' ? "Siga o feixe de luz gigante até a próxima vila para continuar" : "Explore o mundo ou siga o ponto vermelho no radar para encontrar missões"}
               </div>
          </div>
      )}

      {isPlaying && gameState === 'playing' && (
          <MiniMap 
              playerPos={playerPos} 
              playerRot={playerRot} 
              // Passa a posição do NPC apenas no modo exploração para desenhar o ponto vermelho
              npcPos={gameMode === 'exploration' ? npcLocation : undefined} 
          />
      )}
    </>
  );
};

export default App;
