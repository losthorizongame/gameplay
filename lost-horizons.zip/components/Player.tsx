
import React, { useRef, useEffect, useState } from 'react';
import { useThree, useFrame } from '@react-three/fiber';
import { Html } from '@react-three/drei';
import * as THREE from 'three';
import { getTerrainHeight, getVillageContent, checkVegetationCollision, getPlatformHeight } from '../services/MathUtils';
import { PlayerState, AUTO_SAVE_INTERVAL, WATER_LEVEL, CHUNK_SIZE, VILLAGE_GRID_SIZE, WORLD_SEED } from '../types';
import { BoatMesh } from './VillageObjects';

// URLs de Áudio
const WALK_SOUND_URL = "https://raw.githubusercontent.com/sypherOS-XXI/worldgenerator/main/andando_gramado.mp3";
const RUN_SOUND_URL = "https://raw.githubusercontent.com/sypherOS-XXI/worldgenerator/main/correndo_gramado.mp3";
const ROCK_WALK_SOUND_URL = "https://raw.githubusercontent.com/sypherOS-XXI/worldgenerator/main/piso_de_pedra_andando.mp3";
const ROCK_RUN_SOUND_URL = "https://raw.githubusercontent.com/sypherOS-XXI/worldgenerator/main/piso_de_pedra_correndo.mp3";
const SAND_WALK_SOUND_URL = "https://raw.githubusercontent.com/sypherOS-XXI/worldgenerator/main/andando_areia.mp3";
const SAND_RUN_SOUND_URL = "https://raw.githubusercontent.com/sypherOS-XXI/worldgenerator/main/correndo_areia.mp3";
const WATER_SOUND_URL = "https://raw.githubusercontent.com/sypherOS-XXI/worldgenerator/main/rio.mp3";

// --- SONS DO BARCO ---
const BOAT_IDLE_URL = "https://raw.githubusercontent.com/sypherOS-XXI/worldgenerator/main/barco_parado.mp3";
const BOAT_START_URL = "https://raw.githubusercontent.com/sypherOS-XXI/worldgenerator/main/barco_partindo.mp3";
const BOAT_CRUISE_URL = "https://raw.githubusercontent.com/sypherOS-XXI/worldgenerator/main/barco_andando.mp3";

interface PlayerProps {
  initialState?: PlayerState;
  onPositionChange: (pos: THREE.Vector3) => void;
  onRotationChange: (rot: number) => void; 
  onStatsUpdate: (speed: number, grounded: boolean) => void;
  onUnderwaterChange?: (isUnderwater: boolean) => void;
  onAutoSave: (state: PlayerState) => void;
  onAttack: (pos: THREE.Vector3, dir: THREE.Vector3) => void;
  onInteractNPC: () => void; 
  isLocked: boolean;
  isMuted: boolean; 
}

const SPEEDS = {
  WALK: 12,
  RUN: 24,
  SWIM: 10,
  BOAT: 25, 
  BOAT_TURN: 1.2, 
};

const PHYSICS = {
  GRAVITY: 35,
  JUMP_FORCE: 14,
  BUOYANCY: 15, 
  WATER_DRAG: 4.0, 
  AIR_DRAG: 0.5,
  GROUND_DRAG: 15.0,
  BOAT_DRAG: 1.0, 
};

const PLAYER_HEIGHT = 1.8;
// Ajuste da altura do assento para posição exata do piloto (cabeça)
const BOAT_SEAT_HEIGHT = 1.6; 

const UPDATE_THRESHOLD = 0.5;

const Player: React.FC<PlayerProps> = ({ 
  initialState, 
  onPositionChange, 
  onStatsUpdate, 
  onUnderwaterChange, 
  onRotationChange, 
  onAutoSave, 
  onAttack, 
  onInteractNPC,
  isLocked,
  isMuted 
}) => {
  const { camera, gl } = useThree();
  
  const velocity = useRef(new THREE.Vector3());
  const position = useRef(new THREE.Vector3(0, 50, 0));
  const lastUpdatePos = useRef(new THREE.Vector3(0, 0, 0));
  const hasInitialized = useRef(false);
  const lastRotationBroadcast = useRef(0);
  
  const isGrounded = useRef(false);
  const isSwimming = useRef(false);
  const lastSaveTime = useRef(Date.now());
  
  const lastStatsUpdate = useRef(0);

  const [isBoating, setIsBoating] = useState(false);
  const boatRotation = useRef(0); 
  // Ref para controlar a malha do barco imperativamente (Sync Perfeito)
  const boatRef = useRef<THREE.Group>(null);
  
  const [canInteractBoat, setCanInteractBoat] = useState(false);
  const [canInteractQuest, setCanInteractQuest] = useState(false);
  const [canInteractNPC, setCanInteractNPC] = useState(false);
  
  const [showQuestModal, setShowQuestModal] = useState(false);
  
  // Refs de Áudio - Grama
  const walkAudioRef = useRef<HTMLAudioElement | null>(null);
  const runAudioRef = useRef<HTMLAudioElement | null>(null);
  
  // Refs de Áudio - Pedra
  const rockWalkAudioRef = useRef<HTMLAudioElement | null>(null);
  const rockRunAudioRef = useRef<HTMLAudioElement | null>(null);

  // Refs de Áudio - Areia
  const sandWalkAudioRef = useRef<HTMLAudioElement | null>(null);
  const sandRunAudioRef = useRef<HTMLAudioElement | null>(null);
  
  // Ref de Áudio - Água (Ambiental)
  const waterAudioRef = useRef<HTMLAudioElement | null>(null);

  // Refs de Áudio - Barco
  const boatIdleAudioRef = useRef<HTMLAudioElement | null>(null);
  const boatStartAudioRef = useRef<HTMLAudioElement | null>(null);
  const boatCruiseAudioRef = useRef<HTMLAudioElement | null>(null);
  
  // Controle de estado do barco
  const wasMovingRef = useRef(false);

  // Controle de volume para FADE (evita clicks)
  const volWalk = useRef(0);
  const volRun = useRef(0);
  const volRockWalk = useRef(0);
  const volRockRun = useRef(0);
  const volSandWalk = useRef(0);
  const volSandRun = useRef(0);
  const volWater = useRef(0); // Volume da água
  
  // Volumes do barco
  const volBoatIdle = useRef(0);
  const volBoatCruise = useRef(0);

  const input = useRef({
    forward: false,
    backward: false,
    left: false,
    right: false,
    sprint: false,
    jump: false,
    interact: false,
    attack: false,
  });

  useEffect(() => {
    camera.rotation.order = 'YXZ';
  }, [camera]);

  // CORREÇÃO CRÍTICA DE CÂMERA (Mantida):
  useEffect(() => {
    if (isLocked) {
        camera.quaternion.identity();
        camera.rotation.set(0, lastRotationBroadcast.current || 0, 0);
    }
  }, [isLocked, camera]);

  // Inicialização dos Áudios
  useEffect(() => {
    const setupAudio = (url: string, loop = true) => {
        const audio = new Audio(url);
        audio.loop = loop;
        audio.volume = 0;
        audio.preload = 'auto';
        audio.muted = isMuted; // Inicializa com o estado correto
        return audio;
    };

    const walk = setupAudio(WALK_SOUND_URL);
    const run = setupAudio(RUN_SOUND_URL);
    const rockWalk = setupAudio(ROCK_WALK_SOUND_URL);
    const rockRun = setupAudio(ROCK_RUN_SOUND_URL);
    const sandWalk = setupAudio(SAND_WALK_SOUND_URL);
    const sandRun = setupAudio(SAND_RUN_SOUND_URL);
    const water = setupAudio(WATER_SOUND_URL);
    
    // Configuração dos áudios do barco
    const boatIdle = setupAudio(BOAT_IDLE_URL, true);
    const boatStart = setupAudio(BOAT_START_URL, false); // Não faz loop
    const boatCruise = setupAudio(BOAT_CRUISE_URL, true);

    walkAudioRef.current = walk;
    runAudioRef.current = run;
    rockWalkAudioRef.current = rockWalk;
    rockRunAudioRef.current = rockRun;
    sandWalkAudioRef.current = sandWalk;
    sandRunAudioRef.current = sandRun;
    waterAudioRef.current = water;
    
    boatIdleAudioRef.current = boatIdle;
    boatStartAudioRef.current = boatStart;
    boatCruiseAudioRef.current = boatCruise;

    // Tentar dar play no ambient imediatamente (volume 0 inicialmente)
    water.play().catch(() => {});
    
    // Barco começa mutado, mas damos play nos loops se necessário (será controlado pelo isBoating)
    boatIdle.play().catch(() => {});
    boatCruise.play().catch(() => {}); // Damos play mas volume fica 0 até acelerar

    return () => {
        walk.pause(); run.pause();
        rockWalk.pause(); rockRun.pause();
        sandWalk.pause(); sandRun.pause();
        water.pause();
        boatIdle.pause(); boatStart.pause(); boatCruise.pause();
    };
  }, []); // Run once on mount

  // Efeito para sincronizar MUTE dinamicamente
  useEffect(() => {
    const refs = [
        walkAudioRef, runAudioRef, 
        rockWalkAudioRef, rockRunAudioRef, 
        sandWalkAudioRef, sandRunAudioRef, 
        waterAudioRef, 
        boatIdleAudioRef, boatStartAudioRef, boatCruiseAudioRef
    ];
    refs.forEach(ref => {
        if (ref.current) ref.current.muted = isMuted;
    });
  }, [isMuted]);

  useEffect(() => {
    const onMouseMove = (e: MouseEvent) => {
        if (!isLocked) return; 
        if (document.pointerLockElement !== gl.domElement) return;

        const sensitivity = 0.002;
        camera.rotation.y -= e.movementX * sensitivity;
        camera.rotation.x -= e.movementY * sensitivity;
        
        const PI_2 = Math.PI / 2 - 0.01;
        camera.rotation.x = Math.max(-PI_2, Math.min(PI_2, camera.rotation.x));
    };

    document.addEventListener('mousemove', onMouseMove);
    return () => document.removeEventListener('mousemove', onMouseMove);
  }, [isLocked, camera, gl.domElement]);

  useEffect(() => {
    if (!hasInitialized.current && initialState) {
      position.current.copy(initialState.position as unknown as THREE.Vector3);
      
      if (initialState.rotation) {
          camera.rotation.set(initialState.rotation.phi, initialState.rotation.theta, 0);
          boatRotation.current = initialState.rotation.theta;
          lastRotationBroadcast.current = initialState.rotation.theta;
      }
      
      hasInitialized.current = true;
    }
  }, [initialState, camera]);

  useEffect(() => {
    const handleKey = (code: string, pressed: boolean) => {
      switch (code) {
        case 'ArrowUp': case 'KeyW': input.current.forward = pressed; break;
        case 'ArrowLeft': case 'KeyA': input.current.left = pressed; break;
        case 'ArrowDown': case 'KeyS': input.current.backward = pressed; break;
        case 'ArrowRight': case 'KeyD': input.current.right = pressed; break;
        case 'ShiftLeft': input.current.sprint = pressed; break;
        case 'Space': if (pressed) input.current.jump = true; break;
        case 'KeyE': if (pressed) input.current.interact = true; break; 
      }
    };

    const onMouseDown = (e: MouseEvent) => {
        if (!isLocked || e.button !== 0) return; 
        input.current.attack = true;
    };
    
    const onMouseUp = () => {
        input.current.attack = false;
    }

    const onKeyDown = (e: KeyboardEvent) => handleKey(e.code, true);
    const onKeyUp = (e: KeyboardEvent) => {
      handleKey(e.code, false);
      if (e.code === 'Space') input.current.jump = false;
      if (e.code === 'KeyE') input.current.interact = false;
    };

    document.addEventListener('keydown', onKeyDown);
    document.addEventListener('keyup', onKeyUp);
    document.addEventListener('mousedown', onMouseDown);
    document.addEventListener('mouseup', onMouseUp);
    return () => {
      document.removeEventListener('keydown', onKeyDown);
      document.removeEventListener('keyup', onKeyUp);
      document.removeEventListener('mousedown', onMouseDown);
      document.removeEventListener('mouseup', onMouseUp);
    };
  }, [isLocked]);

  useEffect(() => {
      if (input.current.attack) {
          // --- DETECÇÃO DE CLICK NO NPC ---
          if (canInteractNPC) {
               onInteractNPC();
          } else {
              const dir = new THREE.Vector3();
              camera.getWorldDirection(dir);
              onAttack(position.current, dir);
          }
          input.current.attack = false; 
      }
  }, [input.current.attack, onAttack, camera, canInteractNPC, onInteractNPC]);

  useFrame((state) => {
     // Lógica de Interação Geral (Barco e Missão)

     if (isBoating) {
         if (input.current.interact) {
             setIsBoating(false);
             input.current.interact = false; 
             velocity.current.y = 10; 
         }
         return;
     }

     if (position.current.y < 50.0) { // Otimização: Só checa se não estiver voando muito alto
        const rX = Math.floor((position.current.x + CHUNK_SIZE/2) / VILLAGE_GRID_SIZE);
        const rZ = Math.floor((position.current.z + CHUNK_SIZE/2) / VILLAGE_GRID_SIZE);
        
        let foundBoat = false;
        let foundQuest = false;
        let foundNPC = false;
        
        // Loop de colisão e interação
        for(let cx = rX - 1; cx <= rX + 1; cx++) {
            for(let cz = rZ - 1; cz <= rZ + 1; cz++) {
                const content = getVillageContent(cx, cz);
                for(const obj of content.objects) {
                    
                    // --- BARCO ---
                    if (obj.type === 'boat') {
                        const dx = position.current.x - obj.x;
                        const dz = position.current.z - obj.z;
                        const distSq = dx*dx + dz*dz;

                        // Raio de interação (4 metros)
                        if (distSq < 16) { 
                            foundBoat = true;
                            if (input.current.interact) {
                                setIsBoating(true);
                                input.current.interact = false;
                                boatRotation.current = obj.rot; 
                                position.current.x = obj.x;
                                position.current.z = obj.z;
                            }
                        }

                        // LÓGICA DE COLISÃO DO JOGADOR COM BARCO PARADO
                        if (distSq < 10.24) { 
                            const dist = Math.sqrt(distSq);
                            const pushDirX = dx / dist;
                            const pushDirZ = dz / dist;
                            
                            const pushDist = 3.2 - dist;
                            position.current.x += pushDirX * pushDist;
                            position.current.z += pushDirZ * pushDist;

                            velocity.current.x *= 0.5;
                            velocity.current.z *= 0.5;
                        }
                    }

                    // --- QUEST BOARD ---
                    if (obj.type === 'quest_board') {
                        const dx = position.current.x - obj.x;
                        const dz = position.current.z - obj.z;
                        const distSq = dx*dx + dz*dz;

                        // Raio de interação (3 metros)
                        if (distSq < 9) {
                            foundQuest = true;
                            // Abre com E ou Clique (Attack)
                            if (input.current.interact || input.current.attack) {
                                setShowQuestModal(prev => !prev);
                                input.current.interact = false;
                                input.current.attack = false;
                            }
                        }
                    }

                    // --- NPC ---
                    if (obj.type === 'npc') {
                        const dx = position.current.x - obj.x;
                        const dz = position.current.z - obj.z;
                        const distSq = dx*dx + dz*dz;
                        
                        // Raio de interação (4 metros)
                        if (distSq < 16) {
                            foundNPC = true;
                        }
                    }
                }
            }
        }
        setCanInteractBoat(foundBoat);
        setCanInteractQuest(foundQuest);
        setCanInteractNPC(foundNPC);
     } else {
        if (canInteractBoat) setCanInteractBoat(false);
        if (canInteractQuest) setCanInteractQuest(false);
        if (canInteractNPC) setCanInteractNPC(false);
     }
  });

  useFrame((state, delta) => {
    const dt = Math.min(delta, 0.05);
    const naturalHeight = getTerrainHeight(position.current.x, position.current.z);
    const terrainHeight = getPlatformHeight(position.current.x, position.current.z, naturalHeight);
    const eyeLevel = position.current.y + (isBoating ? BOAT_SEAT_HEIGHT : 1.6);
    
    if (!isBoating) {
        if (isSwimming.current) {
            if (eyeLevel > WATER_LEVEL + 0.2) isSwimming.current = false;
        } else {
            if (eyeLevel < WATER_LEVEL - 0.1) isSwimming.current = true;
        }
        if (onUnderwaterChange) onUnderwaterChange(isSwimming.current);
    } else {
        isSwimming.current = false;
        if (onUnderwaterChange) onUnderwaterChange(false);
    }

    const inputDir = new THREE.Vector3(0, 0, 0);
    let isMoving = false;

    if (isLocked) {
        if (isBoating) {
            if (input.current.left) boatRotation.current += SPEEDS.BOAT_TURN * dt;
            if (input.current.right) boatRotation.current -= SPEEDS.BOAT_TURN * dt;
            
            const boatDir = new THREE.Vector3(Math.sin(boatRotation.current), 0, Math.cos(boatRotation.current));
            
            if (input.current.forward) inputDir.add(boatDir);
            if (input.current.backward) inputDir.sub(boatDir);
            
            // Check movimento do barco para áudio
            if (input.current.forward || input.current.backward) isMoving = true;

            const mapRotation = Math.PI - boatRotation.current;
            
            if (Math.abs(mapRotation - lastRotationBroadcast.current) > 0.05) {
                onRotationChange(mapRotation);
                lastRotationBroadcast.current = mapRotation;
            }

            const targetSpeed = SPEEDS.BOAT;
            const targetVelocity = inputDir.normalize().multiplyScalar(targetSpeed);
            
            velocity.current.x += (targetVelocity.x - velocity.current.x) * PHYSICS.BOAT_DRAG * dt;
            velocity.current.z += (targetVelocity.z - velocity.current.z) * PHYSICS.BOAT_DRAG * dt;
            
            const waveHeight = Math.sin(state.clock.elapsedTime * 0.8) * 0.15;
            position.current.y = WATER_LEVEL + 1.0 + waveHeight; 
            velocity.current.y = 0; 
            
        } else {
            const camDirection = new THREE.Vector3();
            camera.getWorldDirection(camDirection);
            const rotationY = Math.atan2(camDirection.x, -camDirection.z);
            
            if (Math.abs(rotationY - lastRotationBroadcast.current) > 0.05) {
                onRotationChange(rotationY);
                lastRotationBroadcast.current = rotationY;
            }

            const forwardVecFlat = new THREE.Vector3(camDirection.x, 0, camDirection.z).normalize();
            const rightVec = new THREE.Vector3().crossVectors(new THREE.Vector3(0, 1, 0), forwardVecFlat).normalize();

            if (isSwimming.current) {
                if (input.current.forward) inputDir.add(camDirection);
                if (input.current.backward) inputDir.sub(camDirection);
                if (input.current.right) inputDir.add(rightVec);
                if (input.current.left) inputDir.sub(rightVec);
            } else {
                if (input.current.forward) inputDir.add(forwardVecFlat);
                if (input.current.backward) inputDir.sub(forwardVecFlat);
                if (input.current.right) inputDir.sub(rightVec);
                if (input.current.left) inputDir.add(rightVec);
            }

            if (inputDir.lengthSq() > 0) {
                inputDir.normalize();
                isMoving = true;
            }

            let targetSpeed = input.current.sprint ? SPEEDS.RUN : SPEEDS.WALK;
            if (isSwimming.current) targetSpeed = SPEEDS.SWIM;

            const targetVelocity = inputDir.clone().multiplyScalar(targetSpeed);
            const damping = isSwimming.current ? PHYSICS.WATER_DRAG : (isGrounded.current ? PHYSICS.GROUND_DRAG : PHYSICS.AIR_DRAG);
            
            const alpha = 1.0 - Math.exp(-damping * dt);
            
            velocity.current.x = THREE.MathUtils.lerp(velocity.current.x, targetVelocity.x, alpha);
            velocity.current.z = THREE.MathUtils.lerp(velocity.current.z, targetVelocity.z, alpha);

            if (isSwimming.current) {
                velocity.current.y = THREE.MathUtils.lerp(velocity.current.y, targetVelocity.y, alpha);
                const depth = Math.max(0, WATER_LEVEL - position.current.y);
                const buoyancyForce = Math.min(depth, 1.0) * PHYSICS.BUOYANCY;
                velocity.current.y += (buoyancyForce - PHYSICS.GRAVITY * 0.2) * dt;
                if (input.current.jump) velocity.current.y = THREE.MathUtils.lerp(velocity.current.y, SPEEDS.SWIM, 5 * dt);
            } else {
                velocity.current.y -= PHYSICS.GRAVITY * dt;
                if (isGrounded.current && input.current.jump) {
                    velocity.current.y = PHYSICS.JUMP_FORCE;
                    isGrounded.current = false;
                }
            }
        }
    } else {
        const damping = PHYSICS.GROUND_DRAG;
        const alpha = 1.0 - Math.exp(-damping * dt);
        velocity.current.x = THREE.MathUtils.lerp(velocity.current.x, 0, alpha);
        velocity.current.z = THREE.MathUtils.lerp(velocity.current.z, 0, alpha);
        
        if (!isSwimming.current && !isBoating) {
             velocity.current.y -= PHYSICS.GRAVITY * dt;
        } else if (isSwimming.current) {
             const depth = Math.max(0, WATER_LEVEL - position.current.y);
             velocity.current.y += (depth * PHYSICS.BUOYANCY - PHYSICS.GRAVITY * 0.2) * dt;
        }
    }

    const isSand = terrainHeight <= WATER_LEVEL + 3.5;
    const isRockOrSnow = terrainHeight > 35;
    const isGrass = !isSand && !isRockOrSnow;
    const isMovingOnLand = isLocked && isGrounded.current && isMoving && !isSwimming.current && !isBoating;
    const isMovingOnGrass = isMovingOnLand && isGrass;
    const isMovingOnRock = isMovingOnLand && isRockOrSnow;
    const isMovingOnSand = isMovingOnLand && isSand;
    const TARGET_VOL = 0.35;
    const TARGET_ROCK_VOL = 0.6; 
    const TARGET_SAND_VOL = 0.45; 
    const FADE_SPEED = 8.0; 

    // --- CÁLCULO DE ÁUDIO DE MOVIMENTO ---
    const targetWalkVol = (isMovingOnGrass && !input.current.sprint) ? TARGET_VOL : 0;
    const targetRunVol = (isMovingOnGrass && input.current.sprint) ? TARGET_VOL : 0;
    const targetRockWalkVol = (isMovingOnRock && !input.current.sprint) ? TARGET_ROCK_VOL : 0;
    const targetRockRunVol = (isMovingOnRock && input.current.sprint) ? TARGET_ROCK_VOL : 0;
    const targetSandWalkVol = (isMovingOnSand && !input.current.sprint) ? TARGET_SAND_VOL : 0;
    const targetSandRunVol = (isMovingOnSand && input.current.sprint) ? TARGET_SAND_VOL : 0;

    // --- CÁLCULO DE ÁUDIO AMBIENTAL DA ÁGUA ---
    const distToWater = Math.abs(position.current.y - WATER_LEVEL);
    const MAX_WATER_DIST = 10.0;
    const MAX_WATER_VOL = 0.25; 
    
    let targetWaterVol = 0;
    if (isLocked && distToWater < MAX_WATER_DIST) {
        const volFactor = 1.0 - (distToWater / MAX_WATER_DIST);
        targetWaterVol = volFactor * MAX_WATER_VOL;
    }

    // --- CÁLCULO DE ÁUDIO DO BARCO ---
    // Estrutura:
    // 1. Idle: Toca quando !isMoving.
    // 2. Start: Toca UMA VEZ quando isMoving muda de false para true.
    // 3. Cruise: Toca quando isMoving, mas com Fade In lento para dar tempo do Start tocar.
    
    let targetBoatIdleVol = 0;
    let targetBoatCruiseVol = 0;
    
    if (isLocked && isBoating) {
        
        // Detectar "Borda de Subida" (Rising Edge) da movimentação
        if (isMoving && !wasMovingRef.current) {
            // ACABOU DE COMEÇAR A ANDAR
            if (boatStartAudioRef.current) {
                boatStartAudioRef.current.currentTime = 0;
                boatStartAudioRef.current.volume = 0.8;
                boatStartAudioRef.current.play().catch(() => {});
            }
            wasMovingRef.current = true;
        } 
        // Detectar "Borda de Descida" (Falling Edge)
        else if (!isMoving && wasMovingRef.current) {
            // ACABOU DE PARAR
            wasMovingRef.current = false;
        }

        if (isMoving) {
            // Em movimento
            targetBoatIdleVol = 0;
            targetBoatCruiseVol = 0.8; // Volume máximo do loop de cruzeiro
        } else {
            // Parado
            targetBoatIdleVol = 0.6; // Volume do idle
            targetBoatCruiseVol = 0;
        }
    } else {
        // Não está no barco
        wasMovingRef.current = false;
    }

    // Aplicação de LERP nos volumes
    volWalk.current = THREE.MathUtils.lerp(volWalk.current, targetWalkVol, dt * FADE_SPEED);
    volRun.current = THREE.MathUtils.lerp(volRun.current, targetRunVol, dt * FADE_SPEED);
    volRockWalk.current = THREE.MathUtils.lerp(volRockWalk.current, targetRockWalkVol, dt * FADE_SPEED);
    volRockRun.current = THREE.MathUtils.lerp(volRockRun.current, targetRockRunVol, dt * FADE_SPEED);
    volSandWalk.current = THREE.MathUtils.lerp(volSandWalk.current, targetSandWalkVol, dt * FADE_SPEED);
    volSandRun.current = THREE.MathUtils.lerp(volSandRun.current, targetSandRunVol, dt * FADE_SPEED);
    volWater.current = THREE.MathUtils.lerp(volWater.current, targetWaterVol, dt * 2.0);
    
    // --- LERP DO BARCO ---
    const BOAT_IDLE_FADE = 2.0;
    // O Cruise sobe devagar (1.0) para permitir que o Start toque primeiro.
    // O Cruise desce rápido (4.0) quando solta o botão para parar o motor logo.
    const BOAT_CRUISE_FADE = isMoving ? 0.8 : 4.0; 

    volBoatIdle.current = THREE.MathUtils.lerp(volBoatIdle.current, targetBoatIdleVol, dt * BOAT_IDLE_FADE);
    volBoatCruise.current = THREE.MathUtils.lerp(volBoatCruise.current, targetBoatCruiseVol, dt * BOAT_CRUISE_FADE);

    // Se parou de andar, fade out rápido no som de start também (caso ele ainda esteja tocando)
    if (!isMoving && boatStartAudioRef.current && !boatStartAudioRef.current.paused) {
         boatStartAudioRef.current.volume = THREE.MathUtils.lerp(boatStartAudioRef.current.volume, 0, dt * 5.0);
    }

    const applyAudio = (ref: React.MutableRefObject<HTMLAudioElement | null>, vol: number) => {
        if (ref.current) {
            ref.current.volume = vol;
            if (vol > 0.01) {
                if (ref.current.paused) ref.current.play().catch(() => {});
            } else {
                if (!ref.current.paused) {
                    ref.current.pause();
                    ref.current.currentTime = 0; // Reset para passos
                }
            }
        }
    }
    
    const applyAmbientAudio = (ref: React.MutableRefObject<HTMLAudioElement | null>, vol: number) => {
        if (ref.current) {
            ref.current.volume = vol;
            if (vol > 0.01 && ref.current.paused) {
                ref.current.play().catch(() => {});
            } else if (vol <= 0.01 && !ref.current.paused) {
                ref.current.pause();
            }
        }
    }

    applyAudio(walkAudioRef, volWalk.current);
    applyAudio(runAudioRef, volRun.current);
    applyAudio(rockWalkAudioRef, volRockWalk.current);
    applyAudio(rockRunAudioRef, volRockRun.current);
    applyAudio(sandWalkAudioRef, volSandWalk.current);
    applyAudio(sandRunAudioRef, volSandRun.current);
    applyAmbientAudio(waterAudioRef, volWater.current);
    
    applyAmbientAudio(boatIdleAudioRef, volBoatIdle.current);
    applyAmbientAudio(boatCruiseAudioRef, volBoatCruise.current);

    // FIX GAPLESS LOOP para IDLE e CRUISE
    const fixGapless = (audioRef: React.MutableRefObject<HTMLAudioElement | null>) => {
        if (audioRef.current && !audioRef.current.paused && audioRef.current.duration) {
            const t = audioRef.current.currentTime;
            const d = audioRef.current.duration;
            if (t > d - 0.22) { // 220ms buffer
                audioRef.current.currentTime = 0;
            }
        }
    }
    
    fixGapless(boatIdleAudioRef);
    fixGapless(boatCruiseAudioRef);


    // --- APLICAÇÃO DE MOVIMENTO E COLISÃO ---

    if (isBoating) {
        // COLISÃO DO BARCO: Não navegar em terra
        const nextX = position.current.x + velocity.current.x * dt;
        const nextZ = position.current.z + velocity.current.z * dt;
        
        // Limite de profundidade: O terreno deve ser menor que o nível da água - 0.5m
        const MAX_BOAT_TERRAIN_HEIGHT = WATER_LEVEL - 0.5;

        // Check Eixo X
        if (getTerrainHeight(nextX, position.current.z) < MAX_BOAT_TERRAIN_HEIGHT) {
            position.current.x = nextX;
        } else {
            velocity.current.x = 0; // Colidiu
        }

        // Check Eixo Z
        if (getTerrainHeight(position.current.x, nextZ) < MAX_BOAT_TERRAIN_HEIGHT) {
            position.current.z = nextZ;
        } else {
            velocity.current.z = 0; // Colidiu
        }

    } else if (!isSwimming.current) {
        // ANDANDO NA TERRA (Colisão com Vegetação)
        const nextX = position.current.x + velocity.current.x * dt;
        
        // Colisão com Vegetação (Paredes de casas removidas do check)
        if (checkVegetationCollision(nextX, position.current.z)) {
            velocity.current.x = 0; 
        } else {
            position.current.x = nextX;
        }

        const nextZ = position.current.z + velocity.current.z * dt;
        if (checkVegetationCollision(position.current.x, nextZ)) {
            velocity.current.z = 0;
        } else {
            position.current.z = nextZ;
        }
    } else {
        // NADANDO (Sem colisão de vegetação, movimento livre)
        position.current.x += velocity.current.x * dt;
        position.current.z += velocity.current.z * dt;
    }

    if (!isBoating) {
        position.current.y += velocity.current.y * dt;
    } 

    if (!isBoating && position.current.y < terrainHeight + PLAYER_HEIGHT) {
      position.current.y = terrainHeight + PLAYER_HEIGHT;
      velocity.current.y = 0;
      isGrounded.current = true;
    } else if (isBoating) {
    } else {
       isGrounded.current = false;
    }

    if (!isLocked) {
        const time = state.clock.getElapsedTime();
        const orbitRadius = 60;
        const orbitSpeed = 0.08;
        
        const camX = position.current.x + Math.sin(time * orbitSpeed) * orbitRadius;
        const camZ = position.current.z + Math.cos(time * orbitSpeed) * orbitRadius;
        const camY = position.current.y + 35 + Math.sin(time * 0.2) * 5;

        camera.position.set(camX, camY, camZ);
        // IMPORTANTE: Isso suja a matriz de rotação com valores complexos de Quaternion
        camera.lookAt(position.current.x, position.current.y + 2, position.current.z);
        
    } else {
        if (isBoating) {
            // CÂMERA DO BARCO REAJUSTADA (CORREÇÃO DE BLOQUEIO):
            // Trava a posição da câmera no assento do piloto, relativa à rotação do barco.
            const boatOffset = new THREE.Vector3(0, 1.8, 2.2); // Posição da cabeça do piloto
            
            // Rotaciona o offset baseado na direção do barco
            boatOffset.applyAxisAngle(new THREE.Vector3(0, 1, 0), boatRotation.current);
            
            camera.position.set(
                position.current.x + boatOffset.x,
                position.current.y + boatOffset.y,
                position.current.z + boatOffset.z
            );
            
            // Ponto para onde o piloto olha (frente do barco)
            const lookTarget = new THREE.Vector3(0, 1.8, 10.0);
            lookTarget.applyAxisAngle(new THREE.Vector3(0, 1, 0), boatRotation.current);
            
            // LookAt no barco é seguro pois estamos recalculando todo frame em modo fixo
            camera.lookAt(
                position.current.x + lookTarget.x, 
                position.current.y + lookTarget.y, 
                position.current.z + lookTarget.z
            );

        } else {
            camera.position.set(
              position.current.x,
              position.current.y,
              position.current.z
            );
            // NÃO USAR lookAt AQUI PARA FPS.
            // A rotação é controlada exclusivamente pelo useEffect do mousemove.
        }
    }

    if (isBoating && boatRef.current) {
        boatRef.current.position.copy(position.current);
        boatRef.current.rotation.set(0, boatRotation.current, 0);
    }

    if (position.current.distanceTo(lastUpdatePos.current) > UPDATE_THRESHOLD) {
      onPositionChange(position.current.clone());
      lastUpdatePos.current.copy(position.current);
    }
    
    if (isLocked) {
        const now = performance.now();
        if (now - lastStatsUpdate.current > 200) {
            onStatsUpdate(
                Math.sqrt(velocity.current.x**2 + velocity.current.z**2 + (isSwimming.current ? velocity.current.y**2 : 0)), 
                isGrounded.current
            );
            lastStatsUpdate.current = now;
        }

        if (Date.now() - lastSaveTime.current > AUTO_SAVE_INTERVAL) {
            onAutoSave({
                position: { x: position.current.x, y: position.current.y, z: position.current.z },
                rotation: { phi: camera.rotation.x, theta: camera.rotation.y },
                seed: WORLD_SEED
            });
            lastSaveTime.current = Date.now();
        }
    }
  }, 1);

  return (
    <>
        {isBoating ? (
            <group ref={boatRef}>
                <BoatMesh velocityRef={velocity} />
            </group>
        ) : null}
        
        {/* HINT BARCO */}
        {isLocked && canInteractBoat && !isBoating && !showQuestModal ? (
           <Html fullscreen pointerEvents="none">
            <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 mt-12 pointer-events-none">
                <div className="bg-black/60 text-white px-4 py-2 rounded text-sm font-bold animate-pulse backdrop-blur-sm border border-white/20">
                    [E] Pilotar Iate
                </div>
            </div>
           </Html>
        ) : null}
        
        {/* HINT QUEST */}
        {isLocked && canInteractQuest && !showQuestModal ? (
            <Html fullscreen pointerEvents="none">
                <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 mt-12 pointer-events-none">
                    <div className="bg-[#4a3b2a]/90 text-[#f0e6d2] px-4 py-2 rounded text-sm font-bold animate-pulse backdrop-blur-sm border border-[#f0e6d2]/30">
                        [E] Ler Pergaminho
                    </div>
                </div>
            </Html>
        ) : null}

        {/* HINT NPC */}
        {isLocked && canInteractNPC && !showQuestModal ? (
            <Html fullscreen pointerEvents="none">
                <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 mt-12 pointer-events-none">
                    <div className="bg-purple-900/90 text-purple-100 px-4 py-2 rounded text-sm font-bold animate-pulse backdrop-blur-sm border border-purple-500/30 shadow-[0_0_15px_rgba(168,85,247,0.5)]">
                        [Clique] Falar com o Observador
                    </div>
                </div>
            </Html>
        ) : null}

        {/* MODAL DA QUEST (PERGAMINHO) */}
        {showQuestModal ? (
            <Html fullscreen style={{ pointerEvents: 'none' }}>
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                    <div className="w-[500px] h-[600px] bg-[#f0e6d2] text-[#3e2723] p-12 rounded-sm shadow-[0_0_50px_rgba(0,0,0,0.8)] border-[12px] border-[#5c4033] flex flex-col items-center text-center font-serif relative overflow-hidden pointer-events-auto">
                        
                        {/* Efeito de papel velho (Overlay) */}
                        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/aged-paper.png')] opacity-50 pointer-events-none"></div>
                        
                        <div className="relative z-10 w-full flex flex-col h-full">
                            <h2 className="text-4xl font-bold mb-8 border-b-4 border-[#3e2723] pb-4 tracking-widest uppercase">Missão</h2>
                            
                            <div className="flex-grow flex items-center justify-center">
                                <p className="text-3xl italic font-medium leading-relaxed drop-shadow-sm">
                                    "A missão começa aqui."
                                </p>
                            </div>

                            <div className="mt-auto pt-8 border-t border-[#3e2723]/30 w-full flex justify-center">
                                <div className="text-sm font-sans uppercase tracking-widest font-bold opacity-60 bg-[#3e2723] text-[#f0e6d2] px-4 py-1 rounded">
                                    Pressione [E] para fechar
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </Html>
        ) : null}
        
        {isLocked && isBoating ? (
             <Html fullscreen pointerEvents="none">
               <div className="absolute bottom-20 left-1/2 transform -translate-x-1/2 pointer-events-none">
                  <div className="bg-black/60 text-white px-4 py-2 rounded text-sm backdrop-blur-sm">
                      [E] Sair do Iate
                  </div>
              </div>
            </Html>
        ) : null}
    </>
  );
};

export default Player;
