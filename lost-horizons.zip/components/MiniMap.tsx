
import React, { useRef, useEffect } from 'react';
import * as THREE from 'three';
import { Vector3 } from '../types';
import { workerManager } from '../services/WorkerManager';

interface MiniMapProps {
  playerPos: Vector3;
  playerRot: number; // Rotação Y em radianos (via Math.atan2)
  npcPos?: THREE.Vector3; // Posição opcional do NPC para mostrar no mapa
}

const MAP_SIZE = 200; // Tamanho visual na tela (pixels)
const INTERNAL_SIZE = 200; // Resolução da textura (Match 1:1 para qualidade máxima)
const VIEW_RADIUS = 120; // Raio de visão (metros)

const MiniMap: React.FC<MiniMapProps> = ({ playerPos, playerRot, npcPos }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const lastUpdatePos = useRef({ x: -999, z: -999 });
  const isUpdating = useRef(false);

  // Buffer offscreen para guardar a imagem estática do terreno gerada pelo worker
  const mapTextureRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    if (!mapTextureRef.current) {
        mapTextureRef.current = document.createElement('canvas');
        mapTextureRef.current.width = INTERNAL_SIZE;
        mapTextureRef.current.height = INTERNAL_SIZE;
    }
  }, []);

  // Loop de Renderização (60 FPS)
  useEffect(() => {
    let animationFrameId: number;
    
    const render = () => {
        const canvas = canvasRef.current;
        if (!canvas || !mapTextureRef.current) return;
        
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        ctx.clearRect(0, 0, MAP_SIZE, MAP_SIZE);

        ctx.save();
        
        // 1. Centralizar no Canvas
        ctx.translate(MAP_SIZE / 2, MAP_SIZE / 2);
        
        // MODO NORTE FIXO (NORTH UP):
        // Não rotacionamos o mapa. O Norte da textura (Topo) alinha com o Norte do Canvas (Topo).
        
        // 2. Compensação de Movimento (Suavização)
        // Calcula o deslocamento do jogador desde a última geração da textura
        // e move a textura na direção oposta.
        const metersPerPixel = (VIEW_RADIUS * 2) / MAP_SIZE;
        const dx = (playerPos.x - lastUpdatePos.current.x) / metersPerPixel;
        const dz = (playerPos.z - lastUpdatePos.current.z) / metersPerPixel;
        
        ctx.translate(-dx, -dz);
        
        // 3. Desenha a textura centralizada
        ctx.drawImage(
            mapTextureRef.current, 
            -MAP_SIZE / 2, 
            -MAP_SIZE / 2, 
            MAP_SIZE, 
            MAP_SIZE
        );
        ctx.restore();

        // --- RENDERIZAÇÃO DO PONTO VERMELHO DO NPC (SE HOUVER) ---
        if (npcPos) {
            ctx.save();
            ctx.translate(MAP_SIZE / 2, MAP_SIZE / 2); // Centraliza no jogador (centro do radar)
            
            // Calcula a posição relativa do NPC em pixels
            const metersPerPixel = (VIEW_RADIUS * 2) / MAP_SIZE;
            const npcDx = (npcPos.x - playerPos.x) / metersPerPixel;
            const npcDz = (npcPos.z - playerPos.z) / metersPerPixel;

            // Distância do centro
            const dist = Math.sqrt(npcDx * npcDx + npcDz * npcDz);
            const maxDist = (MAP_SIZE / 2) - 8; // Margem para não cortar o círculo

            let drawX = npcDx;
            let drawY = npcDz;

            if (dist > maxDist) {
                // Clampa na borda para indicar direção se estiver longe
                const angle = Math.atan2(npcDz, npcDx);
                drawX = Math.cos(angle) * maxDist;
                drawY = Math.sin(angle) * maxDist;
            }

            // Desenha o ponto vermelho
            ctx.beginPath();
            ctx.arc(drawX, drawY, 5, 0, Math.PI * 2);
            ctx.fillStyle = '#FF0000'; // Vermelho
            ctx.fill();
            ctx.strokeStyle = '#FFFFFF'; // Borda branca para contraste
            ctx.lineWidth = 2;
            ctx.stroke();
            
            ctx.restore();
        }

        // --- Seta do Jogador (GIRATÓRIA) ---
        ctx.save();
        ctx.translate(MAP_SIZE / 2, MAP_SIZE / 2);
        
        // A seta gira para mostrar para onde o jogador está olhando.
        // 0 radianos = Norte = Cima no Canvas.
        ctx.rotate(playerRot);
        
        // Seta com borda para contraste
        ctx.shadowColor = "rgba(0,0,0,0.5)";
        ctx.shadowBlur = 4;
        
        ctx.beginPath();
        ctx.moveTo(0, -10); // Ponta (Frente)
        ctx.lineTo(7, 8);   // Base Dir
        ctx.lineTo(0, 4);   // Centro Base
        ctx.lineTo(-7, 8);  // Base Esq
        ctx.closePath();
        
        ctx.fillStyle = '#FFFFFF'; 
        ctx.fill();
        ctx.strokeStyle = '#000000';
        ctx.lineWidth = 1.5;
        ctx.stroke();
        ctx.restore();

        animationFrameId = requestAnimationFrame(render);
    };

    animationFrameId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animationFrameId);
  }, [playerRot, playerPos, npcPos]); 
  
  // Lógica de Atualização de Dados (Worker Dedicado)
  useEffect(() => {
      const dist = Math.sqrt(
          Math.pow(playerPos.x - lastUpdatePos.current.x, 2) + 
          Math.pow(playerPos.z - lastUpdatePos.current.z, 2)
      );

      // Atualiza a textura a cada 8 metros
      if (dist > 8 && !isUpdating.current) {
          isUpdating.current = true;
          
          workerManager.generateMinimap(playerPos.x, playerPos.z, VIEW_RADIUS)
            .then(data => {
                if (data.minimapBuffer && mapTextureRef.current) {
                    const bufferCtx = mapTextureRef.current.getContext('2d');
                    if (bufferCtx) {
                        const imageData = new ImageData(
                            data.minimapBuffer, 
                            INTERNAL_SIZE, 
                            INTERNAL_SIZE
                        );
                        bufferCtx.putImageData(imageData, 0, 0);
                        lastUpdatePos.current = { x: playerPos.x, z: playerPos.z };
                    }
                }
                isUpdating.current = false;
            })
            .catch(() => {
                isUpdating.current = false;
            });
      }
  }, [playerPos.x, playerPos.z]); 

  return (
    <div 
        className="absolute top-6 right-6 z-10 rounded-full bg-black/50 shadow-xl overflow-hidden backdrop-blur-sm border-4 border-white/10"
        style={{ 
            width: MAP_SIZE, 
            height: MAP_SIZE,
            boxShadow: '0 4px 15px rgba(0,0,0,0.5)'
        }}
    >
        {/* Grid Limpo (Branco translúcido) */}
        <div className="absolute inset-0 z-20 pointer-events-none opacity-20" 
             style={{ 
                 backgroundImage: 'linear-gradient(rgba(255,255,255,0.5) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.5) 1px, transparent 1px)',
                 backgroundSize: '25px 25px'
             }} 
        />
        
        {/* Bússola Fixa (Norte sempre em cima) */}
        <div className="absolute top-1 left-1/2 -translate-x-1/2 text-[10px] font-bold text-white z-30 drop-shadow-md">N</div>
        <div className="absolute bottom-1 left-1/2 -translate-x-1/2 text-[10px] font-bold text-white z-30 drop-shadow-md">S</div>
        <div className="absolute left-1 top-1/2 -translate-y-1/2 text-[10px] font-bold text-white z-30 drop-shadow-md">O</div>
        <div className="absolute right-1 top-1/2 -translate-y-1/2 text-[10px] font-bold text-white z-30 drop-shadow-md">L</div>
        
        <canvas 
            ref={canvasRef} 
            width={MAP_SIZE} 
            height={MAP_SIZE} 
            className="block relative z-10"
        />
    </div>
  );
};

export default MiniMap;
