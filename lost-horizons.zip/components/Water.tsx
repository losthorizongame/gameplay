
import React, { useMemo, useEffect } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import * as THREE from 'three';
import { CHUNK_SIZE } from '../types';

// Shader Definition
const WaterShader = {
  uniforms: {
    uTime: { value: 0 },
    uBaseColor: { value: new THREE.Color('#1a4488') },      
    uShallowColor: { value: new THREE.Color('#4fa4d1') },   
    uFoamColor: { value: new THREE.Color('#ffffff') },      
    uSunPosition: { value: new THREE.Vector3(100, 50, 0) }, 
    uCameraPos: { value: new THREE.Vector3() }              
  },
  vertexShader: `
    uniform float uTime;
    varying float vElevation;
    varying vec2 vUv;
    varying vec3 vWorldPosition;
    varying vec3 vViewPosition;
    varying vec3 vNormal;

    float calculateWave(float x, float z) {
      float elevation = 0.0;
      // Ondas reduzidas (0.3 -> 0.15) para evitar clipping com o barco
      elevation += sin(x * 0.15 + uTime * 0.8) * 0.15;
      elevation += cos(z * 0.1 + uTime * 0.6) * 0.15;
      elevation += sin((x + z) * 0.4 + uTime * 1.5) * 0.05;
      return elevation;
    }

    void main() {
      vUv = uv;
      vec4 worldPosition = modelMatrix * vec4(position, 1.0);
      vWorldPosition = worldPosition.xyz;
      vec3 pos = position;
      float elevation = calculateWave(worldPosition.x, worldPosition.z);
      
      float offset = 0.1;
      float hx = calculateWave(worldPosition.x + offset, worldPosition.z);
      float hz = calculateWave(worldPosition.x, worldPosition.z + offset);
      
      vec3 tangentX = vec3(offset, hx - elevation, 0.0);
      vec3 tangentZ = vec3(0.0, hz - elevation, offset);
      vNormal = normalize(cross(tangentZ, tangentX));

      pos.z += elevation;
      vElevation = elevation;
      vec4 mvPosition = modelViewMatrix * vec4(pos, 1.0);
      vViewPosition = -mvPosition.xyz;
      gl_Position = projectionMatrix * mvPosition;
    }
  `,
  fragmentShader: `
    uniform vec3 uBaseColor;
    uniform vec3 uShallowColor;
    uniform vec3 uFoamColor;
    uniform vec3 uCameraPos;
    
    varying float vElevation;
    varying vec3 vWorldPosition;
    varying vec3 vNormal;

    void main() {
      vec3 normal = normalize(vNormal);
      float mixStrength = (vElevation + 0.5) * 0.6; 
      vec3 waterColor = mix(uBaseColor, uShallowColor, clamp(mixStrength, 0.0, 1.0));

      float foamMask = smoothstep(0.15, 0.35, vElevation); // Ajustado para nova altura de onda
      waterColor = mix(waterColor, uFoamColor, foamMask);

      vec3 viewDir = normalize(uCameraPos - vWorldPosition);
      if (length(viewDir) == 0.0) viewDir = vec3(0.0, 1.0, 0.0);

      float fresnelFactor = dot(viewDir, normal);
      float fresnel = pow(1.0 - abs(fresnelFactor), 3.0);
      vec3 skyColor = vec3(0.6, 0.8, 0.95); 
      waterColor = mix(waterColor, skyColor, fresnel * 0.6);

      vec3 lightDir = normalize(vec3(0.5, 0.8, 0.2)); 
      vec3 reflectDir = reflect(-lightDir, normal);
      float specular = pow(max(dot(viewDir, reflectDir), 0.0), 32.0);
      float safeSpecular = min(specular, 5.0);

      waterColor += vec3(1.0) * safeSpecular * 2.0;

      float alpha = 0.85 + (fresnel * 0.15); 
      waterColor = min(waterColor, vec3(10.0));
      
      gl_FragColor = vec4(waterColor, alpha); 
    }
  `
};

// GLOBAL MATERIAL INSTANCE
const sharedWaterMaterial = new THREE.ShaderMaterial({
  ...WaterShader,
  transparent: true,
  side: THREE.DoubleSide,
  depthWrite: false,
});

export const WaterGlobals: React.FC = () => {
  const { camera, clock } = useThree();
  useFrame(() => {
    sharedWaterMaterial.uniforms.uTime.value = clock.getElapsedTime();
    sharedWaterMaterial.uniforms.uCameraPos.value.copy(camera.position);
  });
  return null;
};

interface WaterProps {
  x: number;
  z: number;
  lodLevel: number;
}

const Water: React.FC<WaterProps> = ({ x, z, lodLevel }) => {
  const worldX = x * CHUNK_SIZE; 
  const worldZ = z * CHUNK_SIZE;

  // PlaneGeometry centralizado
  const centerX = worldX + CHUNK_SIZE / 2;
  const centerZ = worldZ + CHUNK_SIZE / 2;

  const geometry = useMemo(() => {
    const segments = Math.max(4, Math.floor(64 / lodLevel));
    const geo = new THREE.PlaneGeometry(CHUNK_SIZE, CHUNK_SIZE, segments, segments);
    geo.boundingSphere = new THREE.Sphere(new THREE.Vector3(0, 0, 0), CHUNK_SIZE * 0.8);
    return geo;
  }, [lodLevel]);

  return (
    <mesh 
      position={[centerX, 0, centerZ]} 
      rotation={[-Math.PI / 2, 0, 0]}
      geometry={geometry}
      material={sharedWaterMaterial} 
      scale={[1.005, 1.005, 1]}
      frustumCulled={true}
    />
  );
};

export default React.memo(Water);
