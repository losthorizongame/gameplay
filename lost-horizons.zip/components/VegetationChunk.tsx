
import React, { useMemo, useEffect, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { CHUNK_SIZE, WATER_LEVEL, VEGETATION_STEP_HIGH, VEGETATION_STEP_LOW } from '../types';
import { getTerrainHeight, getHumidity, getTreeDensity, getRockDensity, getObstaclesInChunk } from '../services/MathUtils';

interface VegetationChunkProps {
  chunkX: number;
  chunkZ: number;
  lodLevel: number;
}

const hashCoordinates = (x: number, z: number): number => {
  let h = 0x811c9dc5;
  h ^= Math.floor(x);
  h = Math.imul(h, 0x01000193);
  h ^= Math.floor(z);
  h = Math.imul(h, 0x01000193);
  return (h >>> 0) / 4294967296; 
};

// --- GEOMETRIAS OTIMIZADAS (EXTREME LOW POLY) ---
// OTIMIZAÇÃO: Reduzido de 4 para 3 ou 4 segmentos radiais.
// Para árvores em massa, 4 lados é suficiente.
const trunkGeometry = new THREE.CylinderGeometry(0.3, 0.5, 2.5, 4);
trunkGeometry.translate(0, 1.25, 0);

// Folhagem: Cone simples de 4 lados
const pineFoliageGeometry = new THREE.ConeGeometry(2.5, 6, 4);
pineFoliageGeometry.translate(0, 4.5, 0);

// Carvalho: Dodecaedro é mais leve que Icosaedro para folhas arredondadas
const oakFoliageGeometry = new THREE.DodecahedronGeometry(2.2, 0);
oakFoliageGeometry.translate(0, 3.5, 0);

const rockGeometry = new THREE.DodecahedronGeometry(1.5, 0);
rockGeometry.translate(0, 0.8, 0);

// --- SHADER UNIFORMS COMPARTILHADOS ---
const vegetationShaderLogic = {
  uniforms: {
    uGlobalTime: { value: 0 } 
  },
  onBeforeCompile: (shader: any) => {
    shader.uniforms.uGlobalTime = vegetationShaderLogic.uniforms.uGlobalTime;

    shader.vertexShader = `
      uniform float uGlobalTime;
      
      vec3 getWind(vec3 pos, float t) {
        float windStrength = 0.1;
        float wave = sin(t * 1.5 + pos.x * 0.5 + pos.z * 0.5);
        float deform = wave * windStrength * max(0.0, position.y - 1.0); 
        return vec3(deform, 0.0, deform * 0.5);
      }
    ` + shader.vertexShader;

    shader.vertexShader = shader.vertexShader.replace(
      '#include <begin_vertex>',
      `
      #include <begin_vertex>
      // Vento simples aplicado no vertex shader
      // Apenas se y > 0 para fixar a base no chão
      if (position.y > 0.5) {
          vec3 wind = getWind(transformed, uGlobalTime);
          transformed += wind;
      }
      `
    );
  }
};

const trunkMaterial = new THREE.MeshStandardMaterial({ color: '#5c4033', roughness: 0.9 });
const pineMaterial = new THREE.MeshStandardMaterial({ color: '#2d4c1e', roughness: 0.8, flatShading: true });
const oakMaterial = new THREE.MeshStandardMaterial({ color: '#4a6b28', roughness: 0.8, flatShading: true });
const rockMaterial = new THREE.MeshStandardMaterial({ color: '#777777', roughness: 0.7, flatShading: true });

// Aplicar lógica a todos (apenas uma vez na inicialização)
[trunkMaterial, pineMaterial, oakMaterial].forEach(mat => {
    mat.onBeforeCompile = vegetationShaderLogic.onBeforeCompile;
});

const dummy = new THREE.Object3D();
const _color = new THREE.Color();

const VegetationChunk: React.FC<VegetationChunkProps> = ({ chunkX, chunkZ, lodLevel }) => {
  const pineTrunkRef = useRef<THREE.InstancedMesh>(null);
  const pineLeavesRef = useRef<THREE.InstancedMesh>(null);
  const oakTrunkRef = useRef<THREE.InstancedMesh>(null);
  const oakLeavesRef = useRef<THREE.InstancedMesh>(null);
  const rockRef = useRef<THREE.InstancedMesh>(null);
  const groupRef = useRef<THREE.Group>(null);

  const startTime = useRef(0);
  const initialized = useRef(false);

  useFrame((state) => {
    if (!initialized.current) {
        startTime.current = state.clock.getElapsedTime();
        initialized.current = true;
    }
    
    // Atualiza vento global
    vegetationShaderLogic.uniforms.uGlobalTime.value = state.clock.getElapsedTime();

    // Animação Grow-in na CPU (Scale do grupo inteiro)
    if (groupRef.current) {
        const age = state.clock.getElapsedTime() - startTime.current;
        if (age < 0.6) { // Rápido pop-in
            const p = age / 0.6;
            const scale = 1 - Math.pow(1 - p, 3);
            groupRef.current.scale.setScalar(scale);
        } else {
            groupRef.current.scale.setScalar(1);
        }
    }
  });

  const shouldRender = lodLevel <= 4;
  const renderRocks = lodLevel <= 2; // Pedras só bem de perto

  // OTIMIZAÇÃO DE SHADOWS:
  // Só LOD 1 (muito perto) projeta sombras. Isso é o maior ganho de FPS.
  const castShadows = lodLevel === 1;

  const treeData = useMemo(() => {
    if (!shouldRender) return { pines: [], oaks: [], rocks: [] };

    const pines = [];
    const oaks = [];
    const rocks = [];

    const worldX = chunkX * CHUNK_SIZE;
    const worldZ = chunkZ * CHUNK_SIZE;
    
    // DENSIDADE ADAPTATIVA:
    // LOD 1-2: Densidade Alta (VEGETATION_STEP_HIGH)
    // LOD 3-4: Densidade Baixa (VEGETATION_STEP_LOW)
    let step = lodLevel <= 2 ? VEGETATION_STEP_HIGH : VEGETATION_STEP_LOW;

    const checkCollisions = lodLevel <= 1;
    const obstacles = checkCollisions ? getObstaclesInChunk(chunkX, chunkZ) : [];

    // --- GERAÇÃO DE PEDRAS ---
    if (renderRocks) {
        const rockStep = step * 1.5; 
        const startGlobalX = Math.ceil(worldX / rockStep) * rockStep;
        const startGlobalZ = Math.ceil(worldZ / rockStep) * rockStep;
        
        for (let bx = startGlobalX; bx < worldX + CHUNK_SIZE; bx += rockStep) {
            for (let bz = startGlobalZ; bz < worldZ + CHUNK_SIZE; bz += rockStep) {
                // Lógica de pedra simplificada...
                const rockJitterX = (hashCoordinates(bx, bz) - 0.5) * rockStep;
                const rockJitterZ = (hashCoordinates(bx + 100, bz + 100) - 0.5) * rockStep;
                
                const globalRockX = bx + rockJitterX;
                const globalRockZ = bz + rockJitterZ;
                
                const localRockX = globalRockX - worldX;
                const localRockZ = globalRockZ - worldZ;
                
                const rh = getTerrainHeight(globalRockX, globalRockZ);
                const isSafeLand = rh > WATER_LEVEL + 3.0;
                const rockDensity = getRockDensity(globalRockX, globalRockZ);

                if (isSafeLand && rockDensity > 0.6 && rh < 35) {
                    const scale = 0.5 + (rockDensity * 1.5);
                    rocks.push({
                        position: [localRockX, rh - 0.6, localRockZ], 
                        scale: scale, 
                        rotation: rockDensity * Math.PI * 2,
                        tint: rockDensity
                    });
                }
            }
        }
    }

    // --- GERAÇÃO DE ÁRVORES ---
    const startTreeX = Math.ceil(worldX / step) * step;
    const startTreeZ = Math.ceil(worldZ / step) * step;

    for (let bx = startTreeX; bx < worldX + CHUNK_SIZE; bx += step) {
      for (let bz = startTreeZ; bz < worldZ + CHUNK_SIZE; bz += step) {
        
        const density = getTreeDensity(bx, bz);
        if (density < 0.6) continue;

        // Jitter menor para LOD distante para evitar buracos visíveis
        const jitterMult = lodLevel <= 2 ? 1.8 : 0.5;
        const jitterX = (density - 0.5) * step * jitterMult;
        const jitterZ = (getTreeDensity(bx + 50, bz + 50) - 0.5) * step * jitterMult;
        
        const tpx = bx + jitterX; 
        const tpz = bz + jitterZ; 
        
        const localX = tpx - worldX;
        const localZ = tpz - worldZ;

        // Bounds check
        if (localX < -5 || localX >= CHUNK_SIZE + 5 || localZ < -5 || localZ >= CHUNK_SIZE + 5) continue;

        const height = getTerrainHeight(tpx, tpz);
        if (height < WATER_LEVEL + 3.5 || height > 35) continue;

        // Colisão cara apenas perto
        if (checkCollisions) {
            const hNeighbor = getTerrainHeight(tpx + 2, tpz);
            if (Math.abs(height - hNeighbor) > 1.5) continue; 
            
            let blocked = false;
            const minDistSq = 5.5 * 5.5; 
            for (const obs of obstacles) {
               const dx = tpx - obs.x;
               const dz = tpz - obs.z;
               if (dx*dx + dz*dz < minDistSq) {
                   blocked = true;
                   break;
               }
            }
            if (blocked) continue;
        }

        const humidity = getHumidity(tpx, tpz);
        if (humidity < 0.35) continue; 

        // Escala ligeiramente maior ao longe para preencher visualmente
        const distScale = lodLevel > 2 ? 1.5 : 1.0;
        
        const treeInfo = { 
            position: [localX, height, localZ], 
            scale: (0.8 + (density * 0.7)) * distScale, 
            rotation: density * Math.PI * 5, 
            tint: density
        };

        if (height > 25) {
            pines.push(treeInfo);
        } else if (humidity > 0.65) {
            if (density > 0.7) oaks.push(treeInfo);
            else pines.push(treeInfo);
        } else if (humidity > 0.45) {
             oaks.push(treeInfo);
        } 
      }
    }

    return { pines, oaks, rocks };
  }, [chunkX, chunkZ, shouldRender, renderRocks, lodLevel]); 

  useEffect(() => {
    if (!treeData) return;

    // --- CORREÇÃO DE GLITCH VISUAL (BOUNDING SPHERE) ---
    // Calculamos manualmente a bounding sphere do chunk inteiro.
    // Como sabemos que o chunk é 64x64, uma esfera de raio 50 no centro (32, 0, 32) cobre tudo.
    // Isso garante que o Frustum Culling do Three.js não esconda as árvores incorretamente.
    const boundingSphere = new THREE.Sphere(new THREE.Vector3(CHUNK_SIZE/2, 10, CHUNK_SIZE/2), 60);

    const updateMesh = (ref: React.RefObject<THREE.InstancedMesh>, data: any[], colorBase: number, colorVar: boolean) => {
        if (!ref.current) return;
        
        ref.current.count = data.length;
        // Aplica a esfera de culling manual
        ref.current.geometry.boundingSphere = boundingSphere;

        data.forEach((d, i) => {
            dummy.position.set(d.position[0], d.position[1], d.position[2]);
            dummy.scale.set(d.scale, d.scale, d.scale);
            dummy.rotation.set(0, d.rotation, 0);
            dummy.updateMatrix();
            ref.current!.setMatrixAt(i, dummy.matrix);
            
            if (colorVar) {
                _color.setHex(colorBase);
                // Variação HSL leve
                _color.offsetHSL(colorBase === 0x5c4033 ? 0 : (d.tint - 0.5) * 0.1, 0, 0);
                ref.current!.setColorAt(i, _color);
            }
        });

        ref.current.instanceMatrix.needsUpdate = true;
        if (ref.current.instanceColor) ref.current.instanceColor.needsUpdate = true;
    }

    updateMesh(pineTrunkRef, treeData.pines, 0x5c4033, false);
    updateMesh(pineLeavesRef, treeData.pines, 0x2d4c1e, true);
    updateMesh(oakTrunkRef, treeData.oaks, 0x5c4033, false);
    updateMesh(oakLeavesRef, treeData.oaks, 0x4a6b28, true);
    if (renderRocks) updateMesh(rockRef, treeData.rocks, 0x777777, true);

  }, [treeData, renderRocks]);

  if (!shouldRender) return null;

  return (
    <group ref={groupRef} position={[chunkX * CHUNK_SIZE, 0, chunkZ * CHUNK_SIZE]}>
      {/* FRUSTUM CULLED = TRUE (Performance Crucial) */}
      <instancedMesh ref={pineTrunkRef} args={[trunkGeometry, trunkMaterial, treeData.pines.length]} castShadow={castShadows} receiveShadow={castShadows} frustumCulled={true} />
      <instancedMesh ref={pineLeavesRef} args={[pineFoliageGeometry, pineMaterial, treeData.pines.length]} castShadow={castShadows} receiveShadow={castShadows} frustumCulled={true} />

      <instancedMesh ref={oakTrunkRef} args={[trunkGeometry, trunkMaterial, treeData.oaks.length]} castShadow={castShadows} receiveShadow={castShadows} frustumCulled={true} />
      <instancedMesh ref={oakLeavesRef} args={[oakFoliageGeometry, oakMaterial, treeData.oaks.length]} castShadow={castShadows} receiveShadow={castShadows} frustumCulled={true} />
      
      {renderRocks ? (
         <instancedMesh ref={rockRef} args={[rockGeometry, rockMaterial, treeData.rocks.length]} castShadow={castShadows} receiveShadow={castShadows} frustumCulled={true} />
      ) : null}
    </group>
  );
};

export default React.memo(VegetationChunk);
