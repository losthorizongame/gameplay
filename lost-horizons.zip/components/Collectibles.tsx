
import React, { useRef, useMemo, useEffect } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { DropData, Vector3 } from '../types';
import { getTerrainHeight } from '../services/MathUtils';

interface CollectiblesProps {
  drops: DropData[];
  playerPos: THREE.Vector3;
  onCollect: (id: string, type: 'wood' | 'stone') => void;
}

const woodColor = new THREE.Color('#5c4033'); 
const stoneColor = new THREE.Color('#888888');

// Dados internos de física para evitar re-render do React
interface PhysicsState {
  id: string;
  type: 'wood' | 'stone';
  pos: THREE.Vector3;
  velY: number;
  active: boolean;
}

const Collectibles: React.FC<CollectiblesProps> = ({ drops, playerPos, onCollect }) => {
  const woodMeshRef = useRef<THREE.InstancedMesh>(null);
  const stoneMeshRef = useRef<THREE.InstancedMesh>(null);
  const dummy = useMemo(() => new THREE.Object3D(), []);
  
  // Estado local de física sincronizado com props.drops
  const physicsRef = useRef<PhysicsState[]>([]);

  // Sincronizar drops do React com estado de física local
  useEffect(() => {
    // Adicionar novos drops
    drops.forEach(d => {
       const exists = physicsRef.current.find(p => p.id === d.id);
       if (!exists) {
           physicsRef.current.push({
               id: d.id,
               type: d.type,
               pos: new THREE.Vector3(d.position.x, d.position.y, d.position.z),
               velY: 0,
               active: true
           });
       }
    });

    // Remover drops coletados (que não estão mais em props.drops)
    physicsRef.current = physicsRef.current.filter(p => 
        drops.some(d => d.id === p.id)
    );

  }, [drops]);

  const woodGeometry = useMemo(() => {
    const geo = new THREE.CylinderGeometry(0.12, 0.12, 0.6, 6);
    geo.rotateZ(Math.PI / 2); 
    return geo;
  }, []);

  const stoneGeometry = useMemo(() => new THREE.DodecahedronGeometry(0.25, 0), []);
  
  const material = useMemo(() => new THREE.MeshStandardMaterial({ 
      roughness: 0.8,
      flatShading: true
  }), []);

  useFrame((state, delta) => {
    const time = state.clock.getElapsedTime();
    const dt = Math.min(delta, 0.05);

    let woodCount = 0;
    let stoneCount = 0;

    // Física Loop
    physicsRef.current.forEach(p => {
        if (!p.active) return;

        // 1. Gravidade
        const groundH = getTerrainHeight(p.pos.x, p.pos.z);
        
        if (p.pos.y > groundH + 0.3) {
            p.velY -= 15 * dt; // Gravidade
            p.pos.y += p.velY * dt;
        } else {
            p.pos.y = groundH + 0.3; // Chão
            p.velY = 0;
        }

        // 2. Ímã (Magnet)
        const distSq = p.pos.distanceToSquared(playerPos);
        
        // Coleta automática se muito perto (< 1.5m)
        if (distSq < 2.25) { 
            onCollect(p.id, p.type);
            p.active = false; // Desativa localmente para não renderizar no próximo frame
            return;
        }

        // Se estiver perto (< 6m), puxar para o jogador
        if (distSq < 36) {
            const dir = new THREE.Vector3().subVectors(playerPos, p.pos).normalize();
            const strength = (6.0 - Math.sqrt(distSq)) * 2.0; // Mais forte quanto mais perto
            p.pos.add(dir.multiplyScalar(strength * dt));
        }

        // Renderização
        dummy.position.copy(p.pos);
        
        // Animação visual (flutuar levemente + girar)
        const floatOffset = Math.sin(time * 3 + p.pos.x) * 0.1;
        dummy.position.y += floatOffset;
        dummy.rotation.set(0, time * 2, 0);
        dummy.scale.setScalar(1.0);
        dummy.updateMatrix();

        if (p.type === 'wood' && woodMeshRef.current) {
            woodMeshRef.current.setMatrixAt(woodCount, dummy.matrix);
            woodMeshRef.current.setColorAt(woodCount, woodColor);
            woodCount++;
        } else if (p.type === 'stone' && stoneMeshRef.current) {
            stoneMeshRef.current.setMatrixAt(stoneCount, dummy.matrix);
            stoneMeshRef.current.setColorAt(stoneCount, stoneColor);
            stoneCount++;
        }
    });

    // Atualizar Instanced Meshes
    if (woodMeshRef.current) {
        woodMeshRef.current.count = woodCount;
        woodMeshRef.current.instanceMatrix.needsUpdate = true;
        if (woodMeshRef.current.instanceColor) woodMeshRef.current.instanceColor.needsUpdate = true;
    }
    if (stoneMeshRef.current) {
        stoneMeshRef.current.count = stoneCount;
        stoneMeshRef.current.instanceMatrix.needsUpdate = true;
        if (stoneMeshRef.current.instanceColor) stoneMeshRef.current.instanceColor.needsUpdate = true;
    }
  });

  return (
    <group>
        <instancedMesh ref={woodMeshRef} args={[woodGeometry, material, 500]} castShadow />
        <instancedMesh ref={stoneMeshRef} args={[stoneGeometry, material, 500]} castShadow />
    </group>
  );
};

export default React.memo(Collectibles);
