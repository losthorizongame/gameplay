
import React, { useRef, useMemo, useState } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import * as THREE from 'three';

interface BeaconProps {
  position: THREE.Vector3;
  isLit: boolean; // Se true, tem fogo intenso. Se false, é apenas o "fantasma" do objetivo.
  isNext?: boolean; // Se é o próximo objetivo
  variant?: 'beacon' | 'crystal' | 'monolith' | 'artifact';
}

// --- TEXTURA PROCEDURAL PARA O GLOW (SPRITE) ---
const glowTexture = new THREE.CanvasTexture((() => {
  const canvas = document.createElement('canvas');
  canvas.width = 64; 
  canvas.height = 64;
  const ctx = canvas.getContext('2d');
  if (ctx) {
      const grad = ctx.createRadialGradient(32, 32, 0, 32, 32, 32);
      grad.addColorStop(0, 'rgba(255, 200, 50, 1)'); 
      grad.addColorStop(0.4, 'rgba(255, 100, 0, 0.5)'); 
      grad.addColorStop(1, 'rgba(0, 0, 0, 0)'); 
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, 64, 64);
  }
  return canvas;
})());

// --- SHADER DE FOGO LOW-POLY ---
const FireShader = {
  uniforms: {
    uTime: { value: 0 },
    uColorA: { value: new THREE.Color('#ffaa00') },
    uColorB: { value: new THREE.Color('#ff2200') },
  },
  vertexShader: `
    uniform float uTime;
    varying float vHeight;
    varying vec2 vUv;

    // Simple noise
    float hash(float n) { return fract(sin(n) * 43758.5453123); }
    float noise(vec3 x) {
        vec3 p = floor(x);
        vec3 f = fract(x);
        f = f * f * (3.0 - 2.0 * f);
        float n = p.x + p.y * 57.0 + 113.0 * p.z;
        return mix(mix(mix(hash(n + 0.0), hash(n + 1.0), f.x),
                       mix(hash(n + 57.0), hash(n + 58.0), f.x), f.y),
                   mix(mix(hash(n + 113.0), hash(n + 114.0), f.x),
                       mix(hash(n + 170.0), hash(n + 171.0), f.x), f.y), f.z);
    }

    void main() {
      vUv = uv;
      vec3 pos = position;
      
      float noiseVal = noise(vec3(pos.x * 2.0, pos.z * 2.0, uTime * 3.0 + pos.y));
      float strength = pos.y * 0.5; 
      pos.x += (noiseVal - 0.5) * strength;
      pos.z += (noiseVal - 0.5) * strength;
      
      float pulse = 1.0 + sin(uTime * 5.0 + pos.y * 10.0) * 0.1 * strength;
      pos.x *= pulse;
      pos.z *= pulse;

      vHeight = pos.y;
      gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
    }
  `,
  fragmentShader: `
    uniform vec3 uColorA;
    uniform vec3 uColorB;
    varying float vHeight;

    void main() {
      float t = smoothstep(0.0, 2.5, vHeight);
      vec3 color = mix(uColorA, uColorB, t);
      float alpha = 1.0 - smoothstep(1.5, 2.5, vHeight);
      if (alpha < 0.1) discard;
      gl_FragColor = vec4(color, alpha);
    }
  `
};

const materials = {
  stone: new THREE.MeshStandardMaterial({ color: 0x444444, roughness: 0.9, flatShading: true }),
  wood: new THREE.MeshStandardMaterial({ color: 0x3d2817, roughness: 1.0 }),
  glow: new THREE.MeshBasicMaterial({ color: 0xffaa00, transparent: true, opacity: 0.2, side: THREE.DoubleSide, blending: THREE.AdditiveBlending, depthWrite: false }),
  beam: new THREE.MeshBasicMaterial({ color: 0xffdd88, transparent: true, opacity: 0.1, side: THREE.DoubleSide, blending: THREE.AdditiveBlending, depthWrite: false }),
  ghostBeam: new THREE.MeshBasicMaterial({ color: 0xffff00, transparent: true, opacity: 0.05, side: THREE.DoubleSide, blending: THREE.AdditiveBlending, depthWrite: false }),
  sprite: new THREE.SpriteMaterial({ map: glowTexture, color: 0xffaa00, blending: THREE.AdditiveBlending, depthWrite: false }),
  crystal: new THREE.MeshPhysicalMaterial({ color: 0x00ffff, transmission: 0.6, roughness: 0.1, thickness: 1.0, emissive: 0x0044aa, emissiveIntensity: 0.5 }),
  monolith: new THREE.MeshStandardMaterial({ color: 0x1a1a1a, roughness: 0.4, metalness: 0.8 }),
  artifact: new THREE.MeshStandardMaterial({ color: 0xffd700, metalness: 1.0, roughness: 0.3 })
};

const AncientBeacon: React.FC<BeaconProps> = ({ position, isLit, isNext, variant = 'beacon' }) => {
  const { camera } = useThree();
  const fireRef = useRef<THREE.Mesh>(null);
  const beamRef = useRef<THREE.Mesh>(null);
  const lightRef = useRef<THREE.PointLight>(null);
  const variantMeshRef = useRef<THREE.Mesh>(null);
  
  const fireMat = useMemo(() => new THREE.ShaderMaterial({
      ...FireShader,
      transparent: true,
      side: THREE.DoubleSide,
      depthWrite: false, 
      blending: THREE.AdditiveBlending
  }), []);

  // LIGHT CULLING LOGIC
  const CULL_DIST_SQ = 120 * 120;
  const ACTIVATE_DIST_SQ = 110 * 110;

  useFrame((state) => {
    const t = state.clock.getElapsedTime();
    
    if (isLit && fireRef.current) {
        fireMat.uniforms.uTime.value = t;
        fireRef.current.rotation.y = -t * 0.5;
    }

    if (beamRef.current) {
        const pulse = 0.5 + Math.sin(t * 2.0) * 0.1;
        beamRef.current.scale.set(1 + pulse*0.2, 1, 1 + pulse*0.2);
        beamRef.current.rotation.y = t * 0.2;
    }

    if (variantMeshRef.current) {
        variantMeshRef.current.rotation.y = t * 0.3;
        if (!isLit) {
            variantMeshRef.current.position.y = 3.0 + Math.sin(t * 2) * 0.2;
        }
    }

    if (lightRef.current) {
        const distSq = camera.position.distanceToSquared(position);
        if (lightRef.current.visible) {
            if (distSq > CULL_DIST_SQ) lightRef.current.visible = false;
        } else {
            if (distSq < ACTIVATE_DIST_SQ) lightRef.current.visible = true;
        }
    }
  });

  const renderBase = () => (
      <>
        <mesh position={[0, -0.5, 0]} receiveShadow castShadow material={materials.stone}>
           <cylinderGeometry args={[2.5, 3.0, 1.5, 7]} />
        </mesh>
        <mesh position={[0, 0.5, 0]} receiveShadow castShadow material={materials.stone}>
           <cylinderGeometry args={[2.0, 2.3, 0.8, 6]} />
        </mesh>
      </>
  );

  return (
    <group position={[position.x, position.y, position.z]}>
      
      {/* SE FOR UM FAROL, TEM A ESTRUTURA COMPLETA */}
      {variant === 'beacon' && (
        <>
          {renderBase()}
          <mesh position={[0, 1.5, 0]} receiveShadow castShadow material={materials.stone}>
             <cylinderGeometry args={[1.2, 1.2, 2.0, 5]} />
          </mesh>
          <mesh position={[0, 2.8, 0]} receiveShadow castShadow material={materials.stone}>
             <cylinderGeometry args={[1.8, 1.0, 0.8, 8]} />
          </mesh>
          <group position={[0, 3.0, 0]}>
             <mesh rotation={[0.2, 0.5, 0.3]} material={materials.wood}><cylinderGeometry args={[0.15, 0.15, 1.8]} /></mesh>
             <mesh rotation={[-0.3, 1.2, -0.2]} material={materials.wood}><cylinderGeometry args={[0.15, 0.15, 1.8]} /></mesh>
          </group>
        </>
      )}

      {/* OUTRAS VARIANTES FLUTUAM OU TEM BASES SIMPLES */}
      {variant === 'crystal' && (
         <>
             <mesh position={[0, 0, 0]} material={materials.stone}><cylinderGeometry args={[0.5, 1.5, 2.0, 5]} /></mesh>
             <mesh ref={variantMeshRef} position={[0, 3.0, 0]} material={materials.crystal}>
                 <dodecahedronGeometry args={[1.5, 0]} />
             </mesh>
         </>
      )}

      {variant === 'monolith' && (
         <mesh ref={variantMeshRef} position={[0, 3.0, 0]} material={materials.monolith} castShadow>
             <boxGeometry args={[1.2, 6.0, 0.4]} />
         </mesh>
      )}

      {variant === 'artifact' && (
         <group ref={variantMeshRef} position={[0, 3.0, 0]}>
             <mesh material={materials.artifact}><torusKnotGeometry args={[0.6, 0.2, 64, 8]} /></mesh>
         </group>
      )}

      {/* --- ESTADO: ACESO --- */}
      {isLit && (
        <>
            {variant === 'beacon' && (
                <mesh ref={fireRef} position={[0, 3.0, 0]} material={fireMat}>
                    <cylinderGeometry args={[0.1, 1.2, 2.5, 8, 2, true]} /> 
                </mesh>
            )}

            <pointLight ref={lightRef} position={[0, 4.0, 0]} intensity={3.0} distance={40} color={variant === 'crystal' ? '#00ffff' : '#ff6600'} decay={1.5} />
            <sprite position={[0, 4.0, 0]} scale={[8, 8, 1]} material={materials.sprite} />
            <mesh ref={beamRef} position={[0, 100, 0]}>
                <cylinderGeometry args={[2, 6, 200, 16, 1, true]} />
                <primitive object={materials.beam} />
            </mesh>
        </>
      )}

      {/* --- ESTADO: OBJETIVO ATUAL (Ainda não aceso) --- */}
      {isNext && !isLit && (
         <>
            <mesh ref={beamRef} position={[0, 100, 0]}>
                <cylinderGeometry args={[0.5, 1.0, 200, 8, 1, true]} />
                <primitive object={materials.ghostBeam} />
            </mesh>
            <pointLight ref={lightRef} position={[0, 4.0, 0]} intensity={1.5} distance={15} color="#ffff00" decay={2} />
         </>
      )}
    </group>
  );
};

export default AncientBeacon;
