
import React, { useMemo, useRef, useEffect } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { CHUNK_SIZE, WATER_LEVEL } from '../types';
import { getTerrainHeight, getHumidity, getObstaclesInChunk } from '../services/MathUtils';

interface GrassChunkProps {
  chunkX: number;
  chunkZ: number;
}

// GEOMETRIA DA GRAMA: TUFOS OTIMIZADOS
const grassGeometry = new THREE.BufferGeometry();

// OTIMIZAÇÃO: Reduzido de 3 para 2 para ganhar fill-rate
const BLADES_PER_TUFT = 2; 
const verts: number[] = [];
const uvs: number[] = [];
const indices: number[] = [];

let vertIdx = 0;

for (let i = 0; i < BLADES_PER_TUFT; i++) {
  const r = Math.random() * 0.4;
  const theta = Math.random() * Math.PI * 2;
  const xOff = r * Math.cos(theta);
  const zOff = r * Math.sin(theta);

  const w = 0.08 + Math.random() * 0.04; 
  const h = 0.7 + Math.random() * 0.5;   
  
  const tiltAngle = theta; 
  const leanFactor = 0.2 + Math.random() * 0.3;

  const bl = { x: -w/2, y: 0, z: 0 };
  const br = { x:  w/2, y: 0, z: 0 };
  const mid = { x: 0, y: h * 0.5, z: leanFactor * 0.4 }; 
  const top = { x: 0, y: h, z: leanFactor }; 

  const rotate = (p: {x:number, y:number, z:number}) => {
    const cos = Math.cos(tiltAngle);
    const sin = Math.sin(tiltAngle);
    return {
      x: p.x * cos - p.z * sin + xOff,
      y: p.y,
      z: p.x * sin + p.z * cos + zOff
    };
  };

  const v0 = rotate(bl);
  const v1 = rotate(br);
  const v2 = rotate(mid);
  const v3 = rotate(top);

  verts.push(
    v0.x, v0.y, v0.z, // 0
    v1.x, v1.y, v1.z, // 1
    v2.x, v2.y, v2.z, // 2
    v3.x, v3.y, v3.z  // 3
  );

  uvs.push(0, 0, 1, 0, 0.5, 0.5, 0.5, 1);

  indices.push(
    vertIdx, vertIdx + 1, vertIdx + 2,
    vertIdx + 2, vertIdx + 1, vertIdx + 3
  );

  vertIdx += 4;
}

const normals = new Float32Array(verts.length).fill(0);
for(let i=0; i<verts.length; i+=3) {
    normals[i+1] = 1.0; 
}

grassGeometry.setIndex(indices);
grassGeometry.setAttribute('position', new THREE.BufferAttribute(new Float32Array(verts), 3));
grassGeometry.setAttribute('uv', new THREE.BufferAttribute(new Float32Array(uvs), 2));
grassGeometry.setAttribute('normal', new THREE.BufferAttribute(normals, 3));

grassGeometry.boundingSphere = new THREE.Sphere(
  new THREE.Vector3(CHUNK_SIZE / 2, 20, CHUNK_SIZE / 2), 
  CHUNK_SIZE 
);

const grassMaterial = new THREE.MeshStandardMaterial({
  color: 0xffffff,
  roughness: 1.0, 
  metalness: 0.0,
  side: THREE.DoubleSide, 
  vertexColors: true,
});

const grassShaderLogic = {
  uniforms: {
    uTime: { value: 0 }
  },
  onBeforeCompile: (shader: any) => {
    shader.uniforms.uTime = grassShaderLogic.uniforms.uTime;
    
    shader.vertexShader = `
      uniform float uTime;
      varying vec2 vGrassUv;
      varying float vSway; 
      
      vec3 getWind(vec3 pos, float t) {
        float windA = sin(t * 0.7 + pos.x * 0.2 + pos.z * 0.2); 
        float windB = sin(t * 2.5 + pos.x * 1.0 + pos.z * 1.0) * 0.2; 
        
        float wave = windA + windB;
        float stiffness = pow(uv.y, 2.5); 
        
        float deformX = wave * 0.3 * stiffness; 
        float deformZ = cos(t * 1.5 + pos.x * 0.3) * 0.15 * stiffness;
        
        return vec3(deformX, 0.0, deformZ);
      }
    ` + shader.vertexShader;

    shader.vertexShader = shader.vertexShader.replace(
      '#include <begin_vertex>',
      `
      #include <begin_vertex>
      vGrassUv = uv;
      
      vec3 globalPos = (instanceMatrix * vec4(position, 1.0)).xyz;
      vec3 wind = getWind(globalPos, uTime);
      transformed += wind;
      vSway = length(wind);
      `
    );
    
    shader.fragmentShader = `
      varying vec2 vGrassUv;
      varying float vSway;
    ` + shader.fragmentShader;

    shader.fragmentShader = shader.fragmentShader.replace(
      '#include <color_fragment>',
      `
      #include <color_fragment>
      float ao = smoothstep(0.0, 0.5, vGrassUv.y);
      vec3 tipColor = vec3(1.0, 1.0, 0.5); 
      float tipStrength = smoothstep(0.6, 1.0, vGrassUv.y);
      diffuseColor.rgb *= (0.3 + ao * 0.7);
      diffuseColor.rgb = mix(diffuseColor.rgb, diffuseColor.rgb * tipColor * 1.5, tipStrength * 0.6);
      diffuseColor.rgb += vec3(0.05) * vSway;
      `
    );
  }
};

grassMaterial.onBeforeCompile = grassShaderLogic.onBeforeCompile;

const dummy = new THREE.Object3D();
const _color = new THREE.Color();

const GrassChunk: React.FC<GrassChunkProps> = ({ chunkX, chunkZ }) => {
  const meshRef = useRef<THREE.InstancedMesh>(null);
  
  // Controle de Grow-in
  const startTime = useRef(0);
  const initialized = useRef(false);
  const groupRef = useRef<THREE.Group>(null);

  useFrame((state) => {
    grassShaderLogic.uniforms.uTime.value = state.clock.getElapsedTime();
    
    // Animation Logic
    if (!initialized.current) {
        startTime.current = state.clock.getElapsedTime();
        initialized.current = true;
    }
    
    if (groupRef.current) {
        const age = state.clock.getElapsedTime() - startTime.current;
        if (age < 1.0) {
            // Suavização cúbica simples (Ease Out)
            const p = age;
            const scale = 1 - Math.pow(1 - p, 3);
            groupRef.current.scale.set(1, scale, 1); // Cresce apenas verticalmente para grama
        } else {
            groupRef.current.scale.set(1, 1, 1);
        }
    }
  });

  const instances = useMemo(() => {
    const data = [];
    const worldX = chunkX * CHUNK_SIZE;
    const worldZ = chunkZ * CHUNK_SIZE;
    const obstacles = getObstaclesInChunk(chunkX, chunkZ);
    const step = 5.0; 

    for (let x = 0; x < CHUNK_SIZE; x += step) {
      for (let z = 0; z < CHUNK_SIZE; z += step) {
        
        const jx = (Math.random() - 0.5) * step;
        const jz = (Math.random() - 0.5) * step;
        
        const px = worldX + x + jx;
        const pz = worldZ + z + jz;

        const h = getTerrainHeight(px, pz);
        
        if (h < WATER_LEVEL + 3.5) continue; 
        if (h > 32) continue; 

        const slope = Math.abs(h - getTerrainHeight(px + 1, pz));
        if (slope > 0.7) continue; 

        let blocked = false;
        for (const obs of obstacles) {
           const dx = px - obs.x;
           const dz = pz - obs.z;
           if (dx*dx + dz*dz < 20.25) {
               blocked = true;
               break;
           }
        }
        if (blocked) continue;

        const humidity = getHumidity(px, pz);
        if (humidity < 0.35) continue; 

        let colorHex = 0x387028;
        if (humidity < 0.55) colorHex = 0x8a9a48; 
        else if (humidity > 0.75) colorHex = 0x1a4512; 

        const scaleBase = 1.0; 
        const scaleVar = Math.random() * 0.5;
        
        data.push({
          pos: [x + jx, h, z + jz],
          scale: scaleBase + scaleVar,
          rotY: Math.random() * Math.PI * 2,
          colorHex,
          colorVar: (Math.random() - 0.5) * 0.1
        });
      }
    }
    return data;
  }, [chunkX, chunkZ]);

  useEffect(() => {
    if (!meshRef.current || instances.length === 0) return;

    meshRef.current.count = instances.length;

    instances.forEach((data, i) => {
      dummy.position.set(data.pos[0], data.pos[1], data.pos[2]);
      dummy.scale.set(data.scale, data.scale * (0.8 + Math.random() * 0.4), data.scale);
      dummy.rotation.y = data.rotY;
      
      dummy.updateMatrix();
      meshRef.current!.setMatrixAt(i, dummy.matrix);
      
      _color.setHex(data.colorHex);
      _color.offsetHSL(0, 0, data.colorVar);
      meshRef.current!.setColorAt(i, _color);
    });

    meshRef.current.instanceMatrix.needsUpdate = true;
    if (meshRef.current.instanceColor) meshRef.current.instanceColor.needsUpdate = true;

  }, [instances]);

  if (instances.length === 0) return null;

  return (
    <group ref={groupRef} position={[chunkX * CHUNK_SIZE, 0, chunkZ * CHUNK_SIZE]}>
        <instancedMesh
          ref={meshRef}
          args={[grassGeometry, grassMaterial, instances.length]}
          frustumCulled={true} 
          receiveShadow={true} 
          castShadow={false}
        />
    </group>
  );
};

export default React.memo(GrassChunk);
