
import React, { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

interface VillageObjectProps {
  type: 'well' | 'lamp' | 'campfire' | 'bench' | 'dock' | 'boat' | 'quest_board' | 'npc';
  position: [number, number, number];
  rotation: number;
}

const materials = {
  stone: new THREE.MeshStandardMaterial({ color: 0x5a5a5a, roughness: 0.9 }),
  wood: new THREE.MeshStandardMaterial({ color: 0x3d2817, roughness: 1.0 }),
  woodPlank: new THREE.MeshStandardMaterial({ color: 0x5c4033, roughness: 0.9 }), 
  woodLight: new THREE.MeshStandardMaterial({ color: 0x8f6a4e, roughness: 0.8 }),
  water: new THREE.MeshStandardMaterial({ 
      color: 0x4fa4d1, 
      roughness: 0.1, 
      metalness: 0.8,
      transparent: true,
      opacity: 0.8 
  }),
  fire: new THREE.MeshBasicMaterial({ color: 0xff4500 }),
  lampGlow: new THREE.MeshBasicMaterial({ color: 0xffffaa }),
  metal: new THREE.MeshStandardMaterial({ color: 0xcccccc, metalness: 0.8, roughness: 0.2 }),
  darkMetal: new THREE.MeshStandardMaterial({ color: 0x222222, metalness: 0.6, roughness: 0.5 }),
  glass: new THREE.MeshStandardMaterial({ 
    color: 0x88ccee, 
    roughness: 0.0, 
    metalness: 0.1, 
    transparent: true, 
    opacity: 0.15,
    side: THREE.DoubleSide
  }),
  roof: new THREE.MeshStandardMaterial({ color: 0x2c3e50, roughness: 0.6 }),
  white: new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.5 }),
  hullBottom: new THREE.MeshStandardMaterial({ color: 0x800000, roughness: 0.8 }),
  leather: new THREE.MeshStandardMaterial({ color: 0x8b0000, roughness: 0.6 }),
  display: new THREE.MeshBasicMaterial({ color: 0x00ff00 }), // Cor digital para o painel
  displayBg: new THREE.MeshStandardMaterial({ color: 0x111111, roughness: 0.4 }),
  parchment: new THREE.MeshStandardMaterial({ color: 0xf0e6d2, roughness: 0.9 }), // Cor de pergaminho
  npcRobe: new THREE.MeshStandardMaterial({ color: 0x4b0082, roughness: 0.9 }), // Roxo Índigo
  npcSkin: new THREE.MeshStandardMaterial({ color: 0xffdbac, roughness: 0.5 }),
  eyeGlow: new THREE.MeshBasicMaterial({ color: 0x00ffff }),
};

// Componente visual do barco (Geometry)
// Recebe velocityRef opcional para animar ponteiros se estiver sendo pilotado
export const BoatMesh: React.FC<{ velocityRef?: React.MutableRefObject<THREE.Vector3> }> = ({ velocityRef }) => {
  const needleRef = useRef<THREE.Group>(null);

  useFrame(() => {
    if (velocityRef && needleRef.current) {
        // Velocidade atual (magnitude X/Z)
        const speed = Math.sqrt(velocityRef.current.x**2 + velocityRef.current.z**2);
        // Mapeia 0-30 m/s para rotação do ponteiro (aprox -2.5 a 2.5 rads)
        const rot = Math.min(speed / 30, 1.0) * -3.0 + 1.5;
        needleRef.current.rotation.z = THREE.MathUtils.lerp(needleRef.current.rotation.z, rot, 0.1);
    }
  });

  return (
  <group>
    {/* Casco Inferior */}
    <mesh position={[0, -0.7, 0.5]} material={materials.hullBottom} castShadow><boxGeometry args={[2.8, 1.2, 6.0]} /></mesh>
    <mesh position={[0, -0.7, 4.0]} rotation={[0, Math.PI / 4, 0]} material={materials.hullBottom} castShadow><boxGeometry args={[1.9, 1.2, 1.9]} /></mesh>
    
    {/* Convés */}
    <mesh position={[0, 0.3, 0.5]} material={materials.white} castShadow><boxGeometry args={[3.0, 0.8, 6.2]} /></mesh>
    <mesh position={[0, 0.3, 4.1]} rotation={[0, Math.PI / 4, 0]} material={materials.white} castShadow><boxGeometry args={[2.05, 0.8, 2.05]} /></mesh>

    {/* Piso Madeira (Elevado para garantir que água não clipe) */}
    <mesh position={[0, 0.75, -1.5]} material={materials.woodLight} receiveShadow><boxGeometry args={[2.6, 0.1, 2.0]} /></mesh>
    <mesh position={[0, 0.75, 1.5]} material={materials.woodPlank} receiveShadow><boxGeometry args={[2.6, 0.1, 3.5]} /></mesh>
    <mesh position={[0, 0.75, 4.0]} rotation={[0, Math.PI/4, 0]} material={materials.white} receiveShadow><boxGeometry args={[1.8, 0.1, 1.8]} /></mesh>

    {/* Cabine Detalhada */}
    <group position={[0, 0.7, 1.0]}>
        {/* Laterais */}
        <mesh position={[1.4, 1.0, 0.5]} material={materials.white} castShadow><boxGeometry args={[0.1, 2.0, 3.5]} /></mesh>
        <mesh position={[-1.4, 1.0, 0.5]} material={materials.white} castShadow><boxGeometry args={[0.1, 2.0, 3.5]} /></mesh>
        
        {/* Frente da cabine */}
        <mesh position={[0, 0.5, 2.2]} material={materials.white} castShadow><boxGeometry args={[2.9, 1.0, 0.2]} /></mesh>

        {/* Vidro Frontal e Laterais */}
        <mesh position={[0, 1.5, 2.15]} rotation={[-0.2, 0, 0]} material={materials.glass}><boxGeometry args={[2.8, 1.1, 0.05]} /></mesh>
        <mesh position={[1.4, 1.5, 0.5]} material={materials.glass}><boxGeometry args={[0.05, 0.9, 3.0]} /></mesh>
        <mesh position={[-1.4, 1.5, 0.5]} material={materials.glass}><boxGeometry args={[0.05, 0.9, 3.0]} /></mesh>

        <mesh position={[0, 2.1, 0.8]} material={materials.roof} castShadow><boxGeometry args={[3.2, 0.15, 4.5]} /></mesh>
        
        {/* Colunas do vidro */}
        <mesh position={[1.35, 1.0, -1.2]} material={materials.white}><cylinderGeometry args={[0.05, 0.05, 2.0]} /></mesh>
        <mesh position={[-1.35, 1.0, -1.2]} material={materials.white}><cylinderGeometry args={[0.05, 0.05, 2.0]} /></mesh>

        {/* --- PAINEL DE CONTROLE / DASHBOARD --- */}
        <group position={[0, 0.7, 1.8]}>
             {/* Base do Painel */}
             <mesh rotation={[-0.5, 0, 0]} material={materials.darkMetal} castShadow><boxGeometry args={[2.0, 0.4, 0.5]} /></mesh>
             
             {/* Volante */}
             <group position={[-0.6, 0.25, -0.3]} rotation={[0.5, 0, 0]}>
                 <mesh material={materials.metal}><torusGeometry args={[0.25, 0.03, 8, 16]} /></mesh>
                 <mesh rotation={[0, 0, Math.PI/2]} material={materials.metal}><cylinderGeometry args={[0.02, 0.02, 0.5]} /></mesh>
                 <mesh material={materials.metal}><cylinderGeometry args={[0.02, 0.02, 0.5]} /></mesh>
             </group>

             {/* Mostrador de Velocidade (Fixo no mesh) */}
             <group position={[0, 0.25, -0.22]} rotation={[-0.5, 0, 0]}>
                 <mesh material={materials.displayBg}><cylinderGeometry args={[0.15, 0.15, 0.02, 32]} /></mesh>
                 
                 {/* Ponteiro Animado */}
                 <group ref={needleRef} rotation={[0, 0, 1.5]}>
                    <mesh position={[0, 0.05, 0.02]} material={materials.fire}><boxGeometry args={[0.02, 0.1, 0.01]} /></mesh>
                 </group>
             </group>

             {/* Telas / Botões */}
             <mesh position={[0.6, 0.2, -0.25]} rotation={[-0.5, 0, 0]} material={materials.display}><boxGeometry args={[0.4, 0.2, 0.01]} /></mesh>
             <mesh position={[0.3, 0.1, -0.2]} rotation={[-0.5, 0, 0]} material={materials.metal}><boxGeometry args={[0.05, 0.05, 0.05]} /></mesh>
             <mesh position={[0.4, 0.1, -0.2]} rotation={[-0.5, 0, 0]} material={materials.metal}><boxGeometry args={[0.05, 0.05, 0.05]} /></mesh>
        </group>

        {/* Assento do Piloto */}
        <group position={[-0.6, 0.4, 0.8]}>
             <mesh position={[0, 0.4, 0]} material={materials.leather}><boxGeometry args={[0.6, 0.1, 0.6]} /></mesh>
             <mesh position={[0, 0.8, -0.28]} material={materials.leather}><boxGeometry args={[0.6, 0.7, 0.1]} /></mesh>
             <mesh position={[0, 0.2, 0]} material={materials.metal}><cylinderGeometry args={[0.1, 0.1, 0.4]} /></mesh>
        </group>
        
        {/* Assento Copiloto */}
        <group position={[0.6, 0.4, 0.8]}>
             <mesh position={[0, 0.4, 0]} material={materials.leather}><boxGeometry args={[0.6, 0.1, 0.6]} /></mesh>
             <mesh position={[0, 0.8, -0.28]} material={materials.leather}><boxGeometry args={[0.6, 0.7, 0.1]} /></mesh>
             <mesh position={[0, 0.2, 0]} material={materials.metal}><cylinderGeometry args={[0.1, 0.1, 0.4]} /></mesh>
        </group>

        {/* Assentos Laterais Passageiros */}
        <mesh position={[1.0, 0.3, -0.5]} material={materials.leather}><boxGeometry args={[0.5, 0.4, 1.5]} /></mesh>
        <mesh position={[-1.0, 0.3, -0.5]} material={materials.leather}><boxGeometry args={[0.5, 0.4, 1.5]} /></mesh>
    </group>

    {/* Antena / Radar */}
    <group position={[0, 1.2, 3.5]}>
        <mesh position={[0, 0, 1.5]} material={materials.metal}><boxGeometry args={[0.05, 0.5, 0.05]} /></mesh>
        <mesh position={[1.0, 0, 0]} material={materials.metal}><boxGeometry args={[0.05, 0.5, 0.05]} /></mesh>
        <mesh position={[-1.0, 0, 0]} material={materials.metal}><boxGeometry args={[0.05, 0.5, 0.05]} /></mesh>
        <mesh position={[0.5, 0.25, 0.8]} rotation={[0, 0.6, 0]} material={materials.metal}><boxGeometry args={[0.05, 0.05, 2.0]} /></mesh>
        <mesh position={[-0.5, 0.25, 0.8]} rotation={[0, -0.6, 0]} material={materials.metal}><boxGeometry args={[0.05, 0.05, 2.0]} /></mesh>
    </group>

    <group position={[0, 2.8, 1.0]}>
        <mesh material={materials.white}><cylinderGeometry args={[0.3, 0.3, 0.2, 16]} /></mesh>
        <mesh position={[0, 0.3, 0]} rotation={[0, 0, Math.PI/2]} material={materials.metal}><cylinderGeometry args={[0.02, 0.02, 1.5]} /></mesh>
        <mesh position={[0, 0.2, 0]} material={materials.darkMetal}><boxGeometry args={[0.1, 0.4, 0.1]} /></mesh>
    </group>

    {/* Motor Traseiro */}
    <group position={[0, 0.2, -3.2]}>
        <mesh material={materials.darkMetal}><boxGeometry args={[0.8, 1.2, 0.8]} /></mesh>
        <mesh position={[0, -0.6, 0.2]} material={materials.metal}><cylinderGeometry args={[0.1, 0.05, 0.4]} /></mesh>
        <mesh position={[0, -0.7, 0.4]} rotation={[Math.PI/2, 0, 0]} material={materials.metal}><boxGeometry args={[0.6, 0.1, 0.05]} /></mesh>
         <mesh position={[0, -0.7, 0.4]} rotation={[Math.PI/2, Math.PI/2, 0]} material={materials.metal}><boxGeometry args={[0.6, 0.1, 0.05]} /></mesh>
    </group>
  </group>
  );
};

// Componente Wrapper para animar o barco estacionado
const FloatingBoat: React.FC<{ position: [number, number, number], rotation: number }> = ({ position, rotation }) => {
    const groupRef = useRef<THREE.Group>(null);
    
    useFrame(({ clock }) => {
        if (groupRef.current) {
            const t = clock.getElapsedTime();
            // Flutuação Vertical
            const floatY = Math.sin(t * 1.5 + position[0]) * 0.1;
            // Balanço (Rocking)
            const rockX = Math.cos(t * 0.8 + position[2]) * 0.03; 
            const rockZ = Math.sin(t * 0.6 + position[0]) * 0.02;

            groupRef.current.position.y = position[1] + floatY;
            
            // Mantém a rotação original Y do barco e adiciona o balanço em X e Z
            groupRef.current.rotation.set(rockX, rotation, rockZ);
        }
    });

    return (
        <group ref={groupRef} position={position} rotation={[0, rotation, 0]}>
            {/* Como o grupo já tem a rotação base, resetamos a rotação Y interna para não dobrar */}
            <group rotation={[0, -rotation, 0]}>
                <BoatMesh />
            </group>
        </group>
    );
}

// NPC MISTICO ESTÁTICO
const NPCMesh: React.FC<{ position: [number, number, number], rotation: number }> = ({ position, rotation }) => {
    // Renderiza uma figura humanoide estática com manto
    return (
        <group position={position} rotation={[0, rotation, 0]}>
             {/* Corpo (Robe) - Cone truncado para parecer um manto pesado no chão */}
             {/* Height: 1.8. Pivot: Centro. Y = 0.9 coloca a base no chão (0) */}
             <mesh position={[0, 0.9, 0]} material={materials.npcRobe} castShadow>
                 <cylinderGeometry args={[0.3, 0.6, 1.8, 16]} /> 
             </mesh>
             {/* Cabeça */}
             <mesh position={[0, 1.9, 0]} material={materials.npcSkin} castShadow>
                 <sphereGeometry args={[0.25, 16, 16]} />
             </mesh>
             {/* Capuz */}
             <mesh position={[0, 2.0, -0.05]} rotation={[-0.2, 0, 0]} material={materials.npcRobe} castShadow>
                 <coneGeometry args={[0.4, 0.6, 16, 1, true]} />
             </mesh>
             
             {/* Olhos Brilhantes (Cyan) */}
             <mesh position={[0.1, 1.95, 0.2]} material={materials.eyeGlow}>
                 <sphereGeometry args={[0.03, 8, 8]} />
             </mesh>
             <mesh position={[-0.1, 1.95, 0.2]} material={materials.eyeGlow}>
                 <sphereGeometry args={[0.03, 8, 8]} />
             </mesh>

             {/* Cajado (Apoiado no chão) */}
             <group position={[0.5, 0, 0.3]} rotation={[0, 0, -0.1]}>
                 <mesh position={[0, 1.1, 0]} material={materials.woodPlank}><cylinderGeometry args={[0.03, 0.03, 2.2]} /></mesh>
                 <mesh position={[0, 2.2, 0]} material={materials.eyeGlow}>
                     <dodecahedronGeometry args={[0.1, 0]} />
                 </mesh>
                 <pointLight position={[0, 2.2, 0]} color="#00ffff" distance={2} decay={2} intensity={0.5} />
             </group>
        </group>
    );
}


const VillageObject: React.FC<VillageObjectProps> = ({ type, position, rotation }) => {

  if (type === 'well') {
    return (
      <group position={position} rotation={[0, rotation, 0]}>
        <group>
            {Array.from({length: 8}).map((_, i) => {
                const angle = (i / 8) * Math.PI * 2;
                const r = 0.6;
                return (
                    <mesh 
                        key={i} 
                        position={[Math.cos(angle)*r, 0.4, Math.sin(angle)*r]} 
                        rotation={[0, -angle, 0]}
                        material={materials.stone} 
                        castShadow
                    >
                        <boxGeometry args={[0.2, 0.8, 0.5]} />
                    </mesh>
                )
            })}
        </group>
        
        <mesh position={[0, 0.5, 0]} rotation={[-Math.PI/2, 0, 0]} material={materials.water}><circleGeometry args={[0.55, 16]} /></mesh>

        <mesh position={[-0.8, 1.5, 0]} material={materials.wood} castShadow><boxGeometry args={[0.15, 2.2, 0.15]} /></mesh>
        <mesh position={[0.8, 1.5, 0]} material={materials.wood} castShadow><boxGeometry args={[0.15, 2.2, 0.15]} /></mesh>
        
        <mesh position={[0, 2.6, 0]} material={materials.wood} castShadow><coneGeometry args={[1.4, 0.8, 4]} /></mesh>
        
        <group position={[0, 1.2, 0]}>
            <mesh material={materials.wood}><cylinderGeometry args={[0.2, 0.15, 0.3, 8]} /></mesh>
            <mesh position={[0, 0.2, 0]} material={materials.metal}><torusGeometry args={[0.15, 0.02, 4, 8, Math.PI]} /></mesh>
        </group>
      </group>
    );
  }

  if (type === 'dock') {
      return (
          <group position={position} rotation={[0, rotation, 0]}>
              {/* Plataforma Principal */}
              <mesh position={[2.0, 0, 0]} material={materials.woodPlank} receiveShadow castShadow><boxGeometry args={[6.0, 0.2, 2.5]} /></mesh>
              
              {/* Rampa de Acesso */}
              <mesh position={[-2.25, 0.5, 0]} rotation={[0, 0, 0.3]} material={materials.woodPlank} receiveShadow><boxGeometry args={[3.0, 0.2, 2.5]} /></mesh>

              {/* Fundação Sólida */}
              <mesh position={[-2.0, -1.0, 0]} material={materials.stone}><boxGeometry args={[3.5, 3.0, 2.3]} /></mesh>

              {/* Pilares */}
              <mesh position={[0, -4.0, 1.0]} material={materials.wood}><cylinderGeometry args={[0.15, 0.15, 8.0]} /></mesh>
              <mesh position={[0, -4.0, -1.0]} material={materials.wood}><cylinderGeometry args={[0.15, 0.15, 8.0]} /></mesh>
              <mesh position={[4.0, -4.0, 1.0]} material={materials.wood}><cylinderGeometry args={[0.15, 0.15, 8.0]} /></mesh>
              <mesh position={[4.0, -4.0, -1.0]} material={materials.wood}><cylinderGeometry args={[0.15, 0.15, 8.0]} /></mesh>
              
              {/* Postes */}
              <mesh position={[4.5, 0.3, 1.0]} material={materials.wood}><cylinderGeometry args={[0.1, 0.1, 0.6]} /></mesh>
              <mesh position={[4.5, 0.3, -1.0]} material={materials.wood}><cylinderGeometry args={[0.1, 0.1, 0.6]} /></mesh>
          </group>
      )
  }

  if (type === 'boat') {
      // Uso do componente animado para barcos
      return <FloatingBoat position={position} rotation={rotation} />;
  }

  if (type === 'npc') {
      return <NPCMesh position={position} rotation={rotation} />;
  }

  if (type === 'lamp') {
    return (
      <group position={position} rotation={[0, rotation, 0]}>
         <mesh position={[0, 1.5, 0]} material={materials.wood} castShadow><cylinderGeometry args={[0.1, 0.15, 3.0, 6]} /></mesh>
         <mesh position={[0.3, 2.8, 0]} material={materials.metal}><boxGeometry args={[0.7, 0.1, 0.1]} /></mesh>
         <group position={[0.6, 2.6, 0]}>
            <mesh material={materials.metal}><boxGeometry args={[0.3, 0.4, 0.3]} /></mesh>
            <mesh material={materials.lampGlow}><boxGeometry args={[0.2, 0.3, 0.2]} /></mesh>
            <pointLight distance={10} intensity={2} color="#ffaa55" decay={2} />
         </group>
      </group>
    );
  }

  if (type === 'campfire') {
      return (
        <group position={position}>
           {Array.from({length: 8}).map((_, i) => (
             <mesh key={i} position={[Math.cos(i/8 * Math.PI*2)*0.8, 0.1, Math.sin(i/8 * Math.PI*2)*0.8]} material={materials.stone}>
                <sphereGeometry args={[0.2, 4, 4]} />
             </mesh>
           ))}
           <mesh position={[0, 0.1, 0]} rotation={[0, 0.5, Math.PI/4]} material={materials.wood}><cylinderGeometry args={[0.1, 0.1, 1.0]} /></mesh>
           <mesh position={[0, 0.1, 0]} rotation={[0, -0.5, -Math.PI/4]} material={materials.wood}><cylinderGeometry args={[0.1, 0.1, 1.0]} /></mesh>
           <pointLight position={[0, 0.5, 0]} distance={15} intensity={3} color="#ff4400" decay={2} />
        </group>
      );
  }
  
  if (type === 'quest_board') {
      return (
        <group position={position} rotation={[0, rotation, 0]}>
             {/* Poste */}
             <mesh position={[0, 1.0, 0]} material={materials.wood} castShadow>
                 <cylinderGeometry args={[0.08, 0.08, 2.0]} />
             </mesh>
             
             {/* Placa de Madeira */}
             <mesh position={[0, 1.6, 0.1]} material={materials.woodPlank} castShadow>
                 <boxGeometry args={[0.8, 0.6, 0.05]} />
             </mesh>
             
             {/* Pergaminho Aberto Preso */}
             <group position={[0, 1.6, 0.13]}>
                 {/* Papel */}
                 <mesh material={materials.parchment}>
                     <boxGeometry args={[0.6, 0.4, 0.01]} />
                 </mesh>
                 {/* Rolinhos nas bordas */}
                 <mesh position={[0, 0.2, 0.01]} rotation={[0, 0, Math.PI/2]} material={materials.parchment}>
                     <cylinderGeometry args={[0.03, 0.03, 0.6]} />
                 </mesh>
                 <mesh position={[0, -0.2, 0.01]} rotation={[0, 0, Math.PI/2]} material={materials.parchment}>
                     <cylinderGeometry args={[0.03, 0.03, 0.6]} />
                 </mesh>
                 {/* Prego */}
                 <mesh position={[0, 0.18, 0.02]} rotation={[Math.PI/2, 0, 0]} material={materials.darkMetal}>
                     <cylinderGeometry args={[0.01, 0.01, 0.05]} />
                 </mesh>
             </group>
        </group>
      );
  }

  return null;
};

export default React.memo(VillageObject);
