
import React, { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

interface ObjectiveMarkerProps {
  position: THREE.Vector3;
}

const ObjectiveMarker: React.FC<ObjectiveMarkerProps> = ({ position }) => {
  const outerRef = useRef<THREE.Mesh>(null);
  const innerRef = useRef<THREE.Mesh>(null);
  const beamRef = useRef<THREE.Mesh>(null);

  // Material Amarelo Brilhante (GTA V Style)
  const material = useRef(new THREE.MeshBasicMaterial({ 
      color: 0xffcc00, 
      transparent: true, 
      opacity: 0.3,
      side: THREE.DoubleSide,
      depthWrite: false, // Importante para transparência correta
      blending: THREE.AdditiveBlending
  })).current;
  
  const beamMaterial = useRef(new THREE.MeshBasicMaterial({ 
      color: 0xffdd44, 
      transparent: true, 
      opacity: 0.2, // Aumentado para melhor visibilidade
      side: THREE.DoubleSide,
      depthWrite: false,
      blending: THREE.AdditiveBlending
  })).current;

  useFrame((state) => {
    const t = state.clock.getElapsedTime();
    
    if (outerRef.current) {
        // Pulsação de escala
        const scale = 1.0 + Math.sin(t * 3) * 0.05;
        outerRef.current.scale.set(scale, 1, scale);
        // Rotação Lenta
        outerRef.current.rotation.y = t * 0.5;
    }
    
    if (innerRef.current) {
        // Rotação inversa mais rápida
        innerRef.current.rotation.y = -t * 1.0;
        // Bobbing vertical
        innerRef.current.position.y = 1.0 + Math.sin(t * 2) * 0.2;
    }
    
    if (beamRef.current) {
        // Oscilação de opacidade do feixe
        beamMaterial.opacity = 0.15 + Math.sin(t * 5) * 0.1;
    }
  });

  return (
    <group position={[position.x, position.y, position.z]}>
        {/* Cilindro Externo (Area de Trigger Visual) */}
        <mesh ref={outerRef} position={[0, 1, 0]}>
            <cylinderGeometry args={[4, 4, 2, 32, 1, true]} />
            <primitive object={material} />
        </mesh>

        {/* Anéis Internos (Detalhe) */}
        <mesh ref={innerRef} position={[0, 1, 0]}>
            <cylinderGeometry args={[3, 3, 0.5, 16, 1, true]} />
            <meshBasicMaterial color={0xffaa00} wireframe transparent opacity={0.5} />
        </mesh>
        
        {/* Feixe de Luz Infinito (Beacon) - Altura Aumentada drasticamente */}
        <mesh ref={beamRef} position={[0, 2500, 0]}>
            <cylinderGeometry args={[2, 8, 5000, 16, 1, true]} />
            <primitive object={beamMaterial} />
        </mesh>

        {/* Ponto de Luz para iluminar o chão ao redor */}
        <pointLight color="#ffcc00" distance={40} intensity={5} decay={1.5} position={[0, 5, 0]} />
    </group>
  );
};

export default ObjectiveMarker;
