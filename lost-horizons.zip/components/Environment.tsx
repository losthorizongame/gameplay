
import React, { useRef, useMemo, useEffect, useState } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import * as THREE from 'three';
import { RENDER_DISTANCE, CHUNK_SIZE } from '../types';

interface EnvironmentProps {
  playerPos: THREE.Vector3; // Usado apenas para inicialização ou fallback
  isUnderwater: boolean;
}

const DAY_CYCLE_DURATION = 600; 
// O sol deve estar além da distância de renderização para parecer distante.
// Render Distance 16 * 64 = 1024. Far Plane = 1500.
// AJUSTE: Reduzido para 1450 para evitar clipping com o Far Plane.
const SUN_DISTANCE = 1450; 

const CloudShader = {
  uniforms: {
    uTime: { value: 0 },
    uCloudColor: { value: new THREE.Color('#ffffff') },
  },
  vertexShader: `
    varying vec2 vUv;
    void main() {
      vUv = uv;
      gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    }
  `,
  fragmentShader: `
    uniform float uTime;
    uniform vec3 uCloudColor;
    varying vec2 vUv;

    vec3 permute(vec3 x) { return mod(((x*34.0)+1.0)*x, 289.0); }
    float snoise(vec2 v){
      const vec4 C = vec4(0.211324865405187, 0.366025403784439,
               -0.577350269189626, 0.024390243902439);
      vec2 i  = floor(v + dot(v, C.yy) );
      vec2 x0 = v -   i + dot(i, C.xx);
      vec2 i1;
      i1 = (x0.x > x0.y) ? vec2(1.0, 0.0) : vec2(0.0, 1.0);
      vec4 x12 = x0.xyxy + C.xxzz;
      x12.xy -= i1;
      i = mod(i, 289.0);
      vec3 p = permute( permute( i.y + vec3(0.0, i1.y, 1.0 ))
      + i.x + vec3(0.0, i1.x, 1.0 ));
      vec3 m = max(0.5 - vec3(dot(x0,x0), dot(x12.xy,x12.xy), dot(x12.zw,x12.zw)), 0.0);
      m = m*m ;
      m = m*m ;
      vec3 x = 2.0 * fract(p * C.www) - 1.0;
      vec3 h = abs(x) - 0.5;
      vec3 ox = floor(x + 0.5);
      vec3 a0 = x - ox;
      m *= 1.79284291400159 - 0.85373472095314 * ( a0*a0 + h*h );
      vec3 g;
      g.x  = a0.x  * x0.x  + h.x  * x0.y;
      g.yz = a0.yz * x12.xz + h.yz * x12.yw;
      return 130.0 * dot(m, g);
    }

    void main() {
      float n1 = snoise(vUv * 8.0 + uTime * 0.05);
      float n2 = snoise(vUv * 16.0 - uTime * 0.02);
      float noise = n1 * 0.5 + n2 * 0.5;
      float cloudDensity = smoothstep(0.3, 0.7, noise); 
      float alpha = cloudDensity * 0.3; 
      if (alpha < 0.01) discard;
      gl_FragColor = vec4(uCloudColor, alpha);
    }
  `
};

const StarShader = {
  uniforms: {
    uTime: { value: 0 },
    uOpacity: { value: 0 }, 
  },
  vertexShader: `
    uniform float uTime;
    attribute float aSize;
    attribute float aTwinkleSpeed;
    attribute vec3 aColor;
    varying vec3 vColor;
    varying float vAlpha;

    void main() {
      vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);
      gl_Position = projectionMatrix * mvPosition;
      
      float dist = length(mvPosition.xyz);
      float scale = 300.0 / max(dist, 1.0);
      
      gl_PointSize = aSize * scale; 
      gl_PointSize = clamp(gl_PointSize, 2.0, 6.0);
      
      float twinkle = sin(uTime * aTwinkleSpeed + position.x * 10.0) * 0.5 + 0.5;
      vColor = aColor;
      vAlpha = mix(0.5, 1.0, twinkle);
    }
  `,
  fragmentShader: `
    uniform float uOpacity;
    varying vec3 vColor;
    varying float vAlpha;

    void main() {
      vec2 uv = gl_PointCoord.xy - 0.5;
      float dist = length(uv);
      if (dist > 0.5) discard;
      float glow = 1.0 - (dist * 2.0);
      glow = pow(glow, 2.0); 
      gl_FragColor = vec4(vColor * 1.5, uOpacity * vAlpha * glow);
    }
  `
};

const Environment: React.FC<EnvironmentProps> = ({ playerPos, isUnderwater }) => {
  const { scene, camera } = useThree();
  const dirLightRef = useRef<THREE.DirectionalLight>(null);
  
  const [lightTarget] = useState(() => {
    const obj = new THREE.Object3D();
    return obj;
  });

  const moonRef = useRef<THREE.Mesh>(null);
  const sunRef = useRef<THREE.Mesh>(null);
  const starsRef = useRef<THREE.Points>(null);
  const starMaterialRef = useRef<THREE.ShaderMaterial>(null);
  const cloudsRef = useRef<THREE.Mesh>(null);
  const cloudMatRef = useRef<THREE.ShaderMaterial>(null);
  
  const sunColor = useMemo(() => new THREE.Color('#ffffee'), []);
  const moonColor = useMemo(() => new THREE.Color('#6688ff'), []);
  const skyColorDay = useMemo(() => new THREE.Color('#87CEEB'), []);
  const skyColorSunset = useMemo(() => new THREE.Color('#ed8e55'), []);
  const skyColorNight = useMemo(() => new THREE.Color('#050714'), []); 
  const waterColor = useMemo(() => new THREE.Color('#1a3366'), []);

  useEffect(() => {
    scene.add(lightTarget);
    return () => { scene.remove(lightTarget); };
  }, [scene, lightTarget]);

  // Inicialização do FOG dinâmica
  useEffect(() => {
    if (!scene.background) {
      scene.background = new THREE.Color('#87CEEB');
    }
    // O FOG deve terminar EXATAMENTE onde os chunks terminam de carregar.
    // Se Render Distance = 16 * 64 = 1024 metros.
    // Fog Far deve ser 1024 - 24 = 1000 (Margem de segurança para não ver o corte).
    const fogDist = RENDER_DISTANCE * CHUNK_SIZE;
    if (!scene.fog) {
      scene.fog = new THREE.Fog('#87CEEB', fogDist * 0.5, fogDist - 50);
    }
  }, [scene]);

  const starGeo = useMemo(() => {
    const geometry = new THREE.BufferGeometry();
    const count = 3000; 
    
    const positions = new Float32Array(count * 3);
    const colors = new Float32Array(count * 3);
    const sizes = new Float32Array(count);
    const speeds = new Float32Array(count);
    
    const radius = 1400; 

    const starColors = [
      new THREE.Color('#9bb0ff'), new THREE.Color('#cad7ff'), 
      new THREE.Color('#fff4ea'), new THREE.Color('#ffffff')
    ];

    for (let i = 0; i < count; i++) {
      const theta = 2 * Math.PI * Math.random();
      const phi = Math.acos(2 * Math.random() - 1);
      const x = radius * Math.sin(phi) * Math.cos(theta);
      const y = radius * Math.sin(phi) * Math.sin(theta);
      const z = radius * Math.cos(phi);
      positions[i * 3] = x;
      positions[i * 3 + 1] = y;
      positions[i * 3 + 2] = z;

      sizes[i] = 2.0 + Math.random() * 3.0;
      const color = starColors[Math.floor(Math.random() * starColors.length)];
      colors[i * 3] = color.r;
      colors[i * 3 + 1] = color.g;
      colors[i * 3 + 2] = color.b;
      speeds[i] = Math.random() * 3.0 + 1.0;
    }

    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geometry.setAttribute('aColor', new THREE.BufferAttribute(colors, 3));
    geometry.setAttribute('aSize', new THREE.BufferAttribute(sizes, 1));
    geometry.setAttribute('aTwinkleSpeed', new THREE.BufferAttribute(speeds, 1));
    return geometry;
  }, []);

  useFrame((state) => {
    const time = state.clock.getElapsedTime();
    const cycle = (time % DAY_CYCLE_DURATION) / DAY_CYCLE_DURATION;
    const angle = cycle * Math.PI * 2;
    
    const sinAngle = Math.sin(angle);
    const cosAngle = Math.cos(angle);
    
    const currentPos = camera.position;

    const sunOffsetX = cosAngle * SUN_DISTANCE; 
    const sunOffsetY = sinAngle * SUN_DISTANCE;

    if (sunRef.current) {
        sunRef.current.position.set(currentPos.x + sunOffsetX, currentPos.y + sunOffsetY, currentPos.z);
    }
    if (moonRef.current) {
        moonRef.current.position.set(currentPos.x - sunOffsetX, currentPos.y - sunOffsetY, currentPos.z);
    }

    if (dirLightRef.current) {
      const lightDist = 200; 
      const lx = cosAngle * lightDist;
      const ly = sinAngle * lightDist;

      dirLightRef.current.position.set(
          currentPos.x + lx, 
          currentPos.y + ly, 
          currentPos.z + 50
      );
      lightTarget.position.copy(currentPos);
      
      const intensity = Math.max(0, sinAngle);
      dirLightRef.current.intensity = intensity * 1.8;
      dirLightRef.current.updateMatrixWorld();
    }

    let targetSkyColor = skyColorNight;
    if (sinAngle > 0.1) targetSkyColor = skyColorDay;
    else if (sinAngle > -0.2) targetSkyColor = skyColorSunset;

    const bg = scene.background as THREE.Color;
    const fog = scene.fog as THREE.Fog;

    // Cálculo dinâmico do Fog Far baseado na Render Distance para garantir o blend perfeito
    const maxDist = RENDER_DISTANCE * CHUNK_SIZE;
    const fogFar = maxDist - 50;
    const fogNear = maxDist * 0.4; // Fog começa suave aos 40% da distância

    if (isUnderwater) {
       bg.lerp(waterColor, 0.1);
       if (fog) {
           fog.color.lerp(waterColor, 0.1);
           fog.near = 0;
           fog.far = 50; 
       }
    } else {
       bg.lerp(targetSkyColor, 0.02);
       if (fog) {
           fog.color.lerp(bg, 0.02);
           // Mantém os valores calculados para o horizonte
           fog.near = THREE.MathUtils.lerp(fog.near, fogNear, 0.05);
           fog.far = THREE.MathUtils.lerp(fog.far, fogFar, 0.05);
       }
    }

    if (starMaterialRef.current) {
       const starOpacity = sinAngle < 0.1 ? 1.0 - (Math.max(0, sinAngle + 0.2) * 3) : 0;
       starMaterialRef.current.uniforms.uOpacity.value = THREE.MathUtils.lerp(
         starMaterialRef.current.uniforms.uOpacity.value, 
         Math.max(0, starOpacity), 
         0.05
       );
       starMaterialRef.current.uniforms.uTime.value = time;
    }

    if (cloudMatRef.current) {
       cloudMatRef.current.uniforms.uTime.value = time;
       const lightColor = sinAngle > 0 ? new THREE.Color(1,1,1) : new THREE.Color(0.2, 0.2, 0.3);
       cloudMatRef.current.uniforms.uCloudColor.value.lerp(lightColor, 0.05);
    }

    if (cloudsRef.current) cloudsRef.current.position.set(currentPos.x, 200, currentPos.z);
    if (starsRef.current) starsRef.current.position.set(currentPos.x, 0, currentPos.z);
  });

  return (
    <>
      <directionalLight 
        ref={dirLightRef}
        target={lightTarget}
        castShadow
        shadow-mapSize={[1024, 1024]} 
        shadow-camera-near={0.5}
        shadow-camera-far={1500}
        shadow-bias={-0.0001}
        shadow-normalBias={0.04}
      >
        <orthographicCamera attach="shadow-camera" args={[-80, 80, 80, -80]} />
      </directionalLight>
      
      <ambientLight intensity={0.3} />

      <mesh ref={sunRef} frustumCulled={false}>
        <sphereGeometry args={[60, 32, 32]} />
        <meshBasicMaterial color={sunColor} fog={false} toneMapped={false} />
      </mesh>

      <mesh ref={moonRef} frustumCulled={false}>
        <sphereGeometry args={[40, 32, 32]} />
        <meshBasicMaterial color={moonColor} fog={false} toneMapped={false} />
      </mesh>

      <points ref={starsRef} geometry={starGeo} frustumCulled={false}>
        <shaderMaterial 
          ref={starMaterialRef} 
          args={[StarShader]} 
          transparent 
          depthWrite={false} 
          blending={THREE.AdditiveBlending} 
        />
      </points>

      <mesh ref={cloudsRef} rotation={[-Math.PI/2, 0, 0]} frustumCulled={false}>
        <planeGeometry args={[3000, 3000]} />
        <shaderMaterial 
          ref={cloudMatRef} 
          args={[CloudShader]} 
          transparent 
          depthWrite={false} 
          side={THREE.DoubleSide} 
        />
      </mesh>
    </>
  );
};

export default Environment;
