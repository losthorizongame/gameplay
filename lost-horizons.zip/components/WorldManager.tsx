
import React, { useState, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import TerrainChunk from './TerrainChunk';
import { CHUNK_SIZE, RENDER_DISTANCE } from '../types';

interface WorldManagerProps {
  playerPosition: THREE.Vector3;
}

// Helper para chave única
const getChunkKey = (x: number, z: number) => `${x}_${z}`;

const WorldManager: React.FC<WorldManagerProps> = ({ playerPosition }) => {
  const [activeChunks, setActiveChunks] = useState<Set<string>>(new Set());
  const chunksRef = useRef<Map<string, React.ReactElement>>(new Map());
  const chunkLODs = useRef<Map<string, number>>(new Map()); 
  
  const prevPlayerChunk = useRef({ x: -999, z: -999 });
  const loadQueue = useRef<{x: number, z: number, dist: number, lod: number}[]>([]);
  
  // OTIMIZAÇÃO: Throttle de atualização
  const lastUpdate = useRef(0);

  useFrame(({ clock }) => {
    // OTIMIZAÇÃO: Executar lógica pesada de distância apenas 5 vezes por segundo
    const now = clock.getElapsedTime() * 1000;
    if (now - lastUpdate.current < 200) return;
    lastUpdate.current = now;

    const currentChunkX = Math.floor(playerPosition.x / CHUNK_SIZE);
    const currentChunkZ = Math.floor(playerPosition.z / CHUNK_SIZE);

    // Verificação de mudança ou re-cálculo de LOD periódico
    // Mesmo que não mude o chunk, recalculamos LODs periodicamente para transições suaves
    
    prevPlayerChunk.current = { x: currentChunkX, z: currentChunkZ };
    
    const newQueue: {x: number, z: number, dist: number, lod: number}[] = [];
    const neededKeys = new Set<string>();

    for (let x = -RENDER_DISTANCE; x <= RENDER_DISTANCE; x++) {
      for (let z = -RENDER_DISTANCE; z <= RENDER_DISTANCE; z++) {
        const distSq = x*x + z*z;
        if (distSq > RENDER_DISTANCE * RENDER_DISTANCE) continue;

        const chunkX = currentChunkX + x;
        const chunkZ = currentChunkZ + z;
        const key = getChunkKey(chunkX, chunkZ);
        const dist = Math.sqrt(distSq);
        
        // --- LOD LOGIC OTIMIZADO ---
        let targetLod = 8; 
        
        // LOD 1: Sombras e detalhes máximos (apenas muito perto: 1.5 chunks)
        if (dist < 1.5) targetLod = 1;      
        
        // LOD 2: Árvores densas sem sombras (3.5 chunks)
        else if (dist < 3.5) targetLod = 2;   
        
        // LOD 4: Árvores esparsas (low density) para horizonte (até 9 chunks)
        // Aqui usamos VEGETATION_STEP_LOW (45) em vez de HIGH (12).
        // 4x menos geometria.
        else if (dist < 9.0) targetLod = 4;

        // LOD 8: Apenas terreno (montanhas distantes)
        else targetLod = 8;                 

        neededKeys.add(key);

        const currentLod = chunkLODs.current.get(key);
        
        // Se não existe ou se o LOD mudou, adiciona à fila
        if (!chunksRef.current.has(key) || currentLod !== targetLod) {
          newQueue.push({ x: chunkX, z: chunkZ, dist, lod: targetLod });
        }
      }
    }

    let chunksRemoved = false;
    for (const [key] of chunksRef.current) {
      if (!neededKeys.has(key)) {
        chunksRef.current.delete(key);
        chunkLODs.current.delete(key); 
        chunksRemoved = true;
      }
    }

    newQueue.sort((a, b) => a.dist - b.dist);
    loadQueue.current = newQueue;

    if (chunksRemoved) {
      setActiveChunks(new Set(chunksRef.current.keys()));
    }

    // Carregamento progressivo (4 chunks por ciclo de update)
    const chunksToLoad = 4; 

    if (loadQueue.current.length > 0) {
      let updated = false;

      for (let i = 0; i < chunksToLoad; i++) {
        const next = loadQueue.current.shift();
        if (!next) break;

        const key = getChunkKey(next.x, next.z);
        
        chunksRef.current.set(key, 
          <TerrainChunk 
            key={key} 
            x={next.x} 
            z={next.z} 
            lodLevel={next.lod} 
          />
        );
        chunkLODs.current.set(key, next.lod);
        updated = true;
      }

      if (updated) {
        setActiveChunks(new Set(chunksRef.current.keys()));
      }
    }
  });

  return (
    <group>
      {Array.from(activeChunks).map(key => chunksRef.current.get(key))}
    </group>
  );
};

export default WorldManager;
