
import React, { useMemo, useRef, useEffect } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import * as THREE from 'three';
import { CHUNK_SIZE, WATER_LEVEL } from '../types';
import { getTerrainHeight } from '../services/MathUtils';

// CONFIGURAÇÕES
const BIRD_COUNT = 80; 
const FLOCK_CENTER_BIAS = 0.005;
const SEPARATION_DIST = 5.0;
const ALIGNMENT_VEL = 0.02;

// --- GEOMETRIA PROCEDURAL OTIMIZADA ---
const createBirdGeometry = () => {
  const geometry = new THREE.BufferGeometry();
  
  const vertices = [
    // Corpo
    0.0, 0.0, 0.5,   
    0.15, -0.1, -0.3, 
    -0.15, -0.1, -0.3, 
    0.0, 0.2, -0.2,  
    
    // Asa Esq
    0.0, 0.1, 0.1,   
    0.0, 0.1, -0.2,  
    -1.2, 0.0, -0.1, 

    // Asa Dir
    0.0, 0.1, 0.1,   
    0.0, 0.1, -0.2,  
    1.2, 0.0, -0.1   
  ];

  const indices = [
    0, 1, 3,  0, 3, 2,  0, 2, 1,  1, 2, 3,
    4, 6, 5,  5, 6, 4,
    7, 8, 9,  9, 8, 7
  ];

  const wingFactors = [
    0, 0, 0, 0, 
    0, 0, 1,    
    0, 0, 1     
  ];

  geometry.setIndex(indices);
  geometry.setAttribute('position', new THREE.Float32BufferAttribute(vertices, 3));
  geometry.setAttribute('wingFactor', new THREE.Float32BufferAttribute(wingFactors, 1));
  geometry.computeVertexNormals();

  return geometry;
};

// --- SHADER DE ANIMAÇÃO (GPU) ---
const birdMaterial = new THREE.MeshStandardMaterial({
  color: 0xffffff,
  roughness: 0.6,
  vertexColors: true,
  side: THREE.DoubleSide
});

const birdShaderLogic = {
  uniforms: {
    uTime: { value: 0 }
  },
  onBeforeCompile: (shader: any) => {
    shader.uniforms.uTime = birdShaderLogic.uniforms.uTime;
    
    shader.vertexShader = `
      uniform float uTime;
      attribute float wingFactor;
      attribute float flapSpeed; 
      attribute float flapOffset;
      
      mat4 rotationMatrix(vec3 axis, float angle) {
          axis = normalize(axis);
          float s = sin(angle);
          float c = cos(angle);
          float oc = 1.0 - c;
          
          return mat4(oc * axis.x * axis.x + c,           oc * axis.x * axis.y - axis.z * s,  oc * axis.z * axis.x + axis.y * s,  0.0,
                      oc * axis.x * axis.y + axis.z * s,  oc * axis.y * axis.y + c,           oc * axis.y * axis.z - axis.x * s,  0.0,
                      oc * axis.z * axis.x - axis.y * s,  oc * axis.y * axis.z + axis.x * s,  oc * axis.z * axis.z + c,           0.0,
                      0.0,                                0.0,                                0.0,                                1.0);
      }
    ` + shader.vertexShader;

    shader.vertexShader = shader.vertexShader.replace(
      '#include <begin_vertex>',
      `
      #include <begin_vertex>
      
      if (wingFactor > 0.1) {
        float flap = sin(uTime * flapSpeed + flapOffset);
        float dir = position.x > 0.0 ? -1.0 : 1.0;
        mat4 rot = rotationMatrix(vec3(0.0, 0.0, 1.0), flap * dir * 0.6 * wingFactor);
        vec3 pos = transformed;
        vec4 newPos = rot * vec4(pos, 1.0);
        transformed = newPos.xyz;
      }
      `
    );
  }
};
birdMaterial.onBeforeCompile = birdShaderLogic.onBeforeCompile;


const SPECIES_PALETTES = [
  { color: '#8B4513', scale: 1.5, speed: 12, flap: 8 },  
  { color: '#A9A9A9', scale: 0.5, speed: 20, flap: 25 }, 
  { color: '#FF4500', scale: 0.8, speed: 18, flap: 20 }, 
  { color: '#1E90FF', scale: 0.7, speed: 22, flap: 18 }, 
  { color: '#FFFF00', scale: 0.6, speed: 24, flap: 22 }, 
  { color: '#000000', scale: 1.0, speed: 15, flap: 10 }, 
  { color: '#FFFFFF', scale: 1.2, speed: 14, flap: 10 }, 
  { color: '#2E8B57', scale: 0.6, speed: 19, flap: 20 }, 
  { color: '#8A2BE2', scale: 0.7, speed: 21, flap: 19 }, 
  { color: '#FF69B4', scale: 1.8, speed: 10, flap: 6 },  
];

const _tempLook = new THREE.Vector3();
const _dirToCenter = new THREE.Vector3();

// Props 'playerPos' mantida para inicialização, mas ignorada no loop
const BirdFlock: React.FC<{ playerPos: THREE.Vector3 }> = ({ playerPos }) => {
  const meshRef = useRef<THREE.InstancedMesh>(null);
  const birdsData = useRef<any[]>([]);
  const dummy = useMemo(() => new THREE.Object3D(), []);
  const { camera } = useThree();

  // Inicializar Pássaros
  useEffect(() => {
    const geo = createBirdGeometry();
    const flapSpeeds = new Float32Array(BIRD_COUNT);
    const flapOffsets = new Float32Array(BIRD_COUNT);
    
    birdsData.current = [];
    const colorObj = new THREE.Color();

    for (let i = 0; i < BIRD_COUNT; i++) {
      const species = SPECIES_PALETTES[Math.floor(Math.random() * SPECIES_PALETTES.length)];
      
      const angle = Math.random() * Math.PI * 2;
      const dist = 50 + Math.random() * 300; 
      const x = playerPos.x + Math.cos(angle) * dist;
      const z = playerPos.z + Math.sin(angle) * dist;
      // Começam alto para evitar spawn dentro da terra
      const y = 80 + Math.random() * 40;

      const velocity = new THREE.Vector3(
        (Math.random() - 0.5) * species.speed,
        0,
        (Math.random() - 0.5) * species.speed
      );

      birdsData.current.push({
        velocity,
        position: new THREE.Vector3(x, y, z),
        species,
        seed: Math.random() * 100
      });

      flapSpeeds[i] = species.flap + (Math.random() - 0.5) * 5.0;
      flapOffsets[i] = Math.random() * 10.0;
      
      colorObj.set(species.color);
      colorObj.offsetHSL(0, 0, (Math.random() - 0.5) * 0.1);
      
      if (meshRef.current) {
        meshRef.current.setColorAt(i, colorObj);
      }
    }
    
    if (meshRef.current) {
        meshRef.current.geometry = geo;
        meshRef.current.geometry.setAttribute('flapSpeed', new THREE.InstancedBufferAttribute(flapSpeeds, 1));
        meshRef.current.geometry.setAttribute('flapOffset', new THREE.InstancedBufferAttribute(flapOffsets, 1));
        meshRef.current.instanceColor!.needsUpdate = true;
    }

  }, []); 

  useFrame((state, delta) => {
    if (!meshRef.current) return;
    
    birdShaderLogic.uniforms.uTime.value = state.clock.getElapsedTime();

    const dt = Math.min(delta, 0.1);
    
    // Usar camera.position para manter os pássaros ao redor do jogador
    const center = camera.position;

    for (let i = 0; i < BIRD_COUNT; i++) {
      const bird = birdsData.current[i];
      
      // 1. Coesão Global (Manter no raio do jogador)
      const distToCenter = bird.position.distanceTo(center);
      if (distToCenter > 350) {
        _dirToCenter.subVectors(center, bird.position).normalize();
        bird.velocity.lerp(_dirToCenter.multiplyScalar(bird.species.speed), dt * 0.5);
      } else {
        const noiseX = Math.sin(bird.seed + state.clock.elapsedTime * 0.5);
        const noiseZ = Math.cos(bird.seed + state.clock.elapsedTime * 0.3);
        
        bird.velocity.x += noiseX * dt * 5.0;
        bird.velocity.z += noiseZ * dt * 5.0;
      }

      // --- 2. INTELIGÊNCIA DE TERRENO (Look Ahead) ---
      // Calcular onde o pássaro estará em breve para prever colisão
      const lookAheadX = bird.position.x + bird.velocity.x * 1.5; // Olha 1.5s a frente
      const lookAheadZ = bird.position.z + bird.velocity.z * 1.5;

      // Obtem altura do terreno neste ponto futuro
      const groundHeight = getTerrainHeight(lookAheadX, lookAheadZ);
      const isOverWater = groundHeight <= WATER_LEVEL + 0.5;

      // Definir Altura Alvo baseada no bioma
      // Se for Água: Voa baixo (5m acima da água)
      // Se for Terra: Voa alto (25m acima do chão para evitar árvores)
      const minAltitude = isOverWater 
          ? Math.max(groundHeight, WATER_LEVEL) + 5.0 
          : groundHeight + 25.0;

      // Teto máximo para não subirem para o espaço
      const maxAltitude = 160;

      // Aplicação de força vertical
      if (bird.position.y < minAltitude) {
          // Push Up Force (Sustentação)
          // Quanto mais baixo, mais forte a força para subir
          const lift = (minAltitude - bird.position.y) * 2.0;
          bird.velocity.y += lift * dt;
          
          // Se estiver MUITO baixo (perto de colidir), reduz velocidade horizontal
          // para dar tempo de subir antes de bater na montanha
          if (bird.position.y < groundHeight + 5) {
             bird.velocity.x *= 0.95;
             bird.velocity.z *= 0.95;
          }

      } else if (bird.position.y > maxAltitude) {
          bird.velocity.y -= 5 * dt; // Empurrar pra baixo
      } else {
          // Voo cruzeiro: leve variação
          bird.velocity.y += (Math.random() - 0.5) * dt * 2;
          // Tentar voltar lentamente para uma altitude neutra se estiver muito alto sobre a terra
          if (!isOverWater && bird.position.y > minAltitude + 20) {
              bird.velocity.y -= 2 * dt;
          }
      }

      // Amortecimento vertical para suavidade
      bird.velocity.y *= 0.98;

      // Normalizar velocidade horizontal para manter constante
      const currentSpeed = Math.sqrt(bird.velocity.x**2 + bird.velocity.z**2);
      if (currentSpeed > 0.1) {
          const speedFix = bird.species.speed / currentSpeed;
          bird.velocity.x *= speedFix;
          bird.velocity.z *= speedFix;
      }

      // Integrar posição
      bird.position.addScaledVector(bird.velocity, dt);

      // Atualizar Matriz
      dummy.position.copy(bird.position);
      _tempLook.addVectors(bird.position, bird.velocity);
      dummy.lookAt(_tempLook);
      
      // Banking (Inclinação nas curvas)
      dummy.rotateZ(Math.sin(state.clock.elapsedTime + bird.seed) * 0.2); 
      dummy.scale.setScalar(bird.species.scale);
      
      dummy.updateMatrix();
      meshRef.current.setMatrixAt(i, dummy.matrix);
    }
    
    meshRef.current.instanceMatrix.needsUpdate = true;
  });

  return (
    <instancedMesh
      ref={meshRef}
      args={[undefined as any, birdMaterial, BIRD_COUNT]}
      frustumCulled={false}
      castShadow
    />
  );
};

export default React.memo(BirdFlock);
