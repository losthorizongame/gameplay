
import React, { useMemo } from 'react';
import * as THREE from 'three';

interface HouseProps {
  position: [number, number, number];
  rotationY: number;
  seed: number;
  lodLevel?: number; // Optional LOD
}

// Materiais reutilizáveis
const materials = {
  woodDark: new THREE.MeshStandardMaterial({ color: 0x3d2817, roughness: 0.9 }),
  stone: new THREE.MeshStandardMaterial({ color: 0x5a5a5a, roughness: 0.8 }), 
  plaster: new THREE.MeshStandardMaterial({ color: 0xebe5ce, roughness: 1.0 }), // Cor creme mais clara
  roof: new THREE.MeshStandardMaterial({ color: 0x8b3a3a, roughness: 0.6 }), // Telhado avermelhado
  glass: new THREE.MeshStandardMaterial({ 
    color: 0x88ccee, 
    roughness: 0.1, 
    metalness: 0.1, 
    transparent: true, 
    opacity: 0.4,
    side: THREE.DoubleSide
  }),
  emissive: new THREE.MeshBasicMaterial({ color: 0xffaa00 }),
  fabric: new THREE.MeshStandardMaterial({ color: 0x3d5c5c, roughness: 1.0 }), // Cama azulada/verde
  woodLight: new THREE.MeshStandardMaterial({ color: 0xa67b5b, roughness: 0.8 }) // Móveis
};

// Helper para construir boxes nos arrays de geometria
const buildBox = (
  positions: number[], normals: number[], 
  x: number, y: number, z: number, 
  w: number, h: number, d: number
) => {
  const hw = w/2, hh = h/2, hd = d/2;
  const faces = [
    [x+hw,y-hh,z+hd,  x+hw,y-hh,z-hd,  x+hw,y+hh,z-hd,  x+hw,y+hh,z+hd,  1,0,0],
    [x-hw,y-hh,z-hd,  x-hw,y-hh,z+hd,  x-hw,y+hh,z+hd,  x-hw,y+hh,z-hd,  -1,0,0],
    [x+hw,y+hh,z+hd,  x+hw,y+hh,z-hd,  x-hw,y+hh,z-hd,  x-hw,y+hh,z+hd,  0,1,0],
    [x+hw,y-hh,z+hd,  x-hw,y-hh,z+hd,  x-hw,y-hh,z-hd,  x+hw,y-hh,z-hd,  0,-1,0],
    [x+hw,y-hh,z+hd,  x+hw,y+hh,z+hd,  x-hw,y+hh,z+hd,  x-hw,y-hh,z+hd,  0,0,1],
    [x+hw,y-hh,z-hd,  x-hw,y-hh,z-hd,  x-hw,y+hh,z-hd,  x+hw,y+hh,z-hd,  0,0,-1],
  ];

  for(let f of faces) {
     const nx=f[12], ny=f[13], nz=f[14];
     positions.push(f[0],f[1],f[2]); normals.push(nx,ny,nz);
     positions.push(f[3],f[4],f[5]); normals.push(nx,ny,nz);
     positions.push(f[6],f[7],f[8]); normals.push(nx,ny,nz);
     positions.push(f[0],f[1],f[2]); normals.push(nx,ny,nz);
     positions.push(f[6],f[7],f[8]); normals.push(nx,ny,nz);
     positions.push(f[9],f[10],f[11]); normals.push(nx,ny,nz);
  }
};

// Prisma Triangular para Gables (Frontões)
const buildGable3D = (
  positions: number[], normals: number[],
  x: number, y: number, z: number,
  w: number, h: number, d: number
) => {
    const hw = w / 2;
    const hd = d / 2;
    const yBase = y;
    const yTop = y + h;
    const zFront = z + hd;
    const zBack = z - hd;
    
    const topF = [x, yTop, zFront]; const topB = [x, yTop, zBack];
    const leftF = [x - hw, yBase, zFront]; const leftB = [x - hw, yBase, zBack];
    const rightF = [x + hw, yBase, zFront]; const rightB = [x + hw, yBase, zBack];

    positions.push(...leftF, ...rightF, ...topF); normals.push(0,0,1, 0,0,1, 0,0,1);
    positions.push(...rightB, ...leftB, ...topB); normals.push(0,0,-1, 0,0,-1, 0,0,-1);

    const hyp = Math.sqrt(h*h + hw*hw);
    const nx = h / hyp;
    const ny = hw / hyp;

    positions.push(...rightF, ...rightB, ...topF); normals.push(nx,ny,0, nx,ny,0, nx,ny,0);
    positions.push(...rightB, ...topB, ...topF); normals.push(nx,ny,0, nx,ny,0, nx,ny,0);
    positions.push(...leftB, ...leftF, ...topB); normals.push(-nx,ny,0, -nx,ny,0, -nx,ny,0);
    positions.push(...leftF, ...topF, ...topB); normals.push(-nx,ny,0, -nx,ny,0, -nx,ny,0);
    
    positions.push(...leftF, ...leftB, ...rightF); normals.push(0,-1,0, 0,-1,0, 0,-1,0);
    positions.push(...leftB, ...rightB, ...rightF); normals.push(0,-1,0, 0,-1,0, 0,-1,0);
};

const House: React.FC<HouseProps> = ({ position, rotationY, seed, lodLevel = 1 }) => {
  const isDetailed = lodLevel === 1;

  const { woodGeo, stoneGeo, plasterGeo, glassGeo, roofDims } = useMemo(() => {
    const woodPos: number[] = [], woodNorm: number[] = [];
    const stonePos: number[] = [], stoneNorm: number[] = [];
    const plasterPos: number[] = [], plasterNorm: number[] = [];
    const glassPos: number[] = [], glassNorm: number[] = [];
    
    // --- DIMENSÕES EXPANDIDAS PARA EVITAR COLISÃO ---
    const width = 8.0;   
    const depth = 9.0;   
    const height = 4.5;  
    const wallThick = 0.3; 
    const doorWidth = 2.2;
    const doorHeight = 2.8;

    // --- 1. FUNDAÇÃO (Pedra) ---
    // Base sólida
    buildBox(stonePos, stoneNorm, 0, -1.0, 0, width, 2.2, depth);
    // Escada de entrada
    const stepZ = depth/2 + 0.5;
    buildBox(stonePos, stoneNorm, 0, 0.1, stepZ, 3.0, 0.2, 1.0); // Degrau mais largo
    buildBox(stonePos, stoneNorm, 0, -0.4, stepZ + 0.6, 3.2, 0.8, 1.2);

    // Chaminé (Pedra) - Lateral
    const chimX = width/2 + 0.5;
    buildBox(stonePos, stoneNorm, chimX, 2.0, -1.5, 1.0, 7.0, 1.5);
    buildBox(stonePos, stoneNorm, chimX, 6.0, -1.5, 0.8, 1.5, 1.0); // Topo

    // --- 2. PISO E TETO (Madeira) ---
    // Piso
    // CORREÇÃO DE GLITCH: Aumentado o buffer de redução do piso para 0.15 para garantir
    // que não haja sobreposição visual com a base da parede.
    const innerW = width - (wallThick * 2) - 0.15;
    const innerD = depth - (wallThick * 2) - 0.15;
    buildBox(woodPos, woodNorm, 0, 0.1, 0, innerW, 0.1, innerD);

    // Vigas do Teto
    if (isDetailed) {
        buildBox(woodPos, woodNorm, 0, height, 0, width, 0.4, 0.4); // Central
        buildBox(woodPos, woodNorm, 0, height, -depth/4, width, 0.3, 0.3);
        buildBox(woodPos, woodNorm, 0, height, depth/4, width, 0.3, 0.3);
    }

    // --- 3. PAREDES (Gesso/Plaster) ---
    
    // Parede Traseira (Z-)
    buildBox(plasterPos, plasterNorm, 0, height/2, -depth/2 + wallThick/2, width, height, wallThick);

    // Paredes Laterais (X- e X+)
    buildBox(plasterPos, plasterNorm, -width/2 + wallThick/2, height/2, 0, wallThick, height, depth - wallThick*2);
    buildBox(plasterPos, plasterNorm, width/2 - wallThick/2, height/2, 0, wallThick, height, depth - wallThick*2);

    // Parede Frontal (Z+) com PORTA LARGA
    const frontWallZ = depth/2 - wallThick/2;
    const sidePanelW = (width - doorWidth) / 2;
    buildBox(plasterPos, plasterNorm, -width/2 + sidePanelW/2, height/2, frontWallZ, sidePanelW, height, wallThick);
    buildBox(plasterPos, plasterNorm, width/2 - sidePanelW/2, height/2, frontWallZ, sidePanelW, height, wallThick);
    
    // Parte Superior da porta (Verga)
    const headerH = height - doorHeight;
    buildBox(plasterPos, plasterNorm, 0, doorHeight + headerH/2, frontWallZ, doorWidth, headerH, wallThick);
    
    // Moldura da Porta (Madeira)
    const frameThick = 0.45; 
    const frameWidth = 0.3; 

    buildBox(woodPos, woodNorm, -doorWidth/2 - 0.1, doorHeight/2, frontWallZ, frameWidth, doorHeight, frameThick);
    buildBox(woodPos, woodNorm, doorWidth/2 + 0.1, doorHeight/2, frontWallZ, frameWidth, doorHeight, frameThick);
    buildBox(woodPos, woodNorm, 0, doorHeight + 0.1, frontWallZ, doorWidth + 0.4, 0.25, frameThick);

    // --- 4. JANELAS ---
    const winY = 2.2;
    const winH = 1.5;
    const winW = 1.2;
    
    // Janela Esquerda
    buildBox(woodPos, woodNorm, -width/2, winY, 0, 0.4, winH + 0.2, winW + 0.2); 
    buildBox(glassPos, glassNorm, -width/2, winY, 0, 0.1, winH, winW); 
    
    // Janela Direita
    buildBox(woodPos, woodNorm, width/2, winY, 2.0, 0.4, winH + 0.2, winW + 0.2); 
    buildBox(glassPos, glassNorm, width/2, winY, 2.0, 0.1, winH, winW);

    // --- 5. TELHADO (Roof) ---
    const gableH = 2.5;
    buildGable3D(plasterPos, plasterNorm, 0, height, -depth/2 + wallThick/2, width, gableH, wallThick);
    buildGable3D(plasterPos, plasterNorm, 0, height, depth/2 - wallThick/2, width, gableH, wallThick);

    const overhang = 0.8;
    const roofLen = depth + overhang*2;
    const roofW = width/2 + overhang;
    const roofThick = 0.25;
    const roofAng = Math.atan2(gableH, width/2);

    const createGeo = (p: number[], n: number[]) => {
        if (p.length === 0) return null;
        const geo = new THREE.BufferGeometry();
        geo.setAttribute('position', new THREE.Float32BufferAttribute(p, 3));
        geo.setAttribute('normal', new THREE.Float32BufferAttribute(n, 3));
        return geo;
    };

    return {
        woodGeo: createGeo(woodPos, woodNorm),
        stoneGeo: createGeo(stonePos, stoneNorm),
        plasterGeo: createGeo(plasterPos, plasterNorm),
        glassGeo: createGeo(glassPos, glassNorm),
        roofDims: { w: roofW, l: roofLen, t: roofThick, a: roofAng, h: height, gh: gableH }
    };

  }, [seed, isDetailed]);

  return (
    <group position={position} rotation={[0, rotationY, 0]}>
      {stoneGeo && <mesh geometry={stoneGeo} material={materials.stone} castShadow receiveShadow />}
      {woodGeo && <mesh geometry={woodGeo} material={materials.woodDark} castShadow receiveShadow />}
      {plasterGeo && <mesh geometry={plasterGeo} material={materials.plaster} receiveShadow />}
      {glassGeo && <mesh geometry={glassGeo} material={materials.glass} />}
      
      {/* Telhado Inclinado */}
      <group position={[0, roofDims.h, 0]}>
         {/* Aba Esquerda */}
         <mesh 
            position={[-roofDims.w/2 + 0.1, roofDims.gh/2, 0]} 
            rotation={[0, 0, roofDims.a]} 
            material={materials.roof} 
            castShadow
         >
             <boxGeometry args={[roofDims.w + 0.6, roofDims.t, roofDims.l]} />
         </mesh>
         {/* Aba Direita */}
         <mesh 
            position={[roofDims.w/2 - 0.1, roofDims.gh/2, 0]} 
            rotation={[0, 0, -roofDims.a]} 
            material={materials.roof} 
            castShadow
         >
             <boxGeometry args={[roofDims.w + 0.6, roofDims.t, roofDims.l]} />
         </mesh>
      </group>

      {isDetailed && (
        <group>
            {/* Luz de Teto */}
            <group position={[0, 3.8, 0]}>
               <mesh material={materials.emissive}><boxGeometry args={[0.3, 0.1, 0.3]} /></mesh>
               <pointLight intensity={2.5} distance={12} decay={2} color="#ffaa44" />
            </group>

            {/* --- CAMA (RE-REPOSICIONADA) --- */}
            {/* House Size: W=8, D=9. Inner Wall Z ~ 4.2. Bed Z Size ~2.4 */}
            {/* New Z = -2.8. Back of bed will be at -2.8 - 1.2 = -4.0. Safe from wall at -4.2 */}
            <group position={[-2.6, 0.5, -2.8]}>
                <mesh position={[0, 0, 0]} material={materials.woodLight} castShadow>
                   <boxGeometry args={[1.6, 0.4, 2.4]} />
                </mesh>
                <mesh position={[0, 0.25, 0]} material={materials.fabric} receiveShadow>
                   <boxGeometry args={[1.4, 0.2, 2.2]} />
                </mesh>
                <mesh position={[0, 0.4, -0.8]} rotation={[0.2, 0, 0]} material={materials.plaster}>
                   <boxGeometry args={[1.0, 0.15, 0.5]} />
                </mesh>
            </group>

            {/* Mesa e Cadeira */}
            <group position={[3.0, 0, 3.0]}>
                <mesh position={[0, 0.7, 0]} material={materials.woodLight} castShadow>
                    <boxGeometry args={[1.6, 0.05, 2.0]} />
                </mesh>
                <mesh position={[0.7, 0.35, 0.9]} material={materials.woodDark}><boxGeometry args={[0.1, 0.7, 0.1]} /></mesh>
                <mesh position={[-0.7, 0.35, 0.9]} material={materials.woodDark}><boxGeometry args={[0.1, 0.7, 0.1]} /></mesh>
                <mesh position={[0.7, 0.35, -0.9]} material={materials.woodDark}><boxGeometry args={[0.1, 0.7, 0.1]} /></mesh>
                <mesh position={[-0.7, 0.35, -0.9]} material={materials.woodDark}><boxGeometry args={[0.1, 0.7, 0.1]} /></mesh>
                
                {/* Cadeira */}
                <group position={[-0.9, 0, 0]} rotation={[0, Math.PI/2, 0]}>
                    <mesh position={[0, 0.4, 0]} material={materials.woodDark}><boxGeometry args={[0.6, 0.05, 0.6]} /></mesh>
                    <mesh position={[0, 0.2, 0.25]} material={materials.woodDark}><boxGeometry args={[0.05, 0.4, 0.05]} /></mesh>
                    <mesh position={[0, 0.2, -0.25]} material={materials.woodDark}><boxGeometry args={[0.05, 0.4, 0.05]} /></mesh>
                    <mesh position={[-0.25, 0.8, 0]} material={materials.woodDark}><boxGeometry args={[0.05, 0.8, 0.6]} /></mesh>
                </group>
            </group>
            
            {/* Tapete Central */}
            <mesh position={[0, 0.12, 0]} rotation={[-Math.PI/2, 0, 0]} material={materials.fabric} receiveShadow>
                <planeGeometry args={[3.0, 4.0]} />
            </mesh>

        </group>
      )}
    </group>
  );
};

export default React.memo(House);
