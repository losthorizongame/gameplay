
import React, { useMemo, useState, useEffect } from 'react';
import * as THREE from 'three';
import { CHUNK_SIZE, WATER_LEVEL, WorkerResponse } from '../types';
import Water from './Water';
import VegetationChunk from './VegetationChunk';
import GrassChunk from './GrassChunk';
import VillageChunk from './VillageChunk';
import { workerManager } from '../services/WorkerManager';
import { chunkCache } from '../services/ChunkCache';

interface TerrainChunkProps {
  x: number; 
  z: number;
  lodLevel: number; 
}

const sharedTerrainMaterial = new THREE.MeshStandardMaterial({
  vertexColors: true,
  roughness: 0.9, 
  flatShading: false, 
  side: THREE.DoubleSide // Garantia de visualização mesmo se as normais estiverem invertidas
});

const TerrainChunk: React.FC<TerrainChunkProps> = ({ x, z, lodLevel }) => {
  const worldX = x * CHUNK_SIZE;
  const worldZ = z * CHUNK_SIZE;

  const [geometry, setGeometry] = useState<THREE.BufferGeometry | null>(null);
  const [hasWater, setHasWater] = useState(false);

  useEffect(() => {
    let isMounted = true;

    // Helper para construir a geometria a partir dos dados do worker ou cache
    const buildGeometry = (data: WorkerResponse) => {
        if (!data.positions || data.positions.length === 0) {
            return;
        }

        const geom = new THREE.BufferGeometry();
        geom.setIndex(new THREE.BufferAttribute(data.indices!, 1));
        geom.setAttribute('position', new THREE.BufferAttribute(data.positions!, 3));
        geom.setAttribute('color', new THREE.BufferAttribute(data.colors!, 3));
        geom.setAttribute('normal', new THREE.BufferAttribute(data.normals!, 3));
        
        geom.computeBoundingSphere();

        if (isMounted) {
            setHasWater(!!data.hasWater);
            setGeometry(geom);
        }
    };
    
    // 1. Tentar pegar do Cache (Síncrono/Imediato)
    const cachedData = chunkCache.get(x, z, lodLevel);

    if (cachedData) {
        buildGeometry(cachedData);
    } else {
        // 2. Se não tem no cache, chama o Worker (Assíncrono)
        workerManager.generateChunk(x, z, lodLevel)
          .then((data) => {
            if (!isMounted) return;
            
            // Salva no cache para uso futuro (ex: quando o jogador se vira)
            chunkCache.set(x, z, lodLevel, data);
            
            buildGeometry(data);
          })
          .catch(err => console.error("Chunk generation failed", err));
    }

    return () => {
      isMounted = false;
      // IMPORTANTE: Dispomos a Geometria (VRAM) mas mantemos os dados no Cache (RAM)
      if (geometry) geometry.dispose();
    };
  }, [x, z, lodLevel]); 

  // OTIMIZAÇÃO CRÍTICA: Sombras apenas no LOD 1 (muito perto).
  const receiveShadow = lodLevel === 1;

  if (!geometry) return null;

  return (
    <group>
      <mesh 
        position={[worldX, 0, worldZ]} 
        geometry={geometry}
        material={sharedTerrainMaterial}
        receiveShadow={receiveShadow}
        castShadow={false} // OTIMIZAÇÃO: Terreno não projeta sombra em si mesmo (ganho alto de FPS)
      />
      
      {/* Água visível até LOD 4 para manter horizonte do mar consistente */}
      {hasWater && lodLevel <= 4 ? (
        <group position={[0, WATER_LEVEL, 0]}>
          <Water x={x} z={z} lodLevel={lodLevel} />
        </group>
      ) : null}

      {/* Vegetação agora vai até LOD 4 para horizonte arborizado */}
      <VegetationChunk chunkX={x} chunkZ={z} lodLevel={lodLevel} />
      
      {lodLevel <= 2 ? (
        <VillageChunk chunkX={x} chunkZ={z} lodLevel={lodLevel} />
      ) : null}

      {lodLevel === 1 ? (
        <GrassChunk chunkX={x} chunkZ={z} />
      ) : null}
    </group>
  );
};

export default React.memo(TerrainChunk);
