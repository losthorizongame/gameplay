
import React from 'react';
import { EffectComposer, Vignette, ToneMapping } from '@react-three/postprocessing';
import { BlendFunction, ToneMappingMode } from 'postprocessing';

const PostFX: React.FC = () => {
  return (
    // OTIMIZAÇÃO: Bloom removido. 
    // Em WebGL, Bloom custa caro (múltiplos render passes). Removê-lo libera muita GPU.
    <EffectComposer disableNormalPass>
      <Vignette 
        offset={0.3} 
        darkness={0.6} 
        eskil={false} 
        blendFunction={BlendFunction.NORMAL}
      />
      <ToneMapping 
        mode={ToneMappingMode.ACES_FILMIC} 
      />
    </EffectComposer>
  );
};

export default PostFX;
