
import React, { useMemo } from 'react';
import { Vector3 } from '../types';

interface HUDProps {
  isPlaying: boolean;
  position: Vector3;
  speed: number;
  fps: number;
  onStart: () => void;
  hasSave: boolean;
  isMuted: boolean;
  toggleMute: () => void;
  missionDistance?: number;
  timeLeft?: number; 
  maxTime?: number; 
  gameState?: 'playing' | 'failed' | 'success'; 
  isMissionActive: boolean; 
  questPhase: 'seek_npc' | 'mission_active';
  beaconsLit: number;
  totalObjectives: number;
  objectName: string;
  gameMode: 'exploration' | 'story';
}

const SoundIconOn = () => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-8 h-8">
    <path strokeLinecap="round" strokeLinejoin="round" d="M19.114 5.636a9 9 0 0 1 0 12.728M16.463 8.288a5.25 5.25 0 0 1 0 7.424M6.75 8.25l4.72-4.72a.75.75 0 0 1 1.28.53v15.88a.75.75 0 0 1-1.28.53l-4.72-4.72H4.51c-.88 0-1.704-.507-1.938-1.354A9.009 9.009 0 0 1 2.25 12c0-.83.112-1.633.322-2.396C2.806 8.756 3.63 8.25 4.51 8.25H6.75Z" />
  </svg>
);

const SoundIconOff = () => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-8 h-8">
    <path strokeLinecap="round" strokeLinejoin="round" d="M17.25 9.75 21.75 14.25M21.75 9.75 17.25 14.25M2.243 4.493l1.67 1.67m0 0 1.95 1.95m0 0 1.67 1.67m-1.67-1.67L7.5 7.5 4.5 10.5H2.25v3h2.25l3 3v2.25l2.25-2.25 3-3m0 0 2.25-2.25m0 0 1.95-1.95" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M10.5 4.5v1.875" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M10.5 19.5v-1.875" />
  </svg>
);

const HUD: React.FC<HUDProps> = ({ 
  isPlaying, 
  position, 
  speed, 
  fps, 
  onStart, 
  hasSave,
  isMuted,
  toggleMute,
  missionDistance,
  timeLeft = 0,
  maxTime = 1,
  gameState = 'playing',
  isMissionActive,
  questPhase,
  beaconsLit,
  totalObjectives,
  objectName,
  gameMode
}) => {
  
  // --- CÁLCULO DA INTENSIDADE DA ESCURIDÃO (VIGNETTE) ---
  const timePercent = Math.max(0, Math.min(100, (timeLeft / maxTime) * 100));
  // Apenas crítico no modo história
  const isUrgent = gameMode === 'story' && isMissionActive && timePercent < 30; 
  const isCritical = gameMode === 'story' && isMissionActive && timePercent < 15; 

  // Opacidade da vinheta preta baseada no tempo
  const darknessOpacity = useMemo(() => {
      if (gameMode === 'exploration') return 0; // Exploração = sem escuridão
      if (!isMissionActive) return 0;
      if (gameState === 'failed') return 1.0;
      if (timePercent > 50) return 0;
      return (1 - (timePercent / 50)) * 0.9; 
  }, [timePercent, gameState, isMissionActive, gameMode]);

  if (!isPlaying) {
    return (
      <div className="absolute inset-0 flex flex-col items-center justify-center z-50 text-white font-sans">
        {/* Background Cinemático */}
        <div className="absolute inset-0 bg-black/40 backdrop-blur-[2px]" />
        
        {/* Title Container */}
        <div className="relative z-10 text-center space-y-8 animate-in fade-in zoom-in duration-700">
            <div>
                <h1 className="text-8xl font-black tracking-tighter text-white drop-shadow-2xl">
                    LOST HORIZONS
                </h1>
                <p className="text-xl font-light tracking-[0.3em] text-blue-300 mt-4 uppercase">
                    Exploração Infinita
                </p>
            </div>
            
            <div className="flex flex-col gap-6 w-80 mx-auto pt-12">
                <button
                    onClick={onStart}
                    className="group relative px-8 py-5 bg-white text-black font-black tracking-widest text-lg uppercase rounded-sm overflow-hidden transition-all duration-300 hover:scale-105 hover:shadow-[0_0_40px_rgba(255,255,255,0.4)]"
                >
                    <span className="relative z-10">{hasSave ? "CONTINUAR JORNADA" : "NOVO JOGO"}</span>
                    <div className="absolute inset-0 bg-blue-400 transform scale-x-0 group-hover:scale-x-100 transition-transform origin-left duration-300 -z-0 mix-blend-multiply" />
                </button>
            </div>

            <div className="text-white/60 text-xs mt-12 space-y-2 font-mono">
                <div className="flex justify-center gap-8">
                    <span>[W,A,S,D] Mover</span>
                    <span>[SHIFT] Correr</span>
                    <span>[ESPAÇO] Pular</span>
                    <span>[E] Interagir</span>
                </div>
            </div>
        </div>

        {/* Toggle de Som */}
        <button 
          onClick={toggleMute}
          className="absolute bottom-10 right-10 p-4 bg-white/10 hover:bg-white/20 backdrop-blur-md rounded-full transition-all hover:scale-110"
        >
          {isMuted ? <SoundIconOff /> : <SoundIconOn />}
        </button>
      </div>
    );
  }

  // TELA DE GAME OVER (Apenas modo história)
  if (gameState === 'failed' && gameMode === 'story') {
      return (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black animate-in fade-in duration-1000">
            <div className="text-center space-y-6">
                <h2 className="text-9xl font-black text-red-600 tracking-tighter uppercase drop-shadow-[0_0_50px_rgba(255,0,0,0.6)] animate-pulse">
                    ESCURIDÃO
                </h2>
                <div className="h-px w-32 bg-red-600 mx-auto" />
                <p className="text-white/50 font-mono tracking-widest uppercase text-sm">
                    Sua luz se apagou. Retornando à vila...
                </p>
            </div>
        </div>
      );
  }

  // HUD DURANTE O JOGO
  return (
    <div className="absolute inset-0 pointer-events-none z-10 overflow-hidden">
      
      {/* VIGNETTE DE ESCURIDÃO (CSS DYNAMIC) */}
      <div 
        className="absolute inset-0 pointer-events-none transition-opacity duration-1000 ease-in-out"
        style={{
            background: 'radial-gradient(circle, transparent 40%, black 120%)',
            opacity: darknessOpacity,
            zIndex: 0
        }}
      />
      {/* Pisca vermelho se crítico */}
      {isCritical && (
         <div className="absolute inset-0 bg-red-900/20 mix-blend-overlay animate-pulse pointer-events-none z-0" />
      )}

      {/* --- HUD ELEMENTS CONTAINER --- */}
      <div className="relative z-10 w-full h-full flex flex-col justify-between p-8">
        
        {/* TOP BAR: TIMER GIGANTE (Só mostra no Modo História Ativo) */}
        {gameMode === 'story' && isMissionActive && (
            <div className="flex justify-center pt-4">
                <div className={`flex flex-col items-center gap-2 transition-all duration-300 ${isUrgent ? 'scale-110' : ''}`}>
                    
                    {/* Barra de Progresso Visual */}
                    <div className="w-[600px] h-2 bg-gray-800 rounded-full overflow-hidden border border-white/10">
                        <div 
                            className={`h-full transition-all duration-200 ease-linear ${isUrgent ? 'bg-red-500 shadow-[0_0_20px_red]' : 'bg-white shadow-[0_0_20px_rgba(255,255,255,0.5)]'}`}
                            style={{ width: `${timePercent}%` }}
                        />
                    </div>

                    {/* Texto do Timer e Contador de Luzes */}
                    <div className="flex justify-between w-full mt-2 px-2">
                        <div className="flex items-baseline gap-2">
                            <span className={`text-5xl font-black tracking-tighter font-mono ${isUrgent ? 'text-red-500 animate-pulse' : 'text-white'}`}>
                                {Math.ceil(timeLeft)}
                            </span>
                            <span className="text-xs font-bold uppercase tracking-[0.2em] text-white/50">
                                Segundos de Luz
                            </span>
                        </div>

                        <div className="flex items-center gap-3">
                             <div className="text-right">
                                <div className="text-4xl font-black text-yellow-400 font-mono drop-shadow-[0_0_10px_orange]">
                                    {beaconsLit}<span className="text-white/30 text-2xl">/{totalObjectives}</span>
                                </div>
                                <div className="text-[10px] uppercase tracking-widest text-white/50">
                                    {objectName}
                                </div>
                             </div>
                        </div>
                    </div>

                    {isUrgent && (
                        <span className="text-red-500 font-bold uppercase tracking-widest text-sm animate-bounce">
                            ⚠ PERIGO: LUZ ACABANDO ⚠
                        </span>
                    )}
                </div>
            </div>
        )}

        {/* TOP LEFT: DEBUG & MODE */}
        <div className="absolute top-8 left-8 space-y-1">
            <div className="text-[10px] font-mono text-white/70">FPS: {fps}</div>
            <div className="text-xs font-bold tracking-widest uppercase px-3 py-1 bg-white/10 rounded-full inline-block border border-white/20 text-white">
                {gameMode === 'exploration' ? 'Modo Exploração' : 'Saga: Sombras'}
            </div>
        </div>

        {/* BOTTOM: MISSION / OBJECTIVE INFO */}
        <div className="flex flex-col items-center pb-8 gap-4">
             {/* MOSTRAR TANTO NA MISSÃO QUANTO NA BUSCA POR NPC (Apenas se houver objetivo ativo ou modo história) */}
             {(isMissionActive || (questPhase === 'seek_npc')) && missionDistance !== undefined && (
                 <div className={`flex items-center gap-4 px-8 py-4 rounded-full border shadow-2xl transition-colors duration-500 ${
                     gameMode === 'story'
                        ? (isMissionActive ? 'bg-black/60 border-white/10' : 'bg-indigo-900/60 border-indigo-500/30')
                        : 'bg-green-900/60 border-green-500/30' // Cor diferente para busca em exploração
                 }`}>
                     <div className="flex flex-col items-end">
                         <span className="text-[10px] uppercase tracking-widest text-gray-400">
                             {gameMode === 'story' && isMissionActive ? `Distância do ${objectName}` : "Distância da Vila"}
                         </span>
                         <span className={`text-3xl font-bold font-mono tracking-tighter ${gameMode === 'story' ? (isMissionActive ? 'text-yellow-400' : 'text-indigo-300') : 'text-green-300'}`}>
                            {Math.round(missionDistance)}<span className="text-sm ml-1 opacity-50">m</span>
                         </span>
                     </div>
                     <div className="h-8 w-px bg-white/20" />
                     <div className="animate-pulse">
                         <div className={`w-3 h-3 rounded-full ${gameMode === 'story' ? (isMissionActive ? 'bg-yellow-400 shadow-[0_0_10px_yellow]' : 'bg-indigo-400 shadow-[0_0_10px_cyan]') : 'bg-green-400 shadow-[0_0_10px_lime]'}`} />
                     </div>
                 </div>
             )}
        </div>

      </div>

      {/* MIRA CENTRAL */}
      <div className="absolute top-1/2 left-1/2 w-1 h-1 bg-white/80 rounded-full transform -translate-x-1/2 -translate-y-1/2 shadow-sm z-20" />
    </div>
  );
};

export default HUD;
