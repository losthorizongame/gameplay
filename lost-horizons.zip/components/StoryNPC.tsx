
import React from 'react';
import * as THREE from 'three';

interface StoryNPCProps {
  position: THREE.Vector3;
  onClick: () => void;
  isInteractable: boolean;
}

const materials = {
    npcRobe: new THREE.MeshStandardMaterial({ color: 0x4b0082, roughness: 0.9 }), 
    npcSkin: new THREE.MeshStandardMaterial({ color: 0xffdbac, roughness: 0.5 }),
    eyeGlow: new THREE.MeshBasicMaterial({ color: 0x00ffff }),
    woodPlank: new THREE.MeshStandardMaterial({ color: 0x5c4033, roughness: 0.9 }),
};

const StoryNPC: React.FC<StoryNPCProps> = ({ position, onClick, isInteractable }) => {
    
    // LookAt player logic é tratada pela câmera ou billboard se necessário, mas aqui é estático rotacionado
    // Como é um NPC "Mistico", ele pode estar sempre encarando uma direção ou apenas estático.
    
    return (
        <group position={[position.x, position.y, position.z]} onClick={(e) => { e.stopPropagation(); if(isInteractable) onClick(); }}>
             {/* Indicador de Quest */}
             {isInteractable && (
                <group position={[0, 3.5, 0]}>
                     <mesh position={[0, 0, 0]}>
                         <dodecahedronGeometry args={[0.2, 0]} />
                         <meshBasicMaterial color="#ffff00" />
                     </mesh>
                     <mesh position={[0, -0.4, 0]}>
                         <coneGeometry args={[0.1, 0.4, 4]} />
                         <meshBasicMaterial color="#ffff00" />
                     </mesh>
                     <pointLight distance={5} color="#ffff00" intensity={1} />
                </group>
             )}

             {/* Corpo (Robe) */}
             <mesh position={[0, 0.9, 0]} material={materials.npcRobe} castShadow>
                 <cylinderGeometry args={[0.3, 0.6, 1.8, 16]} /> 
             </mesh>
             {/* Cabeça */}
             <mesh position={[0, 1.9, 0]} material={materials.npcSkin} castShadow>
                 <sphereGeometry args={[0.25, 16, 16]} />
             </mesh>
             {/* Capuz */}
             <mesh position={[0, 2.0, -0.05]} rotation={[-0.2, 0, 0]} material={materials.npcRobe} castShadow>
                 <coneGeometry args={[0.4, 0.6, 16, 1, true]} />
             </mesh>
             
             {/* Olhos Brilhantes */}
             <mesh position={[0.1, 1.95, 0.2]} material={materials.eyeGlow}>
                 <sphereGeometry args={[0.03, 8, 8]} />
             </mesh>
             <mesh position={[-0.1, 1.95, 0.2]} material={materials.eyeGlow}>
                 <sphereGeometry args={[0.03, 8, 8]} />
             </mesh>

             {/* Cajado */}
             <group position={[0.5, 0, 0.3]} rotation={[0, 0, -0.1]}>
                 <mesh position={[0, 1.1, 0]} material={materials.woodPlank}><cylinderGeometry args={[0.03, 0.03, 2.2]} /></mesh>
                 <mesh position={[0, 2.2, 0]} material={materials.eyeGlow}>
                     <dodecahedronGeometry args={[0.1, 0]} />
                 </mesh>
                 <pointLight position={[0, 2.2, 0]} color="#00ffff" distance={3} decay={2} intensity={0.5} />
             </group>
             
             {/* Área de Clique Invisível Maior */}
             <mesh visible={false}>
                 <cylinderGeometry args={[1, 1, 3]} />
             </mesh>
        </group>
    );
}

export default StoryNPC;
