
import React, { useMemo } from 'react';
import { CHUNK_SIZE, VILLAGE_GRID_SIZE } from '../types';
import { getVillageContent } from '../services/MathUtils';
import House from './House';
import VillageObject from './VillageObjects';

interface VillageChunkProps {
  chunkX: number;
  chunkZ: number;
  lodLevel: number;
}

const VillageChunk: React.FC<VillageChunkProps> = ({ chunkX, chunkZ, lodLevel }) => {
  
  const content = useMemo(() => {
    // Se estiver muito longe, não renderiza vilas para economizar performance
    if (lodLevel > 2) return { houses: [], objects: [] };

    const chunkWorldX = chunkX * CHUNK_SIZE;
    const chunkWorldZ = chunkZ * CHUNK_SIZE;
    
    const housesList = [];
    const objectsList = [];

    // Calcular limites de regiões de vila que interceptam este chunk
    const regionMinX = Math.floor(chunkWorldX / VILLAGE_GRID_SIZE) - 1;
    const regionMaxX = Math.floor((chunkWorldX + CHUNK_SIZE) / VILLAGE_GRID_SIZE) + 1;
    const regionMinZ = Math.floor(chunkWorldZ / VILLAGE_GRID_SIZE) - 1;
    const regionMaxZ = Math.floor((chunkWorldZ + CHUNK_SIZE) / VILLAGE_GRID_SIZE) + 1;

    for (let rx = regionMinX; rx <= regionMaxX; rx++) {
      for (let rz = regionMinZ; rz <= regionMaxZ; rz++) {
        const data = getVillageContent(rx, rz);
        
        // Filter Houses
        for (const house of data.houses) {
           if (house.x >= chunkWorldX && house.x < chunkWorldX + CHUNK_SIZE &&
               house.z >= chunkWorldZ && house.z < chunkWorldZ + CHUNK_SIZE) {
               
               housesList.push({
                 pos: [house.x, house.y, house.z] as [number, number, number],
                 rot: house.rot,
                 id: `h_${rx}_${rz}_${house.x}`
               });
           }
        }
        
        // Filter Objects
        for (const obj of data.objects) {
            if (obj.x >= chunkWorldX && obj.x < chunkWorldX + CHUNK_SIZE &&
                obj.z >= chunkWorldZ && obj.z < chunkWorldZ + CHUNK_SIZE) {
                
                objectsList.push({
                  type: obj.type,
                  pos: [obj.x, obj.y, obj.z] as [number, number, number],
                  rot: obj.rot,
                  id: `o_${rx}_${rz}_${obj.x}_${obj.type}`
                });
            }
        }
      }
    }

    return { houses: housesList, objects: objectsList };
  }, [chunkX, chunkZ, lodLevel]);

  if (content.houses.length === 0 && content.objects.length === 0) return null;

  return (
    <group>
      {content.houses.map(house => (
        <House 
          key={house.id} 
          position={house.pos} 
          rotationY={house.rot} 
          seed={0} 
          lodLevel={lodLevel} 
        />
      ))}
      
      {content.objects.map(obj => (
        <VillageObject 
            key={obj.id}
            type={obj.type}
            position={obj.pos}
            rotation={obj.rot}
        />
      ))}
    </group>
  );
};

export default React.memo(VillageChunk);
